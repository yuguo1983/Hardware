/* Includes ------------------------------------------------------------------*/
#include "include.h"


#define ADDR0() HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_5)
#define ADDR1() HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_4)
#define ADDR2() HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_3)
//#define ADDR3() HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_6)
//#define MB_SAMPLE_TEST_SLAVE_ADDR  0x01

const uint8_t TEXT_Buffer[]={"test 24c02 IIC TEST\r\n"};
#define SIZE sizeof(TEXT_Buffer)

uint8_t getModBusAddressConfig(void)
{
	return (ADDR0() << 1 | ADDR1());
}



void app(void)
{
	uint16_t ret=1;
	uint8_t datatemp[SIZE];
	uint32_t * temp;
	int32_t vol=0;
	bsp_gpio_init();
	AT24CXX_Init();
	dac7512_hw_init();
//	INA226_Init();
	CHIP_IIC_Init();
	INA2XX_Init(0,50,2000);
	INA2XX_Init(1,50,2);
	eMBInit(MB_RTU, 90, 0, 19200, MB_PAR_NONE);
	eMBEnable();
	ret=AT24CXX_Check();
	printf("at24c02 is:%d\r\n",ret);
	AT24CXX_Write(0,(uint8_t*)TEXT_Buffer,SIZE);
	AT24CXX_Read(0,datatemp,SIZE);
	for(int i=0;i<SIZE;i++)
	{
		printf("%c",datatemp[i]);
	}
			vol=INA2XX_GetVoltage(0,temp);
		HAL_Delay(100);
			printf("%d",vol);
	     vol=INA2XX_GetShuntVoltage(0,temp);
		 printf("%d",vol);
	while (1)
	{
		( void )eMBPoll(  );
		UpVoltage();
	}
}
uint16_t TempVoltageOne=0;
uint16_t TempVoltageTwo=0;
void UpVoltage(void)
{
	if(TempVoltageOne!=VoltegeOne)
	{
		TempVoltageOne=VoltegeOne;
		set_vol1(CALIB_VOutToDACCode(TempVoltageOne));
		set_vol1(CALIB_VOutToDACCode(TempVoltageOne));
	}
	if(TempVoltageTwo!=VoltegeTwo)
	{
		TempVoltageTwo=VoltegeTwo;
		set_vol(CALIB_VOutToDACCode(TempVoltageTwo));
		set_vol(CALIB_VOutToDACCode(TempVoltageTwo));
	}
}


