/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __APP_H
#define __APP_H


/* Includes ------------------------------------------------------------------*/

#include "main.h"
#include "include.h"


extern uint16_t VoltegeOne;
extern uint16_t VoltegeTwo;




void app(void);


uint8_t getModBusAddressConfig(void);
void TIM_ModBus_Config(uint16_t usTimeOut50us);
void UpVoltage(void);
#endif






