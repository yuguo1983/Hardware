#include "include.h"

/////////////
//2毫欧方案//   
////////////

/////////////
//1毫欧方案//
////////////

//Configuration Register 00h  ===  0x43FF === D15-RST;D12:D14-000 ; D9:D11(AVG)-001 ; D6:D8(VBCT)-111 ; D3:D5(VSHCT)-111 ; D0-D2(MODE)-111
//Shunt Voltage Register 01h (Read-Only)2.5uV/bit  ===  D15:正负标志 ; D0:D14-DATA ; 负数:二进制补码 +1
//Bus Voltage Register 02h (Read-Only)1.25mV/bit  ===  d15:0 ; D0:D14 - DATA ; 不支持负电压检测
//Power Register 03h (Read-Only) --- 25*Current_LSB/bit === D0:D15 - DATA
//Current Register 04h (Read-Only)1mA/bit === d15:0 ; D0:D14 - DATA 
//Calibration Register 05h (Read/Write) === 0xA00 === d15:0 ; D0:D14 - DATA 
//Mask/Enable 06h (Read/Write) === 0x0000H ===
//Bit 15 - SOL: Shunt Voltage Over-Voltage  
//Bit 14 - SUL: Shunt Voltage Under-Voltage 
//Bit 13 - BOL: Bus Voltage Over-Voltage 
//Bit 12 - BUL: Bus Voltage Under-Voltage 
//Bit 11 - POL: Over-Limit Power
//Bit 10 - CNVR: Conversion Read 
//Bit 4 - AFF: Alert Function Flag 
//Bit 3 - CVRF: Conversion Ready Flag 
//Bit 2 - OVF: Math Overflow Flag 
//Bit 1 - APOL: Alert Polarity bit; sets the Alert pin polarity.
//Bit 0 - LEN: Alert Latch Enable; configures the latching feature of the Alert pin and Flag bits.
//Alert Limit 07h (Read/Write) === 0x0000H === D0:D15 - DATA 
//INA226 ADDR : 1000000 

extern  uint16_t test_data[16];
/////////////
//50毫欧方案//
////////////
void INA226_Init(void)
{	
	bsp_InitI2C();
	
	INA226_SendData(ONE_ADDR,CFG_REG,0x4547);
	INA226_SendData(ONE_ADDR,CAL_REG,0x029F);

	INA226_SendData(TWO_ADDR,CFG_REG,0x4527);
	INA226_SendData(TWO_ADDR,CAL_REG,0x029F);
	
	
}


void INA226_SetRegPointer(uint8_t addr,uint8_t reg)
{
	i2c_Start();

	i2c_SendByte(addr);
	i2c_WaitAck();
  i2c_SendByte(reg);
	i2c_WaitAck();

	i2c_Stop();
}

void INA226_SendData(uint8_t addr,uint8_t reg,uint16_t data)
{
	uint8_t temp=0;
	i2c_Start();

	i2c_SendByte(addr);
	i2c_WaitAck();

  i2c_SendByte(reg);
	i2c_WaitAck();
	
	temp = (uint8_t)(data>>8);
	i2c_SendByte(temp);
	i2c_WaitAck();

	temp = (uint8_t)(data&0x00FF);
	i2c_SendByte(temp);
	i2c_WaitAck();
	
	i2c_Stop();
}

uint16_t INA226_ReadData(uint8_t addr)
{
	uint16_t temp=0;
	i2c_Start();

	i2c_SendByte(addr+1);
	i2c_WaitAck();
	
	temp = i2c_ReadByte();
	temp<<=8;	
	temp |= i2c_ReadByte();
	
	i2c_Stop();
	return temp;
}

uint8_t INA226_AlertAddr(void)
{
	uint8_t temp;
	i2c_Start();

	i2c_SendByte(INA226_GETALADDR);
	i2c_WaitAck();
	
	temp = i2c_ReadByte();
	
	i2c_Stop();
	return temp;
}

//1mA/bit

uint16_t INA226_GetCurrent(uint8_t addr)
{
	uint16_t temp=0;	
	INA226_SetRegPointer(addr,SV_REG);
	temp = INA226_ReadData(addr);
	if(temp&0x8000)
	{
		temp = ~(temp - 1);	
		temp = (temp*25 + 5) / 10 / 5;		
	}
	else
	{
		INA226_SetRegPointer(addr,CUR_REG);
		temp = INA226_ReadData(addr);
		temp = temp&0x7fff;
	}
	temp=temp*61/1000;
	return temp;
}

//1.25mV/bit

uint16_t INA226_GetVoltage(uint8_t addr)
{
	float temp=0;
	INA226_SetRegPointer(addr,BV_REG);
	temp = INA226_ReadData(addr);
	temp = (float)(temp*125)/100;
	//printf("voltage is :%d",(uint16_t)temp);
	return (uint16_t)temp;	
	
}

//2.5uV/bit
uint16_t INA226_GetShuntVoltage(uint8_t addr)
{
	uint32_t temp=0;
	INA226_SetRegPointer(addr,SV_REG);
	temp = INA226_ReadData(addr);
	if(temp&0x8000)	temp = ~(temp - 1);	
	temp = (temp*250) / 100;
	return (uint16_t)temp;	
}








