/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __BSP_GPIO_H
#define __BSP_GPIO_H


/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"
#include "main.h"
#include "gpio.h"


#define EPROM_SCL_Pin GPIO_PIN_13
#define EPROM_SCL_GPIO_Port GPIOC
#define EPROM_SDA_Pin GPIO_PIN_14
#define EPROM_SDA_GPIO_Port GPIOC
#define RUN_LED_Pin GPIO_PIN_15
#define RUN_LED_GPIO_Port GPIOC
#define SYNC_Pin GPIO_PIN_0
#define SYNC_GPIO_Port GPIOA
#define RS485_EN_Pin GPIO_PIN_1
#define RS485_EN_GPIO_Port GPIOA
#define SCK_Pin GPIO_PIN_0
#define SCK_GPIO_Port GPIOB
#define MOSI_Pin GPIO_PIN_1
#define MOSI_GPIO_Port GPIOB
#define RS_Pin GPIO_PIN_10
#define RS_GPIO_Port GPIOB
#define ROM_CS_Pin GPIO_PIN_11
#define ROM_CS_GPIO_Port GPIOB
#define SPI2_SYNC_Pin GPIO_PIN_12
#define SPI2_SYNC_GPIO_Port GPIOB
#define KEY1_Pin GPIO_PIN_8
#define KEY1_GPIO_Port GPIOA
#define KEY2_Pin GPIO_PIN_11
#define KEY2_GPIO_Port GPIOA
#define KEY3_Pin GPIO_PIN_12
#define KEY3_GPIO_Port GPIOA
#define ERR_LED_Pin GPIO_PIN_15
#define ERR_LED_GPIO_Port GPIOA
#define SW3_Pin GPIO_PIN_3
#define SW3_GPIO_Port GPIOB
#define SW2_Pin GPIO_PIN_4
#define SW2_GPIO_Port GPIOB
#define SW1_Pin GPIO_PIN_5
#define SW1_GPIO_Port GPIOB
#define BL_EN_Pin GPIO_PIN_6
#define BL_EN_GPIO_Port GPIOB
#define SCREEN_RST_Pin GPIO_PIN_7
#define SCREEN_RST_GPIO_Port GPIOB




void bsp_gpio_init(void);





#endif 



