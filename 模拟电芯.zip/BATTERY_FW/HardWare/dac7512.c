/* Includes ------------------------------------------------------------------*/
#include "include.h"

void dac7512_hw_init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOB_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	GPIO_InitStruct.Pin = GPIO_PIN_13|GPIO_PIN_0|GPIO_PIN_1;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
	
	GPIO_InitStruct.Pin = GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
	
	GPIO_InitStruct.Pin = GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
	
	GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
	
}

void dac7512_write_dac(uint16_t value,uint8_t mode)
{
	
	uint16_t temp=0;
	int i;
	temp=mode;
	temp|=temp<<12;
	if(value>4095)
	{
		printf("�����ѹֵ����Χ!!!!!!!!\r\n");
		return;
	}
	temp|=value;
  SYNC_0;
	for( i =0; i <16; i++ ) 
	{
		if(0x8000 ==(temp & 0x8000))
		DIN_1;
		else
		DIN_0;
		SCLK_1;
		__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
		SCLK_0;
		temp = temp << 1;
	}
	SYNC_1;
}

void dac7512_write_dac1(uint16_t value,uint8_t mode)
{
	
	uint16_t temp=0;
	int i;
	temp=mode;
	temp|=temp<<12;
	if(value>4095)
	{
		printf("�����ѹֵ����Χ!!!!!!!!\r\n");
		return;
	}
	temp|=value;
  SYNC1_0;
	for( i =0; i <16; i++ ) 
	{
		if(0x8000 ==(temp & 0x8000))
		DIN1_1;
		else
		DIN1_0;
		SCLK1_1;
		__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
		SCLK1_0;
		temp = temp << 1;
	}
	SYNC1_1;
}

void set_vol(uint16_t voltege)
{
	float code=0;
	code=(float)voltege/3300;
	code=code*4096;
	dac7512_write_dac((uint16_t)code,NORMAL);
}


void set_vol1(uint16_t voltege)
{
	float code=0;
	code=(float)voltege/3300;
	code=code*4096;
	dac7512_write_dac1((uint16_t)code,NORMAL);
}

uint64_t CALIB_VOutToDACCode(int64_t uiValue)
{
	int64_t uiGain = 0;
	int64_t uiOffset = 0;
	int64_t uiCodeMin = 0;
	int64_t uiCodeMax = 0;
	int64_t uiOutMin = 0;
	int64_t uiOutMax = 0;		
	int64_t uliValue = 0;

	
	uiCodeMin = 100;
	uiCodeMax = 1200;
	
	uiOutMin = 840;
	uiOutMax = 9600;
	
	uiGain = uiOutMax - uiOutMin;
	uiOffset = uiCodeMax - uiCodeMin;
	
	//dbSlope = (double)uiGain/(double)uiOffset;	
	//vout = voumin + (dacx - dacmin)*slope;
	//dacx = (vout-voutmin)/slope + dacmin;	

//	uliValue = uiValue;
//	uliValue *= 10;		
	uliValue = (uiValue - uiOutMin);
//	uliValue -= uiOutMin;	
	uliValue *= uiOffset;	
	uliValue /= uiGain;	
	uliValue += uiCodeMin;
	
	return (uint32_t)uliValue;
}


