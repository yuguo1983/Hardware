#include <stdint.h>
#include <stddef.h>
#include <stdio.h>

#include "include.h"

static void IIC1_SCL_L(void);
static void IIC1_SCL_H(void);
static void IIC1_SDA_L(void);
static void IIC1_SDA_H(void);
static int IIC1_ReadSCL(void);
static int IIC1_ReadSDA(void);

static _srtI2CPort srtI2CPort = 
{
	//port 1
	IIC1_SCL_L,
	IIC1_SCL_H,
	IIC1_SDA_L,
	IIC1_SDA_H,	
	IIC1_ReadSCL,
	IIC1_ReadSDA,
	//port 2
	IIC1_SCL_L,
	IIC1_SCL_H,
	IIC1_SDA_L,
	IIC1_SDA_H,	
	IIC1_ReadSCL,
	IIC1_ReadSDA,
//	//port 3
//	IIC2_SCL_L,
//	IIC2_SCL_H,
//	IIC2_SDA_L,
//	IIC2_SDA_H,	
//	IIC2_ReadSCL,
//	IIC2_ReadSDA,
//	//port 4
//	IIC4_SCL_L,
//	IIC4_SCL_H,
//	IIC4_SDA_L,
//	IIC4_SDA_H,	
//	IIC4_ReadSCL,
//	IIC4_ReadSDA,
//	//port 5
//	IIC3_SCL_L,
//	IIC3_SCL_H,
//	IIC3_SDA_L,
//	IIC3_SDA_H,	
//	IIC3_ReadSCL,
//	IIC3_ReadSDA,
//	//port 6
//	IIC5_SCL_L,
//	IIC5_SCL_H,
//	IIC5_SDA_L,
//	IIC5_SDA_H,	
//	IIC5_ReadSCL,
//	IIC5_ReadSDA,
//	//port 7,EXTERNAL,BL
//	IIC7_SCL_L,
//	IIC7_SCL_H,
//	IIC7_SDA_L,
//	IIC7_SDA_H,	
//	IIC7_ReadSCL,
//	IIC7_ReadSDA,
};


static void IIC1_SCL_L(void)
{
	GPIOC->BSRR= (uint32_t)GPIO_PIN_13<<16U;
}

static void IIC1_SCL_H(void)
{
   GPIOC->BSRR= GPIO_PIN_13;
}
static void IIC1_SDA_L(void)
{
	GPIOC->BSRR= (uint32_t)GPIO_PIN_14<<16U;
}

static void IIC1_SDA_H(void)
{
   GPIOC->BSRR= GPIO_PIN_14;
}

static int IIC1_ReadSCL(void)
{
    return (GPIOC->IDR & GPIO_PIN_13) != 0;
}

static int IIC1_ReadSDA(void)
{
    return (GPIOC->IDR & GPIO_PIN_14) != 0;
}
/***************************************************************************
    Function           :static void IIC_PollTick(void)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it   ?   :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
static void IIC_PollTick(void)
{
    int i = 0;
    uint32_t uiTick = 44; //215,100KHz,44,400KHz
    
    for(i = 0; i < uiTick; i++)
    {}
}

/***************************************************************************
    Function           :void CHIP_IIC_Init(void)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it   ?   :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
void CHIP_IIC_Init(void)
{
//		bsp_InitI2C();
		i2c_Stop();
		CHIP_IIC_WakeUpBus(&srtI2CPort.Port1);    //������������Իָ�����
}
/***************************************************************************
    Function           :_srtI2CBase *CHIP_IIC_GetInfor(uint32_t uiPort)
    Description        : 
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it   ?   :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
_srtI2CPort *CHIP_IIC_GetInfor(void)
{	
	return  &srtI2CPort;	
}
/***************************************************************************
    Function           :static int CHIP_IIC_WaitSCLStretch(_srtI2CBase *psrtPort)
    Description        : 
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it   ?   :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
static int CHIP_IIC_WaitSCLStretch(_srtI2CBase *psrtPort)
{
    int i = 0;

    psrtPort->SCL_H();
    IIC_PollTick();
	
    for(i = 0; i < 150; i++)
    {
        IIC_PollTick();
		
        if(psrtPort->readSCL())
        {
            return 1;
        }        
    }
	
    return -1;
}

/***************************************************************************
    Function           :static int CHIP_IIC_CheckLineIsLow(_srtI2CBase *psrtPort)
    Description        : 
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it   ?   :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
static int CHIP_IIC_CheckLineIsLow(_srtI2CBase *psrtPort)
{
	int i = 0;
	
	for(i = 0; i < 0x150; i++)
	{
		if(psrtPort->readSCL())
		{
			if(psrtPort->readSDA())
			{
				return 1;
			}
		}		
	}

    return -1;
}
/***************************************************************************
    Function           :void IIC_WakeUpBus(_srtI2CBase *psrtPort)  
    Description        :SDA���ߣ�SCL��������9�����帴λI2c�豸��һ��Ҫ���¸�λ�������ϵ����׳���
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it   ?   :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
void CHIP_IIC_WakeUpBus(_srtI2CBase *psrtPort)
{
    int i = 0;
	
    for(i = 0; i < 9; i++) 
    {
        psrtPort->SCL_H();
        IIC_PollTick();
        psrtPort->SCL_L();
        IIC_PollTick();
        psrtPort->SCL_H();
    }
}
static int CHIP_IIC_Wait_ACK(_srtI2CBase *psrtPort);
static void CHIP_IIC_WriteByte(_srtI2CBase *psrtPort,unsigned char Data);
/***************************************************************************
    Function           :static int CHIP_IIC_SendStart(_srtI2CBase *psrtPort)
    Description        : 
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it   ?   :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
static int CHIP_IIC_SendStart(_srtI2CBase *psrtPort)
{
    // Check bus
    if(CHIP_IIC_CheckLineIsLow(psrtPort) < 0)
    {
        CHIP_IIC_WakeUpBus(psrtPort);    //������������Իָ�����
        //return -1;
    }

    psrtPort->SDA_L();
    IIC_PollTick();
    psrtPort->SCL_L();      //SCL���ͣ��ǳ���Ҫ
    IIC_PollTick();
	
	return 1;
}
/***************************************************************************
    Function           :int CHIP_IIC_Start(_srtI2CBase *psrtPort,unsigned char ucSlaveAddr)  
    Description        :����IIC������ʼ�źţ���SCLΪ���ڼ䣬SDA��һ���½��ؼ���ʼ�ź� 
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it   ?   :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int CHIP_IIC_Start(_srtI2CBase *psrtPort,unsigned char ucSlaveAddr)
{
    CHIP_IIC_SendStart(psrtPort);

	CHIP_IIC_WriteByte(psrtPort,ucSlaveAddr);
	
	if(CHIP_IIC_Wait_ACK(psrtPort) < 0)
	{
//		printf("\r\n%s,write start error,0x%02X",__func__,ucSlaveAddr);
		
		return -1; 
	}
    return 1;    
}

/***************************************************************************
    Function           :int CHIP_IIC_StartAgain(_srtI2CBase *psrtPort,unsigned char ucSlaveAddr)  
    Description        :����IIC������ʼ�źţ���SCLΪ���ڼ䣬SDA��һ���½��ؼ���ʼ�ź� 
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it   ?   :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int CHIP_IIC_StartAgain(_srtI2CBase *psrtPort,unsigned char ucSlaveAddr)
{
    psrtPort->SDA_H();
    IIC_PollTick();
	if(CHIP_IIC_WaitSCLStretch(psrtPort) < 0)
	{
		return -1;
	}
    CHIP_IIC_SendStart(psrtPort);

	CHIP_IIC_WriteByte(psrtPort,ucSlaveAddr | 0x01);
	
	if(CHIP_IIC_Wait_ACK(psrtPort) < 0)
	{
//		printf("\r\n%s,write start error,0x%02X",__func__,ucSlaveAddr);
		
		return -1; 
	}
    return 1;    
}
/***************************************************************************
    Function           :void IIC_Stop(_srtI2CBase *psrtPort)  
    Description        :����IIC����ֹͣ�źţ���SCLΪ���ڼ䣬SDA��һ�������ؼ�ֹͣ�ź� 
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it   ?   :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int CHIP_IIC_Stop(_srtI2CBase *psrtPort) 
{     
    psrtPort->SDA_L();    
    IIC_PollTick(); 
	
	if(CHIP_IIC_WaitSCLStretch(psrtPort) < 0)
	{
		return -1;
	}	
	
    psrtPort->SDA_H();
    IIC_PollTick();
	
	if(psrtPort->readSDA())
	{
		IIC_PollTick(); 
		return 1;
	}
	
	return -1;
}

/***************************************************************************
    Function           :static void IIC_Wait_ACK(_srtI2CBase *psrtPort)  
    Description        :IIC�����ȴ��ӻ�����Ӧ���źţ���SCLΪ�ߵ�ƽ�ڼ䣬SDA����Ϊ�͵�ƽ������ʱ���� 
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it   ?   :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
static int CHIP_IIC_Wait_ACK(_srtI2CBase *psrtPort)
{
    int i = 0;
    int retry = 0x5000;
    
    psrtPort->SCL_L();
    IIC_PollTick();
    psrtPort->SDA_H();
    IIC_PollTick();        
    psrtPort->SCL_H();
    IIC_PollTick();
    
    for(i = 0; i < retry; i++)
    {
        if(0 == psrtPort->readSDA())
        {
            break;
        }
    }
    
    if(i >= retry)
    {
        CHIP_IIC_Stop(psrtPort);
        return -1;
    }
    
    psrtPort->SCL_L(); //SCL���ͣ��ǳ���Ҫ
    return 1;
}

/***************************************************************************
    Function           :static void IIC_Send_ACK(_srtI2CBase *psrtPort)  
    Description        :IIC��������Ӧ���źţ���SDA�߱�����
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it   ?   :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
static int CHIP_IIC_Send_ACK(_srtI2CBase *psrtPort)
{
    psrtPort->SDA_L();      //SDA����,����Ӧ��
    IIC_PollTick();	
	if(CHIP_IIC_WaitSCLStretch(psrtPort) < 0)
	{
        psrtPort->SDA_H();
		
		return -1;
	}
    psrtPort->SCL_L();
    IIC_PollTick();	
	
	return 1;
}

/***************************************************************************
    Function           :static void IIC_Send_NACK(_srtI2CBase *psrtPort)  
    Description        :IIC����������Ӧ���źţ���SDA�߱�����
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it   ?   :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
static int CHIP_IIC_Send_NACK(_srtI2CBase *psrtPort)
{
    psrtPort->SDA_H();      //SDA����,����Ӧ��
    IIC_PollTick();	
	if(CHIP_IIC_WaitSCLStretch(psrtPort) < 0)
	{
        psrtPort->SDA_H();
		
		return -1;
	}
	if(psrtPort->readSDA())
	{}
	else
	{
		return -1;
	}
    psrtPort->SCL_L();
    IIC_PollTick();	
    
    return 1;	
}

/***************************************************************************
    Function           :static void IIC_WriteByte(_srtI2CBase *psrtPort,unsigned char Data)
    Description        :IIC������ӻ�����һ���ֽ�
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it   ?   :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
static void CHIP_IIC_WriteByte(_srtI2CBase *psrtPort,unsigned char Data)
{
    int i = 0;

    for(i = 0; i < 8; i++)
    {
        IIC_PollTick();
        psrtPort->SCL_L();
        
        if(Data & (0x80 >> i))
        {
            psrtPort->SDA_H();
        }
        else
        { 
            psrtPort->SDA_L();
        }
        IIC_PollTick();
        psrtPort->SCL_H();        //SCL���ߣ�����������
    }
    IIC_PollTick();
    psrtPort->SCL_L();            //SCL���ͣ��ǳ���Ҫ
}

/***************************************************************************
    Function           :static unsigned char IIC_ReadByte(_srtI2CBase *psrtPort)
    Description        :IIC�����Ӵӻ���ȡһ���ֽ�
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it   ?   :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
static unsigned char CHIP_IIC_ReadByte(_srtI2CBase *psrtPort)
{
    int i = 0;
    unsigned char ucData = 0;

    psrtPort->SDA_H();
    
    for(i = 0; i < 8; i++)
    {
        ucData <<= 1;
        IIC_PollTick();

        psrtPort->SCL_L();
        IIC_PollTick();
        psrtPort->SCL_H();
        IIC_PollTick();
        if(psrtPort->readSDA())       //���ܽŵ�״̬
        {
            ucData++;            
        }            
    }
    psrtPort->SCL_L();        //SCL���ͣ��ǳ���Ҫ

    return(ucData);
}


/***************************************************************************
    Function           :static void IIC_WriteFrame(unsigned char ucLen)
    Description        :IIC��������д�������
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it   ?   :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int CHIP_IIC_WriteFrame(_srtI2CBase *psrtPort,unsigned char *pucFrame,uint32_t uiLen)
{
    int i = 0;    
    
    for(i = 0; i < uiLen; i++)
    {
        CHIP_IIC_WriteByte(psrtPort,*pucFrame++); //IIC���߷���д��������
        if(CHIP_IIC_Wait_ACK(psrtPort) < 0)             //�ȴ��ӻ�Ӧ��        
        {
            return -1;
        }
    }
    
    return 1;
}
/***************************************************************************
    Function           :static void IIC_ReadFrame(unsigned char ucLen)
    Description        :IIC����������������ݣ������һ�����ݶ��������Ҫ�������ͷ�Ӧ���ź�
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it   ?   :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int CHIP_IIC_ReadFrame(_srtI2CBase *psrtPort,unsigned char *pucFrame,uint32_t uiLen)
{
    int i = 0;    
    
    for(i = 0; i < uiLen - 1; i++)
    {
        *pucFrame++ = CHIP_IIC_ReadByte(psrtPort);  //IIC���߷���д��������
        CHIP_IIC_Send_ACK(psrtPort);                //�ȴ��ӻ�Ӧ��        
    }
    
    *pucFrame++ = CHIP_IIC_ReadByte(psrtPort);      //IIC���߷���д��������
    CHIP_IIC_Send_NACK(psrtPort);                   //�����õ����ݣ���ӻ����ͷ�Ӧ���ź�
    
    return 1;
}
