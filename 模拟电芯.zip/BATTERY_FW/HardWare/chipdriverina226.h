#ifndef _CHIP_DRIVER_INA226_H_
#define _CHIP_DRIVER_INA226_H_

#include <stdint.h>

int INA2XX_Init(uint32_t uiPort,uint32_t uiShuntR,uint32_t uiIMaxExpected);
int INA2XX_GetShuntCurrent(uint32_t uiPort, uint32_t *puiValue);
int INA2XX_GetShuntVoltage(uint32_t uiPort, uint32_t *puiValue);
int INA2XX_GetVoltage(uint32_t uiPort, uint32_t *puiValue);
int INA2XX_GetPower(uint32_t uiPort,uint32_t *puiValue);
int INA2XX_SetAlarmLimit(uint32_t uiPort,uint32_t uiVoltage,uint32_t uiCurrent,uint32_t uiExpected);

#endif
