#include <stddef.h>
#include <stdint.h>

#include "include.h"
#define INA2XX_SLAVE_ADDR           (0x40 << 1)
#define INA2XX_SLAVE_ADDR_MODULE1   (0x41 << 1)
// common register definitions 
#define INA2XX_CONFIG			0x00
#define INA2XX_SHUNT_VOLTAGE	0x01 // readonly
#define INA2XX_BUS_VOLTAGE		0x02 // readonly
#define INA2XX_POWER			0x03 // readonly
#define INA2XX_CURRENT			0x04 // readonly
#define INA2XX_CALIBRATION		0x05
#define INA2XX_MASK_ENABLE 		0x06
#define INA2XX_ALERT   		    0x07

#define DEVICE_INA226

#if defined (DEVICE_INA220)
// settings - depend on use case 
//RST,0;BRING,32-V;PGA,8;ADC,12BIT,(532us conversion time),shunt and bus continuous,0x399F,532us*2
//RST,0;BRING,32-V;PGA,4;ADC,12BIT,(532us conversion time),shunt and bus continuous,0x319F,532us*2
//RST,0;BRING,32-V;PGA,4;ADC,12BIT,(532us conversion time),shunt and bus continuous,4 SAMPLES,0x3557,2.13ms*2
//RST,0;BRING,32-V;PGA,4;ADC,12BIT,(532us conversion time),shunt and bus continuous,8 SAMPLES,0x35DF,4.26ms*2
//RST,0;BRING,32-V;PGA,4;ADC,12BIT,(532us conversion time),shunt and bus continuous,16 SAMPLES,0x3667,8.51ms*2
//RST,0;BRING,32-V;PGA,4;ADC,12BIT,(532us conversion time),shunt and bus continuous,32 SAMPLES,0x36EF,17.02ms*2
//RST,0;BRING,32-V;PGA,8;ADC,12BIT,(532us conversion time),shunt and bus continuous,16 SAMPLES,0x3E67,8.51ms*2
#define INA2XX_CONFIG_DEFAULT	0x3667	
#elif defined(DEVICE_INA226)
//RST,0;AVG,16;(588us conversion time),shunt and bus continuous,16 SAMPLES,588us*16*2,0x44DF
//RST,0;AVG,4;(1.1ms conversion time),shunt and bus continuous,4 SAMPLES,1.1ms*4*2,0x4327
#define INA2XX_CONFIG_DEFAULT	0x4327	
#endif
/***************************************************************************
	Function		:static int INA2XX_StartWrite(uint32_t uiPort,uint32_t uiLen,unsigned char *pucFrame)		 	
	Description		:I2C START WRITE FRAME
	Input Parameter	:
	Output Parameter:   
	Who	Make it	?	:LiuF        		
	History			:							Date/Time:12-03-2013 
****************************************************************************/
static int INA2XX_StartWrite(uint32_t uiPort,unsigned char *pucFrame,uint32_t uiLen)		 
{
	int ret = 0;
    _srtI2CBase *psrtBase;
	
	unsigned char ucSlaveAddr = INA2XX_SLAVE_ADDR;
	
	psrtBase = &CHIP_IIC_GetInfor()->Port1;
	psrtBase += (uiPort >> 1); 
	
	if(NULL != psrtBase)
	{
		if((uiPort % 2) > 0)
		{
			ucSlaveAddr = INA2XX_SLAVE_ADDR_MODULE1;
		}
	    ret = CHIP_IIC_Start(psrtBase,ucSlaveAddr);
	
	    if(ret < 0)
		{}
	
	    ret = CHIP_IIC_WriteFrame(psrtBase,pucFrame,uiLen);

	    if(ret < 0)
		{}
	
        CHIP_IIC_Stop(psrtBase);
		
		return 1;
	}
	
	return -1;
}
/******************************************************************************
	Function		: static int  INA2XX_StartRead(uint8_t ucReg, uint8_t *pucFrame)   
	Description		: read mutil DWord to memory
	Input Parameter	:    
	Output Parameter:   
	Who	Make it	?	:        		
	History			:							Date/Time:12-03-2013 
*******************************************************************************/
static int INA2XX_StartRead(uint32_t uiPort,uint8_t ucReg, uint8_t *pucFrame)
{
	int i = 0;
	int ret = 0;
	int retry = 3;
    _srtI2CBase *psrtBase;
	
	unsigned char ucSlaveAddr = INA2XX_SLAVE_ADDR;
	
	psrtBase = &CHIP_IIC_GetInfor()->Port1;
	psrtBase += (uiPort >> 1); 
	
	if(NULL != psrtBase)
	{
		if((uiPort % 2) > 0)
		{
			ucSlaveAddr = INA2XX_SLAVE_ADDR_MODULE1;
		}
		for(i = 0; i < retry; i++)
		{
			ret = CHIP_IIC_Start(psrtBase,ucSlaveAddr);
		
			if(ret < 0)
			{
				continue;
			}
		
			ret = CHIP_IIC_WriteFrame(psrtBase,&ucReg,1);
			if(ret < 0)
			{
				continue;
			}	
		
			ret = CHIP_IIC_StartAgain(psrtBase,ucSlaveAddr);
			if(ret < 0)
			{
				continue;
			}
		
			ret = CHIP_IIC_ReadFrame(psrtBase,pucFrame,2);
			if(ret < 0)
			{
				continue;
			}
			
			ret = CHIP_IIC_Stop(psrtBase);			
			if(ret < 0)
			{
				continue;
			}

            break;			
		}
		
		if(i >= retry)
		{
			return -1;
		}
		return 1;
	}
	
	return -1;
}

/***************************************************************************
    Function           :static int INA2XX_Calibrate(uint32_t uiPort,uint32_t uiShuntR,uint32_t uiIMaxExpected)
						 Calibration register is set to the best value, which eliminates
                         truncation errors on calculating current register in hardware.
                         According to datasheet (eq. 3) the best values are 2048 for
                         ina226 and 4096 for ina219. They are hardcoded as calibration_value.
                         Cal = 0.04096/Current_lsb*RShunt, \
                         current lsb = Maximum expected current / 2^15 \
                         power lsb = 20 * current lsb
    Description        :   
    Input Parameter    :    
    Output Parameter   :   
    Who Make it ?      :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
static int INA2XX_Calibrate(uint32_t uiPort,uint32_t uiShuntR,uint32_t uiIMaxExpected)
{
	unsigned char ucFrame[3];
    uint64_t uiTemp = 0;
	
#if defined (DEVICE_INA220)
	uiTemp = 4096;            //放大系数100000
#elif defined(DEVICE_INA226)
	uiTemp = 512;            //放大系数100000
#endif	

	uiTemp *= 1000;           //此处由于0.04096放大了100000倍，同时电流值默认采用mA(1000)，电阻采用毫欧姆,故需要调整放大系数
	uiTemp *= 1000;
	uiTemp /= 100000;
	
	uiTemp <<= 15;
	uiTemp /= uiIMaxExpected;	
	uiTemp /= uiShuntR;	

	ucFrame[0] = INA2XX_CALIBRATION;
	ucFrame[1] = ((uiTemp & 0xFFFF) >> 8) & 0xFF;
	ucFrame[2] = ((uiTemp & 0xFFFF) >> 0) & 0xFF;
	
	return INA2XX_StartWrite(uiPort,ucFrame,sizeof(ucFrame));
}

/***************************************************************************
    Function           :int INA2XX_Init(uint32_t uiPort,uint32_t uiShuntR,uint32_t uiIMaxExpected)
    Description        :Initialize the configuration and calibration registers.
    Input Parameter    :    
    Output Parameter   :   
    Who Make it ?      :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int INA2XX_Init(uint32_t uiPort,uint32_t uiShuntR,uint32_t uiIMaxExpected)
{
	int ret = 0;
	unsigned char ucFrame[3];
	
	ucFrame[0] = INA2XX_CONFIG;
	ucFrame[1] = ((INA2XX_CONFIG_DEFAULT & 0xFFFF) >> 8) & 0xFF;
	ucFrame[2] = ((INA2XX_CONFIG_DEFAULT & 0xFFFF) >> 0) & 0xFF;
	
	ret =  INA2XX_StartWrite(uiPort,ucFrame,sizeof(ucFrame));
	if (ret < 0)
		return ret;
	
	ucFrame[0] = INA2XX_ALERT;
	ucFrame[1] = ((0x0FFF) >> 8) & 0xFF;
	ucFrame[2] = ((0xFFFF) >> 0) & 0xFF;
	
	INA2XX_StartWrite(uiPort,ucFrame,sizeof(ucFrame));
	
	return INA2XX_Calibrate(uiPort,uiShuntR,uiIMaxExpected);
}
/***************************************************************************
    Function           :static int INA2XX_ReadReg(uint32_t uiPort,unsigned char reg,uint32_t *puiValue)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who Make it ?      :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
static int INA2XX_ReadReg(uint32_t uiPort ,unsigned char reg,uint32_t *puiValue)
{
	int ret = 0;
	uint32_t uiValue = 0;
	unsigned char ucFrame[2];

	ret = INA2XX_StartRead(uiPort,reg, ucFrame);
	if (ret < 0)
		return ret;
	
	uiValue = ucFrame[0];
	uiValue <<= 8;
	uiValue |= ucFrame[1];

	*puiValue = uiValue;
	return 1;
}
/***************************************************************************
    Function           :int INA2XX_GetVoltage(uint32_t uiPort,uint32_t *puiValue)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who Make it ?      :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int INA2XX_GetVoltage(uint32_t uiPort,uint32_t *puiValue)
{
	int val = 0;
	uint32_t uiValue = 0;

	val = INA2XX_ReadReg(uiPort,INA2XX_BUS_VOLTAGE,&uiValue);
	if(val)
	{
#if defined (DEVICE_INA220)
		uiValue >>= 3;           //OVF--bit0
		*puiValue = uiValue * 4; //config->bus_voltage_lsb,4mV
#elif defined(DEVICE_INA226)
		uiValue *= 125;
    uiValue /= 100;          //config->bus_voltage_lsb,1.25mV

#endif
	}
	return uiValue;
}
/***************************************************************************
    Function           :int INA2XX_GetShuntVoltage(uint32_t uiPort,uint32_t *puiValue)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who Make it ?      :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int INA2XX_GetShuntVoltage(uint32_t uiPort,uint32_t *puiValue)
{
	int val = 0;
	uint32_t uiValue = 0;

	// val = (s16)regval * data->shunt_lsb_uV;
	val = INA2XX_ReadReg(uiPort,INA2XX_SHUNT_VOLTAGE,&uiValue);
	if(val)
	{
		if(uiValue & 0x8000)
		{
			uiValue = 0 - uiValue;
		}
#if defined (DEVICE_INA220)
		*puiValue = (uiValue & 0xFFFF) * 10; //config->shunt_lsb_uV,10uV
#elif defined(DEVICE_INA226)
		uiValue &= 0xFFFF;
		uiValue *= 25;
		uiValue /= 10;
//		*puiValue = uiValue; //config->shunt_lsb_uV,2.5uV
#endif		
	}
	return uiValue;
}
/***************************************************************************
    Function           :int INA2XX_SetAlarmLimit(uint32_t uiPort,uint32_t uiVoltage,uint32_t uiCurrent,uint32_t uiExpected)
    Description        :uiCurrent,keep one point
    Input Parameter    :    
    Output Parameter   :   
    Who Make it ?      :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int INA2XX_SetAlarmLimit(uint32_t uiPort,uint32_t uiVoltage,uint32_t uiCurrent,uint32_t uiExpected)
{
	uint64_t uliValue = 0;
	unsigned char ucFrame[3];

	//power = v*a
	uliValue = uiCurrent;	
	uliValue += 5;
	uliValue /= 10;	
	uliValue *= uiVoltage;
	
	//power = powerreg * 25 * current lsb
	//powerreg = power /25/currentlsb
	//powerreg = power / 25 /expected*32768
	
	uliValue *= 32768;
	uliValue /= 25;
	uliValue /= uiExpected;
	
	uliValue /= 100;  //voltage(mV) 
	uliValue += 5;
	uliValue /= 10;

	ucFrame[0] = INA2XX_ALERT;
	ucFrame[1] = ((uliValue & 0xFFFF) >> 8) & 0xFF;
	ucFrame[2] = ((uliValue & 0xFFFF) >> 0) & 0xFF;
	
	INA2XX_StartWrite(uiPort,ucFrame,sizeof(ucFrame));
	
	uliValue = 0X0800; //POWER ALARM
	ucFrame[0] = INA2XX_MASK_ENABLE;
	ucFrame[1] = ((uliValue & 0xFFFF) >> 8) & 0xFF;
	ucFrame[2] = ((uliValue & 0xFFFF) >> 0) & 0xFF;
	
	return INA2XX_StartWrite(uiPort,ucFrame,sizeof(ucFrame));	
}
/***************************************************************************
    Function           :int INA2XX_GetShuntCurrent(uint32_t uiPort,uint32_t *puiValue)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who Make it ?      :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int INA2XX_GetShuntCurrent(uint32_t uiPort,uint32_t *puiValue)
{
	int val = 0;
	uint32_t uiValue = 0;

	// signed register, result in mA \
	Shunt voltage is calculated by multiplying the Shunt Voltage Register \
	contents with the Shunt Voltage LSB of 10μV. \
	current register = Shunt voltage register * calibration register / 4096
	
	// val = (s16)regval * data->current_lsb_uA;
	val = INA2XX_ReadReg(uiPort,INA2XX_CURRENT,&uiValue);
	if(val)
	{
		if(uiValue & 0x8000)
		{
			uiValue = 0 - uiValue;
		}
		*puiValue = (uiValue & 0xFFFF) * 10; //,保留一位小数点 \
		                            * config->current_lsb_uA,imaxexpected / 2^15;
	}
	return val;
}
/***************************************************************************
    Function           :int INA2XX_GetPower(uint32_t uiPort,uint32_t *puiValue)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who Make it ?      :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int INA2XX_GetPower(uint32_t uiPort,uint32_t *puiValue)
{
	int val = 0;
	uint32_t uiValue = 0;

	// val = (s16)regval * data->power_lsb_mW;
	val = INA2XX_ReadReg(uiPort,INA2XX_POWER,&uiValue);
	if(val)
	{
		*puiValue = uiValue; //LSB,=25 times current lsb	
	}
	return val;
}
