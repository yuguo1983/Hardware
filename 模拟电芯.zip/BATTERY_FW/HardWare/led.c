/* Includes ------------------------------------------------------------------*/
#include "include.h"

void run_led_on(void)
{
	HAL_GPIO_WritePin(GPIOC, RUN_LED_Pin, GPIO_PIN_RESET);
}
void run_led_off(void)
{
	HAL_GPIO_WritePin(GPIOC, RUN_LED_Pin, GPIO_PIN_SET);
}
void err_led_on(void)
{
	HAL_GPIO_WritePin(GPIOA, ERR_LED_Pin, GPIO_PIN_RESET);
}
void err_led_off(void)
{
	HAL_GPIO_WritePin(GPIOA, ERR_LED_Pin, GPIO_PIN_SET);
}


