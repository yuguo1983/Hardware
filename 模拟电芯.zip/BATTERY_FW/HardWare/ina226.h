#ifndef __INA226_H
#define __INA226_H
#include "include.h"


/////////////////////////////////////////////////////////////////
/////														/////
/////////////////////////////////////////////////////////////////


#define 	CH1_ALERT 		
#define 	CFG_REG	 		0x00
#define 	SV_REG 			0x01
#define 	BV_REG 			0x02
#define 	PWR_REG 		0x03
#define 	CUR_REG 		0x04
#define 	CAL_REG 		0x05
#define 	ONFF_REG 		0x06
#define 	AL_REG 			0x07
#define   ONE_ADDR				(0x40<<1 )
#define   TWO_ADDR				(0x41<<1 )



#define   	INA226_GETALADDR	0x14 

extern  uint32_t check_time;
extern  uint32_t led_count;

void INA226_Init(void);
void INA226_SetRegPointer(uint8_t addr,uint8_t reg);
void INA226_SendData(uint8_t addr,uint8_t reg,uint16_t data);
uint16_t INA226_ReadData(uint8_t addr);
uint8_t INA226_AlertAddr(void);
uint16_t INA226_GetCurrent(uint8_t addr);
uint16_t INA226_GetVoltage(uint8_t addr);

uint16_t INA226_GetShuntVoltage(uint8_t addr);

void test_fuc(void);

#endif

