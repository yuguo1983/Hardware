/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DAC7512_H
#define __DAC7512_H


/* Includes ------------------------------------------------------------------*/

#include "main.h"
#include "include.h"

#define SCLK_0 	(GPIOB->BSRR= (uint32_t)GPIO_PIN_13<<16U) 
#define SCLK_1   (GPIOB->BSRR= GPIO_PIN_13 )

#define DIN_0 	(GPIOB->BSRR= (uint32_t)GPIO_PIN_15<<16U) 
#define DIN_1 	(GPIOB->BSRR= GPIO_PIN_15 )

#define SYNC_0  (GPIOB->BSRR= (uint32_t)GPIO_PIN_12<<16U) 
#define SYNC_1  (GPIOB->BSRR= GPIO_PIN_12 )



#define SCLK1_0 	(GPIOB->BSRR= (uint32_t)GPIO_PIN_0<<16U) 
#define SCLK1_1   (GPIOB->BSRR= GPIO_PIN_0)

#define DIN1_0 	(GPIOB->BSRR= (uint32_t)GPIO_PIN_1<<16U) 
#define DIN1_1 	(GPIOB->BSRR= GPIO_PIN_1 )

#define SYNC1_0  (GPIOA->BSRR= (uint32_t)GPIO_PIN_0<<16U) 
#define SYNC1_1  (GPIOA->BSRR= GPIO_PIN_0 )
typedef enum
{
	NORMAL 	= 	0x00,
	PW_1K		=		0x01,
	PW_100K	=		0x01,
  HZ			=		0x03
}DAC7512_MODE;

void dac7512_hw_init(void);
void dac7512_write_dac(uint16_t value,uint8_t mode);
void set_vol(uint16_t voltege);

void set_vol1(uint16_t voltege);
void dac7512_write_dac1(uint16_t value,uint8_t mode);
uint64_t CALIB_VOutToDACCode(int64_t uiValue);

#endif



