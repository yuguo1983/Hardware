/***************************************************************
  ModBus读写操作的四个函数
  eMBRegInputCB eMBRegHoldingCB
  eMBRegCoilsCB	eMBRegDiscreteCB
**************************************************************/
#include "mb.h"
#include "mbport.h"
#include "include.h"
#include "app.h"


uint16_t VoltegeOne=0;
uint16_t VoltegeTwo=0;


uint32_t idAddr[]={
	0x1FFFF7AC,  /*STM32F0唯一ID起始地址*/
	0x1FFFF7E8,  /*STM32F1唯一ID起始地址*/
	0x1FFF7A10,  /*STM32F2唯一ID起始地址*/
	0x1FFFF7AC,  /*STM32F3唯一ID起始地址*/
	0x1FFF7A10,  /*STM32F4唯一ID起始地址*/
	0x1FF0F420,  /*STM32F7唯一ID起始地址*/
	0x1FF80050,  /*STM32L0唯一ID起始地址*/
	0x1FF80050,  /*STM32L1唯一ID起始地址*/
	0x1FFF7590   /*STM32L4唯一ID起始地址*/
};

uint32_t GetSTM32ID(void)
{
	uint32_t id[3];
    id[0]=*(uint32_t*)(idAddr[0]);
    id[1]=*(uint32_t*)(idAddr[0]+4);
    id[2]=*(uint32_t*)(idAddr[0]+8);
	return id[0];
}

//Modbus规定寄存器起始地址为1
#define REG_INPUT_START 5001
#define REG_INPUT_NREGS 5008
#define REG_HOLDING_START 5011
#define REG_HOLDING_NREGS 5100

USHORT usRegInputBuf[8];
USHORT usRegHoldingBuf[100];

//读输入寄存器 功能码0x04
eMBErrorCode
eMBRegInputCB(UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNRegs)
{
	eMBErrorCode eStatus = MB_ENOERR;
	int iRegIndex;

	if ((usAddress >= REG_INPUT_START) && (usAddress + usNRegs <= REG_INPUT_START + REG_INPUT_NREGS))
	{
		iRegIndex = (int)(usAddress - REG_INPUT_START);

		//拷贝用户空间到缓冲区
		uint32_t SN = 0x1FFF7A10;
		usRegInputBuf[0] = 0x4C47;//"LG"
		usRegInputBuf[1] = 0x4B4A;//"KJ"
		usRegInputBuf[2] = 0x2107;//VID
		usRegInputBuf[3] = 60;//PID
		usRegInputBuf[4] = 0x0100;//HW Version
		usRegInputBuf[5] = 0x0101;//SW Version
		usRegInputBuf[6] = SN >> 16;
		usRegInputBuf[7] = SN;

		while (usNRegs > 0)
		{
			*pucRegBuffer++ = (unsigned char)(usRegInputBuf[iRegIndex] >> 8);	//PDU的先输出reg的高位；
			*pucRegBuffer++ = (unsigned char)(usRegInputBuf[iRegIndex] & 0xFF); //再输出低位；
			iRegIndex++;
			usNRegs--;
		}
	}
	else
	{
		eStatus = MB_ENOREG;
	}
	return eStatus;
}

//读写保持寄存器 功能码读0x03写0x06
eMBErrorCode
eMBRegHoldingCB(UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNRegs, eMBRegisterMode eMode)
{
	eMBErrorCode eStatus = MB_ENOERR;
	int iRegIndex;
	uint32_t * temp;

	if ((usAddress >= REG_HOLDING_START) && (usAddress + usNRegs <= REG_HOLDING_START + REG_HOLDING_NREGS))
	{
		iRegIndex = (int)(usAddress - REG_HOLDING_START);
		switch (eMode)
		{
		case MB_REG_READ:

			usRegHoldingBuf[0] = VoltegeOne;
			usRegHoldingBuf[1] = VoltegeTwo;
		
		
		
		
		  usRegHoldingBuf[10] = INA2XX_GetVoltage(0,temp);
			usRegHoldingBuf[11] = INA2XX_GetShuntVoltage(0,temp)/52;
		  usRegHoldingBuf[12] = INA2XX_GetVoltage(1,temp);
			usRegHoldingBuf[13] = INA2XX_GetShuntVoltage(1,temp)/51;	
			while (usNRegs > 0)
			{
				*pucRegBuffer++ = (unsigned char)(usRegHoldingBuf[iRegIndex] >> 8);
				*pucRegBuffer++ = (unsigned char)(usRegHoldingBuf[iRegIndex] & 0xFF);
				iRegIndex++;
				usNRegs--;
			}
			break;

		case MB_REG_WRITE:
			while (usNRegs > 0)
			{
				usRegHoldingBuf[iRegIndex] = (*pucRegBuffer++) << 8;
				usRegHoldingBuf[iRegIndex] |= *pucRegBuffer++;
				iRegIndex++;
				usNRegs--;
			}
			VoltegeOne = usRegHoldingBuf[0];
			VoltegeTwo = usRegHoldingBuf[1];
//			setMuxConfig(muxValue);
//			setBoardConnectConfig(conValue);
		}
	}
	else
	{
		eStatus = MB_ENOREG;
	}
	return eStatus;
}

//读写线圈/离散输出寄存器 功能码读0x01写0x05
eMBErrorCode
eMBRegCoilsCB(UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNCoils, eMBRegisterMode eMode)
{
	(void)pucRegBuffer;
	(void)usAddress;
	(void)usNCoils;
	(void)eMode;
	return MB_ENOREG;
}

//读离散输入寄存器 功能码0x02
eMBErrorCode
eMBRegDiscreteCB(UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNDiscrete)
{
	(void)pucRegBuffer;
	(void)usAddress;
	(void)usNDiscrete;
	return MB_ENOREG;
}
