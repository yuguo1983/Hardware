/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __BSP_GPIO_H
#define __BSP_GPIO_H


/* Includes ------------------------------------------------------------------*/
#include "stm32f2xx_hal.h"
#include "main.h"
#include "gpio.h"

#define IN_G4_A0_Pin GPIO_PIN_2
#define IN_G4_A0_GPIO_Port GPIOE
#define OUT_G4_A1_Pin GPIO_PIN_3
#define OUT_G4_A1_GPIO_Port GPIOE
#define OUT_G4_A0_Pin GPIO_PIN_4
#define OUT_G4_A0_GPIO_Port GPIOE
#define IN_G5_A1_Pin GPIO_PIN_5
#define IN_G5_A1_GPIO_Port GPIOE
#define IN_G5_A0_Pin GPIO_PIN_6
#define IN_G5_A0_GPIO_Port GPIOE
#define CU_SW5_A1_Pin GPIO_PIN_13
#define CU_SW5_A1_GPIO_Port GPIOC
#define CU_LD5_A0_Pin GPIO_PIN_14
#define CU_LD5_A0_GPIO_Port GPIOC
#define CU_LD5_A1_Pin GPIO_PIN_15
#define CU_LD5_A1_GPIO_Port GPIOC
#define CU_LD2_A0_Pin GPIO_PIN_0
#define CU_LD2_A0_GPIO_Port GPIOF
#define CU_SW9_A0_Pin GPIO_PIN_1
#define CU_SW9_A0_GPIO_Port GPIOF
#define E2PROM_SCL_Pin GPIO_PIN_2
#define E2PROM_SCL_GPIO_Port GPIOF
#define E2PROM_SDA_Pin GPIO_PIN_3
#define E2PROM_SDA_GPIO_Port GPIOF
#define RUN_LED_Pin GPIO_PIN_4
#define RUN_LED_GPIO_Port GPIOF
#define ERR_LED_Pin GPIO_PIN_5
#define ERR_LED_GPIO_Port GPIOF
#define SPI1_CS2_Pin GPIO_PIN_6
#define SPI1_CS2_GPIO_Port GPIOF
#define SPI1_CS3_Pin GPIO_PIN_7
#define SPI1_CS3_GPIO_Port GPIOF
#define SPI1_CS4_Pin GPIO_PIN_8
#define SPI1_CS4_GPIO_Port GPIOF
#define SPI1_CS5_Pin GPIO_PIN_9
#define SPI1_CS5_GPIO_Port GPIOF
#define KEY1_Pin GPIO_PIN_10
#define KEY1_GPIO_Port GPIOF
#define CU_SW2_A0_Pin GPIO_PIN_0
#define CU_SW2_A0_GPIO_Port GPIOC
#define CU_SW2_A1_Pin GPIO_PIN_1
#define CU_SW2_A1_GPIO_Port GPIOC
#define KEY2_Pin GPIO_PIN_0
#define KEY2_GPIO_Port GPIOA
#define R485_EN_Pin GPIO_PIN_1
#define R485_EN_GPIO_Port GPIOA
#define SPI1_CS1_Pin GPIO_PIN_4
#define SPI1_CS1_GPIO_Port GPIOA
#define CU_SW3_A0_Pin GPIO_PIN_4
#define CU_SW3_A0_GPIO_Port GPIOC
#define CU_SW3_A1_Pin GPIO_PIN_5
#define CU_SW3_A1_GPIO_Port GPIOC
#define CU_SW6_A0_Pin GPIO_PIN_0
#define CU_SW6_A0_GPIO_Port GPIOB
#define CU_SW6_A1_Pin GPIO_PIN_1
#define CU_SW6_A1_GPIO_Port GPIOB
#define ADC_INT1_Pin GPIO_PIN_11
#define ADC_INT1_GPIO_Port GPIOF
#define ADC_INT2_Pin GPIO_PIN_12
#define ADC_INT2_GPIO_Port GPIOF
#define ADC_INT2F13_Pin GPIO_PIN_13
#define ADC_INT2F13_GPIO_Port GPIOF
#define ADC_INT4_Pin GPIO_PIN_14
#define ADC_INT4_GPIO_Port GPIOF
#define ADC_INT5_Pin GPIO_PIN_15
#define ADC_INT5_GPIO_Port GPIOF
#define OUT_G7_A0_Pin GPIO_PIN_0
#define OUT_G7_A0_GPIO_Port GPIOG
#define IN_G8_A1_Pin GPIO_PIN_1
#define IN_G8_A1_GPIO_Port GPIOG
#define OUT_G5_A1_Pin GPIO_PIN_7
#define OUT_G5_A1_GPIO_Port GPIOE
#define OUT_G5_A0_Pin GPIO_PIN_8
#define OUT_G5_A0_GPIO_Port GPIOE
#define IN_G6_A1_Pin GPIO_PIN_9
#define IN_G6_A1_GPIO_Port GPIOE
#define IN_G6_A0_Pin GPIO_PIN_10
#define IN_G6_A0_GPIO_Port GPIOE
#define OUT_G6_A1_Pin GPIO_PIN_11
#define OUT_G6_A1_GPIO_Port GPIOE
#define OUT_G6_A0_Pin GPIO_PIN_12
#define OUT_G6_A0_GPIO_Port GPIOE
#define IN_G7_A1_Pin GPIO_PIN_13
#define IN_G7_A1_GPIO_Port GPIOE
#define IN_G7_A0_Pin GPIO_PIN_14
#define IN_G7_A0_GPIO_Port GPIOE
#define OUT_G7_A1_Pin GPIO_PIN_15
#define OUT_G7_A1_GPIO_Port GPIOE
#define CU_LD8_A1_Pin GPIO_PIN_12
#define CU_LD8_A1_GPIO_Port GPIOB
#define CU_SW9_A1_Pin GPIO_PIN_14
#define CU_SW9_A1_GPIO_Port GPIOB
#define CU_LD9_A0_Pin GPIO_PIN_15
#define CU_LD9_A0_GPIO_Port GPIOB
#define OUT_G1_A0_Pin GPIO_PIN_8
#define OUT_G1_A0_GPIO_Port GPIOD
#define IN_G2_A1_Pin GPIO_PIN_9
#define IN_G2_A1_GPIO_Port GPIOD
#define IN_G2_A0_Pin GPIO_PIN_10
#define IN_G2_A0_GPIO_Port GPIOD
#define OUT_G2_A1_Pin GPIO_PIN_11
#define OUT_G2_A1_GPIO_Port GPIOD
#define OUT_G2_A0_Pin GPIO_PIN_12
#define OUT_G2_A0_GPIO_Port GPIOD
#define IN_G3_A1_Pin GPIO_PIN_13
#define IN_G3_A1_GPIO_Port GPIOD
#define IN_G3_A0_Pin GPIO_PIN_14
#define IN_G3_A0_GPIO_Port GPIOD
#define OUT_G3_A1_Pin GPIO_PIN_15
#define OUT_G3_A1_GPIO_Port GPIOD
#define IN_G8_A0_Pin GPIO_PIN_2
#define IN_G8_A0_GPIO_Port GPIOG
#define OUT_G8_A1_Pin GPIO_PIN_3
#define OUT_G8_A1_GPIO_Port GPIOG
#define OUT_G8_A0_Pin GPIO_PIN_4
#define OUT_G8_A0_GPIO_Port GPIOG
#define IN_G9_A1_Pin GPIO_PIN_5
#define IN_G9_A1_GPIO_Port GPIOG
#define IN_G9_A0_Pin GPIO_PIN_6
#define IN_G9_A0_GPIO_Port GPIOG
#define OUT_G9_A1_Pin GPIO_PIN_7
#define OUT_G9_A1_GPIO_Port GPIOG
#define OUT_G9_A0_Pin GPIO_PIN_8
#define OUT_G9_A0_GPIO_Port GPIOG
#define CU_LD3_A0_Pin GPIO_PIN_6
#define CU_LD3_A0_GPIO_Port GPIOC
#define CU_LD3_A1_Pin GPIO_PIN_7
#define CU_LD3_A1_GPIO_Port GPIOC
#define CU_SW4_A0_Pin GPIO_PIN_8
#define CU_SW4_A0_GPIO_Port GPIOC
#define CU_SW4_A1_Pin GPIO_PIN_9
#define CU_SW4_A1_GPIO_Port GPIOC
#define CU_SW1_A0_Pin GPIO_PIN_8
#define CU_SW1_A0_GPIO_Port GPIOA
#define CU_SW1_A1_Pin GPIO_PIN_11
#define CU_SW1_A1_GPIO_Port GPIOA
#define CU_LD1_A0_Pin GPIO_PIN_12
#define CU_LD1_A0_GPIO_Port GPIOA
#define CU_LD1_A1_Pin GPIO_PIN_15
#define CU_LD1_A1_GPIO_Port GPIOA
#define CU_LD4_A0_Pin GPIO_PIN_10
#define CU_LD4_A0_GPIO_Port GPIOC
#define CU_LD4_A1_Pin GPIO_PIN_11
#define CU_LD4_A1_GPIO_Port GPIOC
#define CU_SW5_A0_Pin GPIO_PIN_12
#define CU_SW5_A0_GPIO_Port GPIOC
#define CU_LD9_A1_Pin GPIO_PIN_0
#define CU_LD9_A1_GPIO_Port GPIOD
#define CU_SW10_A0_Pin GPIO_PIN_1
#define CU_SW10_A0_GPIO_Port GPIOD
#define CU_SW10_A1_Pin GPIO_PIN_2
#define CU_SW10_A1_GPIO_Port GPIOD
#define CU_LD10_A0_Pin GPIO_PIN_3
#define CU_LD10_A0_GPIO_Port GPIOD
#define CU_LD10_A1_Pin GPIO_PIN_4
#define CU_LD10_A1_GPIO_Port GPIOD
#define IN_G1_A1_Pin GPIO_PIN_5
#define IN_G1_A1_GPIO_Port GPIOD
#define IN_G1_A0_Pin GPIO_PIN_6
#define IN_G1_A0_GPIO_Port GPIOD
#define OUT_G1_A1_Pin GPIO_PIN_7
#define OUT_G1_A1_GPIO_Port GPIOD
#define IN_G10_A1_Pin GPIO_PIN_9
#define IN_G10_A1_GPIO_Port GPIOG
#define IN_G10_A0_Pin GPIO_PIN_10
#define IN_G10_A0_GPIO_Port GPIOG
#define OUT_G10_A1_Pin GPIO_PIN_11
#define OUT_G10_A1_GPIO_Port GPIOG
#define OUT_G10_A0_Pin GPIO_PIN_12
#define OUT_G10_A0_GPIO_Port GPIOG
#define CU_SW8_A1_Pin GPIO_PIN_13
#define CU_SW8_A1_GPIO_Port GPIOG
#define CU_LD8_A0_Pin GPIO_PIN_14
#define CU_LD8_A0_GPIO_Port GPIOG
#define CU_LD2_A1_Pin GPIO_PIN_15
#define CU_LD2_A1_GPIO_Port GPIOG
#define CU_LD6_A0_Pin GPIO_PIN_3
#define CU_LD6_A0_GPIO_Port GPIOB
#define CU_LD6_A1_Pin GPIO_PIN_4
#define CU_LD6_A1_GPIO_Port GPIOB
#define CU_SW7_A0_Pin GPIO_PIN_5
#define CU_SW7_A0_GPIO_Port GPIOB
#define CU_SW7_A1_Pin GPIO_PIN_6
#define CU_SW7_A1_GPIO_Port GPIOB
#define CU_LD7_A0_Pin GPIO_PIN_7
#define CU_LD7_A0_GPIO_Port GPIOB
#define CU_LD7_A1_Pin GPIO_PIN_8
#define CU_LD7_A1_GPIO_Port GPIOB
#define CU_SW8_A0_Pin GPIO_PIN_9
#define CU_SW8_A0_GPIO_Port GPIOB
#define OUT_G3_A0_Pin GPIO_PIN_0
#define OUT_G3_A0_GPIO_Port GPIOE
#define IN_G4_A1_Pin GPIO_PIN_1
#define IN_G4_A1_GPIO_Port GPIOE
void bsp_gpio_init(void);










#endif 



