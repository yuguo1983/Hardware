/* Includes ------------------------------------------------------------------*/
#include "include.h"
_Sys_par  sys_par;

#define ADDR0() HAL_GPIO_ReadPin(GPIOF, GPIO_PIN_10)
#define ADDR1() HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0)
void mb_100ms(void);
extern uint8_t  ms_100_flag;

_Mult_port mult_port={0};
uint8_t APP_FLAG =  0;
uint8_t io_stata=0;
const uint8_t TEXT_Buffer[]={"test 24c02 IIC TEST\r\n"};
#define SIZE sizeof(TEXT_Buffer)

uint8_t getModBusAddressConfig(void)
{
	return (ADDR0() << 1 | ADDR1());
}

void sys_init(void)
{
	sys_par.rs485_addr=getModBusAddressConfig();
	sys_par.rs485_Baud=19200;

}



void bsp_init(void)
{
	sys_init();
	bsp_gpio_init();	

//  ads1256Init();
//	bsp_InitTimer();
	thread_init();
}

extern _port_number  port_number;

void app(void)
{
	uint32_t temp=0;
//  bsp_init();
	MEMORY_Init();
	CALIB_THREAD_Init();
  temp=W25Q_ReadManuID_DeviceID(0);
	printf("0x:%x   \r\n",temp);
	temp=spiReadRegData(0,IO);
	printf("0x:%x   \r\n",temp);
	temp=port_number.port2.GAIN_TYPE;
	printf("GAIN_TYPE 0x:%x   \r\n",temp);
	temp=port_number.port2.RANGE_TYPE;
	printf("GAIN_TYPE 0x:%x   \r\n",temp);
	

}




_DataType *Mult_THREAD_GetInfor(uint32_t uiPort)
{
	_DataType    *psrtBase;
	if(uiPort > MAX_PORT)
	{
	    return NULL;
	}
	
	psrtBase = &(mult_port.port1);
	psrtBase += uiPort;
	
	return psrtBase;
}


