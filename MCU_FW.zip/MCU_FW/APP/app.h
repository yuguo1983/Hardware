/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __APP_H
#define __APP_H


/* Includes ------------------------------------------------------------------*/
#include "stm32f2xx_hal.h"
#include "main.h"
#include "include.h"
typedef struct {
uint32_t rs485_addr;
uint32_t rs485_Baud;



}_Sys_par;



typedef enum{
WORK_STATUS,
CLIB_STATUS,
}_Enum_status;







typedef struct{
int32_t	Itype;	
int32_t Vvalue;
int32_t Avalue;
int32_t mAvalue;
int32_t uAvalue;	
}_DataType ;


typedef struct{
_DataType port1;
_DataType port2;
_DataType port3;
_DataType port4;
//_DataType port5;
//_DataType port6;
//_DataType port7;
//_DataType port8;
//_DataType port9;
//_DataType port10;
//_DataType port11;
//_DataType port12;
//_DataType port13;
//_DataType port14;
//_DataType port15;
//_DataType port16;
//_DataType port17;
//_DataType port18;
//_DataType port19;
//_DataType port20;
}_Mult_port;


/****************************����������************************/



_DataType *Mult_THREAD_GetInfor(uint32_t uiPort);


extern uint8_t io_stata;


void app(void);
void Multimeter1_ON(void);
void Multimeter1_OFF(void);
void Multimeter2_ON(void);
void Multimeter2_OFF(void);
void LOAD1_ON(void);
void LOAD1_OFF(void);	
void LOAD2_ON(void);
void LOAD2_OFF(void);
void UpData(void);
uint8_t getModBusAddressConfig(void);
void bsp_init(void);
void sys_init(void);
#endif






