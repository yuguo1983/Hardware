/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "include.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */
osThreadId defaultTaskHandle;
osThreadId myappHandle;
osThreadId myuartHandle;
uint32_t uartBuffer[ 128 ];
osStaticThreadDef_t uartControlBlock;
osThreadId myledHandle;
osThreadId mymbHandle;
osMessageQId myQueue01Handle;
osMessageQId myQueue02Handle;
extern TIM_HandleTypeDef htim3;
/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void const * argument);
void userapp(void const * argument);
void uart(void const * argument);
void led(void const * argument);
void mb_app(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* GetIdleTaskMemory prototype (linked to static allocation support) */
void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize );

/* Hook prototypes */
void configureTimerForRunTimeStats(void);
unsigned long getRunTimeCounterValue(void);

void init_timer1_for_runtime_state(void);
#define TIMER1_TC         ( * ( ( volatile uint32_t * )0x40008008 ) )
/* USER CODE BEGIN 1 */
/* Functions needed when configGENERATE_RUN_TIME_STATS is on */
void configureTimerForRunTimeStats(void)
{
init_timer1_for_runtime_state();
}

unsigned long getRunTimeCounterValue(void)
{
	
return TIMER1_TC;
}


void init_timer1_for_runtime_state(void)
{
HAL_TIM_Base_Start(&htim3);
}

/* USER CODE END 1 */

/* USER CODE BEGIN GET_IDLE_TASK_MEMORY */
static StaticTask_t xIdleTaskTCBBuffer;
static StackType_t xIdleStack[configMINIMAL_STACK_SIZE];

void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize )
{
  *ppxIdleTaskTCBBuffer = &xIdleTaskTCBBuffer;
  *ppxIdleTaskStackBuffer = &xIdleStack[0];
  *pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;
  /* place for user code */
}




/* USER CODE END GET_IDLE_TASK_MEMORY */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* definition and creation of myQueue01 */
  osMessageQDef(myQueue01, 16, uint16_t);
  myQueue01Handle = osMessageCreate(osMessageQ(myQueue01), NULL);\
	if(myQueue01Handle!=NULL)
	{
		printf("CREATE myQueue01 SUCESSFUL!\r\n");
	}

  /* definition and creation of myQueue02 */
  osMessageQDef(myQueue02, 16, uint16_t);
  myQueue02Handle = osMessageCreate(osMessageQ(myQueue02), NULL);
	if(myQueue01Handle!=NULL)
	{
		printf("CREATE myQueue02 SUCESSFUL!\r\n");
	}
  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of defaultTask */
  osThreadDef(defaultTask, StartDefaultTask, osPriorityNormal, 0, 128);
  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);
	if(myQueue01Handle!=NULL)
	{
		printf("CREATE defaultTask SUCESSFUL!\r\n");
	}
  /* definition and creation of myapp */
  osThreadDef(myapp, userapp, osPriorityIdle, 0, 128);
  myappHandle = osThreadCreate(osThread(myapp), NULL);
	if(myQueue01Handle!=NULL)
	{
		printf("CREATE myapp SUCESSFUL!\r\n");
	}
  /* definition and creation of myuart */
  osThreadStaticDef(myuart, uart, osPriorityIdle, 0, 128, uartBuffer, &uartControlBlock);
  myuartHandle = osThreadCreate(osThread(myuart), NULL);
	if(myQueue01Handle!=NULL)
	{
		printf("CREATE myuart SUCESSFUL!\r\n");
	}
  /* definition and creation of myled */
  osThreadDef(myled, led, osPriorityIdle, 0, 128);
  myledHandle = osThreadCreate(osThread(myled), NULL);
	if(myQueue01Handle!=NULL)
	{
		printf("CREATE myled SUCESSFUL!\r\n");
	}
  /* definition and creation of mymb */
  osThreadDef(mymb, mb_app, 1, 0, 128);
  mymbHandle = osThreadCreate(osThread(mymb), NULL);
	if(myQueue01Handle!=NULL)
	{
		printf("CREATE mymb SUCESSFUL!\r\n");
	}
  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

}



/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void const * argument)
{
  /* USER CODE BEGIN StartDefaultTask */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END StartDefaultTask */
}

/* USER CODE BEGIN Header_userapp */
/**
* @brief Function implementing the myapp thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_userapp */
void userapp(void const * argument)
{
  /* USER CODE BEGIN userapp */
  /* Infinite loop */
	app();
  for(;;)
  {
		
    osDelay(1);
  }
  /* USER CODE END userapp */
}

/* USER CODE BEGIN Header_uart */
/**
* @brief Function implementing the myuart thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_uart */
void uart(void const * argument)
{
  /* USER CODE BEGIN uart */
  /* Infinite loop */
  for(;;)
  {
		HAL_GPIO_TogglePin(GPIOF, GPIO_PIN_5);
    osDelay(1000);
  }
  /* USER CODE END uart */
}

/* USER CODE BEGIN Header_led */
/**
* @brief Function implementing the myled thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_led */
void led(void const * argument)
{
  /* USER CODE BEGIN led */
  /* Infinite loop */
  for(;;)
  {
		HAL_GPIO_TogglePin(GPIOF, GPIO_PIN_4);
    osDelay(500);
  }
  /* USER CODE END led */
}

/* USER CODE BEGIN Header_mb_app */
/**
* @brief Function implementing the mymb thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_mb_app */
void mb_app(void const * argument)
{
  /* USER CODE BEGIN mb_app */
  /* Infinite loop */
	eMBInit( MB_RTU, 1, 0, 19200, MB_PAR_NONE);  //modbus init
  eMBEnable();
  for(;;)
  {
		printf("test\r\n");
		( void )eMBPoll(  );
    osDelay(20);
  }
  /* USER CODE END mb_app */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

