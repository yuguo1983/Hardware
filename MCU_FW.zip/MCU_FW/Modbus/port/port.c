/***************************************************************
  ModBus读写操作的四个函数
  eMBRegInputCB eMBRegHoldingCB
  eMBRegCoilsCB	eMBRegDiscreteCB
**************************************************************/
#include "mb.h"
#include "mbport.h"
#include "app.h"
#include "include.h"



#define  CLIBBASE         				(50)
#define  CLIBSTART         		 		CLIBBASE
#define  CLIBTYPE        		 			CLIBBASE+1
#define  CLIBRAIN         		 		CLIBBASE+2
#define  CLIBCHANEL        		 		CLIBBASE+3
#define  CLIBVALUE        		 		CLIBBASE+4




uint32_t idAddr[]={
	0x1FFFF7AC,  /*STM32F0唯一ID起始地址*/
	0x1FFFF7E8,  /*STM32F1唯一ID起始地址*/
	0x1FFF7A10,  /*STM32F2唯一ID起始地址*/
	0x1FFFF7AC,  /*STM32F3唯一ID起始地址*/
	0x1FFF7A10,  /*STM32F4唯一ID起始地址*/
	0x1FF0F420,  /*STM32F7唯一ID起始地址*/
	0x1FF80050,  /*STM32L0唯一ID起始地址*/
	0x1FF80050,  /*STM32L1唯一ID起始地址*/
	0x1FFF7590   /*STM32L4唯一ID起始地址*/
};

uint32_t GetSTM32ID(void)
{
	uint32_t id[3];
    id[0]=*(uint32_t*)(idAddr[0]);
    id[1]=*(uint32_t*)(idAddr[0]+4);
    id[2]=*(uint32_t*)(idAddr[0]+8);
	return id[0];
}

int32_t ALLDacValue[8]={0};


//Modbus规定寄存器起始地址为1
#define REG_INPUT_START 1001
#define REG_INPUT_NREGS 8
#define REG_HOLDING_START 1001
#define REG_HOLDING_NREGS 100

USHORT usRegInputBuf[8]={0};
USHORT usRegHoldingBuf[100]={0};
USHORT TempHoldingBuf[100]={0};
//读输入寄存器 功能码0x04
eMBErrorCode
eMBRegInputCB(UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNRegs)
{
	eMBErrorCode eStatus = MB_ENOERR;
	int iRegIndex;

	if ((usAddress >= REG_INPUT_START) && (usAddress + usNRegs <= REG_INPUT_START + REG_INPUT_NREGS))
	{
		iRegIndex = (int)(usAddress - REG_INPUT_START);

		//拷贝用户空间到缓冲区
		uint32_t SN = 0x1FFF7A10;
		usRegInputBuf[0] = 0x4C47;//"LG"
		usRegInputBuf[1] = 0x4B4A;//"KJ"
		usRegInputBuf[2] = 0x2107;//VID
		usRegInputBuf[3] = 0x0056;//PID
		usRegInputBuf[4] = 0x0100;//HW Version
		usRegInputBuf[5] = 0x0101;//SW Version
		usRegInputBuf[6] = SN >> 16;
		usRegInputBuf[7] = SN;

		while (usNRegs > 0)
		{
			*pucRegBuffer++ = (unsigned char)(usRegInputBuf[iRegIndex] >> 8);	//PDU的先输出reg的高位；
			*pucRegBuffer++ = (unsigned char)(usRegInputBuf[iRegIndex] & 0xFF); //再输出低位；
			iRegIndex++;
			usNRegs--;
		}
	}
	else
	{
		eStatus = MB_ENOREG;
	}
	return eStatus;
}

//读写保持寄存器 功能码读0x03写0x06
eMBErrorCode
eMBRegHoldingCB(UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNRegs, eMBRegisterMode eMode)
{
	eMBErrorCode eStatus = MB_ENOERR;
	int iRegIndex;
	uint8_t temp=0;
	
	

	if ((usAddress >= REG_HOLDING_START) && (usAddress + usNRegs <= REG_HOLDING_START + REG_HOLDING_NREGS))
	{
		iRegIndex = (int)(usAddress - REG_HOLDING_START);
		switch (eMode)
		{
		case MB_REG_READ:

//			usRegHoldingBuf[0] = ((CALIB_THREAD_VMonToValue(0,getVportvalue(0)))>0x7fffffff)?0:CALIB_THREAD_VMonToValue(0,getVportvalue(0));
//			usRegHoldingBuf[1] = ((CALIB_THREAD_VMonToValue(1,getVportvalue(1)))>0x7fffffff)?0:CALIB_THREAD_VMonToValue(1,getVportvalue(1));	
//			usRegHoldingBuf[2] = ((CALIB_THREAD_VMonToValue(2,getVportvalue(2)))>0x7fffffff)?0:CALIB_THREAD_VMonToValue(2,getVportvalue(2));
//			usRegHoldingBuf[3] = ((CALIB_THREAD_VMonToValue(3,getVportvalue(3)))>0x7fffffff)?0:CALIB_THREAD_VMonToValue(3,getVportvalue(3));
//			usRegHoldingBuf[4] = ((CALIB_THREAD_VMonToValue(4,getVportvalue(4)))>0x7fffffff)?0:CALIB_THREAD_VMonToValue(4,getVportvalue(4));
//			usRegHoldingBuf[5] = ((CALIB_THREAD_VMonToValue(5,getVportvalue(5)))>0x7fffffff)?0:CALIB_THREAD_VMonToValue(5,getVportvalue(5));
//			usRegHoldingBuf[6] = ((CALIB_THREAD_VMonToValue(6,getVportvalue(6)))>0x7fffffff)?0:CALIB_THREAD_VMonToValue(6,getVportvalue(6));		
//			usRegHoldingBuf[7] = ((CALIB_THREAD_VMonToValue(7,getVportvalue(7)))>0x7fffffff)?0:CALIB_THREAD_VMonToValue(7,getVportvalue(7));
//		  usRegHoldingBuf[8] = ((CALIB_THREAD_VMonToValue(8,getVportvalue(8)))>0x7fffffff)?0:CALIB_THREAD_VMonToValue(8,getVportvalue(8));
//			usRegHoldingBuf[9] = ((CALIB_THREAD_VMonToValue(9,getVportvalue(9)))>0x7fffffff)?0:CALIB_THREAD_VMonToValue(9,getVportvalue(9));
//			usRegHoldingBuf[10] = ((CALIB_THREAD_VMonToValue(10,getVportvalue(10)))>0x7fffffff)?0:CALIB_THREAD_VMonToValue(10,getVportvalue(10));
//			usRegHoldingBuf[11] = ((CALIB_THREAD_VMonToValue(11,getVportvalue(11)))>0x7fffffff)?0:CALIB_THREAD_VMonToValue(11,getVportvalue(11));
//			usRegHoldingBuf[12] = ((CALIB_THREAD_VMonToValue(12,getVportvalue(12)))>0x7fffffff)?0:CALIB_THREAD_VMonToValue(12,getVportvalue(12));
//			usRegHoldingBuf[13] = ((CALIB_THREAD_VMonToValue(13,getVportvalue(13)))>0x7fffffff)?0:CALIB_THREAD_VMonToValue(13,getVportvalue(13));
//			usRegHoldingBuf[14] = ((CALIB_THREAD_VMonToValue(14,getVportvalue(14)))>0x7fffffff)?0:CALIB_THREAD_VMonToValue(14,getVportvalue(14));
//			usRegHoldingBuf[15] = ((CALIB_THREAD_VMonToValue(15,getVportvalue(15)))>0x7fffffff)?0:CALIB_THREAD_VMonToValue(15,getVportvalue(15));
//			usRegHoldingBuf[16] = ((CALIB_THREAD_VMonToValue(16,getVportvalue(16)))>0x7fffffff)?0:CALIB_THREAD_VMonToValue(16,getVportvalue(16));
//			usRegHoldingBuf[17] = ((CALIB_THREAD_VMonToValue(17,getVportvalue(17)))>0x7fffffff)?0:CALIB_THREAD_VMonToValue(17,getVportvalue(17));
//			usRegHoldingBuf[18] = ((CALIB_THREAD_VMonToValue(18,getVportvalue(18)))>0x7fffffff)?0:CALIB_THREAD_VMonToValue(18,getVportvalue(18));
//			usRegHoldingBuf[19] = ((CALIB_THREAD_VMonToValue(19,getVportvalue(19)))>0x7fffffff)?0:CALIB_THREAD_VMonToValue(19,getVportvalue(19));
//		
//		  usRegHoldingBuf[20] =CALIB_THREAD_ImonToValue(0,getIportvalue(0));	
//			usRegHoldingBuf[21] =CALIB_THREAD_ImonToValue(1,getIportvalue(1));
//			usRegHoldingBuf[22] =CALIB_THREAD_ImonToValue(2,getIportvalue(2));	
//			usRegHoldingBuf[23] =CALIB_THREAD_ImonToValue(3,getIportvalue(3));
//			usRegHoldingBuf[24] =CALIB_THREAD_ImonToValue(4,getIportvalue(4));	
//			usRegHoldingBuf[25] =CALIB_THREAD_ImonToValue(5,getIportvalue(5));
//			usRegHoldingBuf[26] =CALIB_THREAD_ImonToValue(6,getIportvalue(6));	
//			usRegHoldingBuf[27] =CALIB_THREAD_ImonToValue(7,getIportvalue(7));
//			usRegHoldingBuf[28] =CALIB_THREAD_ImonToValue(8,getIportvalue(8));	
//			usRegHoldingBuf[29] =CALIB_THREAD_ImonToValue(9,getIportvalue(9));
//			usRegHoldingBuf[30] =CALIB_THREAD_ImonToValue(10,getIportvalue(10));	
//			usRegHoldingBuf[31] =CALIB_THREAD_ImonToValue(11,getIportvalue(11));
//			usRegHoldingBuf[32] =CALIB_THREAD_ImonToValue(12,getIportvalue(12));	
//			usRegHoldingBuf[33] =CALIB_THREAD_ImonToValue(13,getIportvalue(13));
//			usRegHoldingBuf[34] =CALIB_THREAD_ImonToValue(14,getIportvalue(14));	
//			usRegHoldingBuf[35] =CALIB_THREAD_ImonToValue(15,getIportvalue(15));
//			usRegHoldingBuf[36] =CALIB_THREAD_ImonToValue(16,getIportvalue(16));	
//			usRegHoldingBuf[37] =CALIB_THREAD_ImonToValue(17,getIportvalue(17));
//			usRegHoldingBuf[38] =CALIB_THREAD_ImonToValue(18,getIportvalue(18));	
//			usRegHoldingBuf[39] =CALIB_THREAD_ImonToValue(19,getIportvalue(19));
			while (usNRegs > 0)	
			{
				*pucRegBuffer++ = (unsigned char)(usRegHoldingBuf[iRegIndex] >> 8);
				*pucRegBuffer++ = (unsigned char)(usRegHoldingBuf[iRegIndex] & 0xFF);
				iRegIndex++;
				usNRegs--;
			}
			break;

		case MB_REG_WRITE:
			while (usNRegs > 0)
			{
				usRegHoldingBuf[iRegIndex] = (*pucRegBuffer++) << 8;
				usRegHoldingBuf[iRegIndex] |= *pucRegBuffer++;
				iRegIndex++;
				usNRegs--;
			}

//				if(usRegHoldingBuf[CLIBSTART]!=TempHoldingBuf[CLIBSTART])
//				{
//					TempHoldingBuf[CLIBSTART]=usRegHoldingBuf[CLIBSTART];
//					if(TempHoldingBuf[CLIBSTART])
//					{
//					usRegHoldingBuf[CLIBSTART]=0;
//					usRegHoldingBuf[CLIBTYPE]=0;
//					usRegHoldingBuf[CLIBRAIN]=0;
//					usRegHoldingBuf[CLIBCHANEL]=0;
//					usRegHoldingBuf[CLIBVALUE]=0;
//					}
//				}
//				else if(usRegHoldingBuf[CLIBTYPE]!=TempHoldingBuf[CLIBTYPE])				
//				{
//					TempHoldingBuf[CLIBTYPE]=usRegHoldingBuf[CLIBTYPE];
//					CALIB_THREAD_StartType(TempHoldingBuf[CLIBTYPE]);
//				}
//				else if(usRegHoldingBuf[CLIBRAIN]!=TempHoldingBuf[CLIBRAIN])   
//				{
//					TempHoldingBuf[CLIBRAIN]=usRegHoldingBuf[CLIBRAIN];
//					CALIB_THREAD_SetIRange(TempHoldingBuf[CLIBRAIN]);
//				}
//				else if(usRegHoldingBuf[CLIBCHANEL]!=TempHoldingBuf[CLIBCHANEL])
//				{
//					TempHoldingBuf[CLIBCHANEL]=usRegHoldingBuf[CLIBCHANEL];
//					CALIB_THREAD_StartChannel(TempHoldingBuf[CLIBCHANEL]-1);				
//				}
//				else if(usRegHoldingBuf[CLIBVALUE]!=TempHoldingBuf[CLIBVALUE])
//				{
//					TempHoldingBuf[CLIBVALUE]=usRegHoldingBuf[CLIBVALUE];
//					CALIB_THREAD_RecordChannel(TempHoldingBuf[CLIBVALUE],TempHoldingBuf[CLIBTYPE]);
//				}
// 				else if(usRegHoldingBuf[80]!=TempHoldingBuf[80])
//				{
//					TempHoldingBuf[80]=usRegHoldingBuf[80];
//				}    
// 				else if(usRegHoldingBuf[81]!=TempHoldingBuf[81])
//				{
//					TempHoldingBuf[81]=usRegHoldingBuf[81];
//					ctrl_io(TempHoldingBuf[80],TempHoldingBuf[81]);
//					temp=spiReadRegData(0,IO);
//					printf("0x:%x   \r\n",temp);
//				}    			
			break;	
		}
		}
	return eStatus;
	}

//读写线圈/离散输出寄存器 功能码读0x01写0x05
eMBErrorCode
eMBRegCoilsCB(UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNCoils, eMBRegisterMode eMode)
{
	(void)pucRegBuffer;
	(void)usAddress;
	(void)usNCoils;
	(void)eMode;
	return MB_ENOREG;
}

//读离散输入寄存器 功能码0x02
eMBErrorCode
eMBRegDiscreteCB(UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNDiscrete)
{
	(void)pucRegBuffer;
	(void)usAddress;
	(void)usNDiscrete;
	return MB_ENOREG;
}
