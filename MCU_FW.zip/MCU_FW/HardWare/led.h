/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __LED_H
#define __LED_H



#include "include.h"

void run_led_on(void);
void run_led_off(void);
void err_led_on(void);
void err_led_off(void);
#endif
