#include <stdint.h>
#include <stddef.h>
#include "adcthread.h"
#include "calibthread.h"
#include "include.h"

//#include "bspdriverbuzzer.h"
//#include "chipdriverina226.h"
//#include "chipdriverads1158.h"
//#include "chipdrivercoretimer.h"
//#include "processevent.h"
//#include "eventthread.h"
//#include "powerthread.h"
#define SDC_CHN_PORT4  4


#define ADC_VREF 25000
static _srtADCThread srtADCThread;
static _srtADCChannel srtADCChannel;
#define DISPLAY_AVERAGE_A_VALUE 0
/***************************************************************************
    Function           :_srtADCThread *ADC_THREAD_GetInfor(uint32_t uiPort)  
    Description        : adc thread get information  
    Input Parameter    :    
    Output Parameter   :   
    Who Make it ?      :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
_srtADCBase *ADC_THREAD_GetInfor(uint32_t uiPort)
{
	_srtADCBase   *psrtBase;
	if(uiPort > SDC_CHN_PORT4)
	{
	    return NULL;
	}
	
	psrtBase = &(srtADCThread.Base1);
	psrtBase += uiPort;
	
	return psrtBase;
}
//static void INA2XX_THREAD_Init(void);

/***************************************************************************
    Function           :void ADC_THREAD_Init(void)
    Description        : adc thread init 
    Input Parameter    :    
    Output Parameter   :   
    Who Make it ?      :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
void ADC_THREAD_Init(void)
{
	int i = 0;
	_srtADCPort *psrtPort;
	_srtADCModule *psrtModule;

	psrtModule = &(srtADCChannel.Module1);
	psrtPort = &(psrtModule->Port1);
	
    for(i = 0; i <= ADC_MONIT_CHANNEL_MAX; i++,psrtPort++)	
	{
		psrtPort->vuiIndex = 0;
		psrtPort->vuiInit = 0;
	}
	
	psrtModule++;
	psrtPort = &(psrtModule->Port1);
	
    for(i = 0; i <= ADC_MONIT_CHANNEL_MAX; i++,psrtPort++)	
	{
		psrtPort->vuiIndex = 0;
		psrtPort->vuiInit = 0;
	}
//	INA2XX_THREAD_Init();
}
/***************************************************************************
    Function           :static void ADC_THREAD_UpdateBuff(_srtADCBase *psrtBase,int16_t *psiTemp,int16_t siTemp)
    Description        : init channel  
    Input Parameter    :    
    Output Parameter   :   
    Who Make it ?      :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
static void ADC_THREAD_UpdateBuff(_srtADCPort *psrtPort,int16_t *psiTemp,int16_t siTemp)
{
	int64_t liResult = 0;
#if(DISPLAY_AVERAGE_A_VALUE == 1)
	int i = 0;
	if(psrtPort->vuiInit)
	{
		psrtPort->viSum += siTemp;		
		psiTemp += psrtPort->vuiIndex;
		psrtPort->viSum -= *psiTemp;		
		*psiTemp = siTemp;
		
		psrtPort->vuiIndex++;
		
		if(psrtPort->vuiIndex >= ADC_BUFF_LEN)
		{
			psrtPort->vuiIndex = 0;
		}

		liResult = psrtPort->viSum/ADC_BUFF_LEN;
		psrtPort->iCode = liResult;
		liResult *= ADC_VREF;
		//liResult >>= ADC_RES_BIT;
	    liResult /= 0x7800;
		
		psrtPort->iValue = liResult;
		return;
	}
	
	psrtPort->vuiInit = 1;
	psrtPort->vuiIndex = 0;
	
	for(i = 0; i < ADC_BUFF_LEN; i++)
	{
		*psiTemp++ = siTemp;
	}
	psrtPort->viSum = (siTemp * ADC_BUFF_LEN);
	psrtPort->vuiIndex++;
	
	liResult = psrtPort->viSum/ADC_BUFF_LEN;
#else
	liResult = siTemp;
#endif
	psrtPort->iCode = liResult;
	
	liResult *= ADC_VREF;
	//liResult >>= ADC_RES_BIT;
	liResult /= 0x7800;
	
	psrtPort->iValue = liResult;
}

/***************************************************************************
    Function           :void ADC_THREAD_Callback(uint32_t uiPort,int16_t siTemp) 
    Description        : callback   
    Input Parameter    :    
    Output Parameter   :   
    Who Make it ?      :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
void ADC_THREAD_Callback(uint32_t uiChannel,uint32_t uiPort,int16_t siTemp)
{
	int16_t *psiTemp;
	uint32_t uiOffset = 0;
	
	_srtADCPort   *psrtPort;
	_srtADCModule *psrtModule;
	_srtADCBase   *psrtBase;
	
	psrtModule = &(srtADCChannel.Module1);
	psrtModule += uiChannel;
	
	psrtPort = &(psrtModule->Port1);
	psrtPort += uiPort;

	//get port information
	psiTemp  =  (int16_t *)&psrtPort->Buff; //receive buff point

	ADC_THREAD_UpdateBuff(psrtPort,psiTemp,siTemp);	
	psrtPort->vuiCount++;
	psrtPort->vuiIsReflash = 1;

	if(((uiPort + 1) % 4) == 0)
	{
		uiOffset = uiPort / 4;
		psrtBase = &(srtADCThread.Base1);
		psrtBase += (uiChannel * 2);
		psrtBase += uiOffset;
		psrtBase->uiIsReflash = 1;	

		psrtPort--;
		psrtPort--;
		psrtBase->uiuACheck = psrtPort->iValue;
		psrtPort++;
		psrtBase->uimACheck = psrtPort->iValue;
		psrtPort++;
		psrtBase->uiVCheck = psrtPort->iValue;		
	}
}

/***************************************************************************
    Function           :int ADC0_THREAD_IsReflash(uint32_t uiPort)
    Description        :    
    Input Parameter    :    
    Output Parameter   :   
    Who Make it ?      :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
static int ADC_THREAD_IsReflash(uint32_t uiPort)
{	
	int ret = 0;
	
	_srtADCBase   *psrtBase;
	_srtADCModule *psrtModule;
	
	psrtModule = &(srtADCChannel.Module1);
	psrtModule += (uiPort / 2);
	
	psrtBase = &(srtADCThread.Base1);
	psrtBase += uiPort;
	
	if(psrtBase->uiIsReflash)
	{		
		psrtModule->vuiTick = TIM_CORE_GetTick();
		psrtBase->uiIsReflash = 0;
		
		return 1;
	}
	
	if(psrtModule->vuiIsTimeOut)
	{}
	else
	{
		//adc check,min interrupt tick 20hz
		if(TIM_CORE_GetTick() > (psrtModule->vuiTick + 100))
		{
			psrtModule->vuiIsTimeOut = 1;
//			PROCESS_EventPost(EVT_SDC0_ADC_TIMEOUT + uiPort);
		}
	}		
	
	return ret;
}
//static _srtINAThread srtINAThread;

/***************************************************************************
    Function           :int ADC_THREAD_ClearOff(uint32_t uiPort)
    Description        :    
    Input Parameter    :    
    Output Parameter   :   
    Who Make it ?      :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int ADC_THREAD_ClearOff(uint32_t uiPort)
{
	int i = 0;
	_srtADCBase   *psrtBase;
//	_srtINABase   *psrtINA;
	
	psrtBase = &(srtADCThread.Base1);
	psrtBase += uiPort;
	
//	psrtINA = &(srtINAThread.Base1);
//	psrtINA += uiPort;
	
	
    psrtBase->uiVCheck = 0;
	psrtBase->uimACheck = 0;
	psrtBase->uiuACheck = 0;
	
	
//	psrtINA->uiStatus = 0;
//	psrtINA->uiIsReflash = 0;
	
	return 1;
}

//static int INA_THREAD_IsReflash(uint32_t uiPort);

/***************************************************************************
    Function           :int ADC_THREAD_Poll(uint32_t uiPort)
    Description        :    
    Input Parameter    :    
    Output Parameter   :   
    Who Make it ?      :LiuF                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int ADC_THREAD_Poll(uint32_t uiPort)
{
//	static uint32_t uiTick = 0;
//	if(INA_THREAD_IsReflash(uiPort))
//	{}
	
	if(ADC_THREAD_IsReflash(uiPort))
	{
//		INA2XX_GetVoltage(uiPort,&uiPower);
//		INA2XX_GetShuntCurrent(uiPort,&uiPower);
//		INA2XX_GetPower(uiPort,&uiPower);
//		INA2XX_GetShuntVoltage(uiPort,&uiPower);

		return 1;
	}
	
//	if(TIM_CORE_GetTick() > (uiTick + 5000))
//	{
//		ADC_THREAD_GetInfor(ADC_CHN_PORT0)->uiSPS = (ADC_THREAD_GetInfor(ADC_CHN_PORT0)->Base0.vuiCount) / 5;
//		ADC_THREAD_GetInfor(ADC_CHN_PORT0)->Base0.vuiCount = 0;
//		uiTick = TIM_CORE_GetTick();
//	}
	return 0;
}


