/* Includes ------------------------------------------------------------------*/
#include "include.h"

void run_led_on(void)
{
	HAL_GPIO_WritePin(GPIOF, RUN_LED_Pin, GPIO_PIN_RESET);
}
void run_led_off(void)
{
	HAL_GPIO_WritePin(GPIOF, RUN_LED_Pin, GPIO_PIN_SET);
}
void err_led_on(void)
{
	HAL_GPIO_WritePin(GPIOF, ERR_LED_Pin, GPIO_PIN_RESET);
}
void err_led_off(void)
{
	HAL_GPIO_WritePin(GPIOF, ERR_LED_Pin, GPIO_PIN_SET);
}


