#ifndef _ADS1256_H
#define _ADS1256_H
/****************************����ͷ�ļ���***********************/

#include "include.h"
extern int64_t adcVaule;
extern float voltage;
extern float filterVoltage;
extern float filterVoltage2;
extern float all_vol[4];
/****************************����ads1256�Ĵ�����ַ**************/
#define STATUS  0x00                //״̬�Ĵ���
#define MUX     0x01                //ͨ���л��Ĵ���
#define ADCON   0x02                //ADC���ƼĴ���
#define DRATE   0x03                //ADC�������üĴ���
#define IO      0x04                //ͨ��IO�Ĵ���
#define OFC0    0x05
#define OFC1    0x06
#define OFC2    0x07
#define FSC0    0x08
#define FSC1    0x09
#define FSC2    0x0A

/****************************����ads1256����*******************/
#define WAKEUP  0x00
#define RDATA   0x01
#define TDATAC  0x03
#define SDATAC  0x0F
#define RREG    0x10
#define WREG    0x50
#define SELFCAL 0xF0    //Offset and Gain Self-Calibration
#define SELFOCAL 0xF1		//Offset Self-Calibration 
#define SELFGCAL 0xF2		//Gain Self-Calibration
#define SYSOCAL  0xF3		//System Offset Calibration 
#define SYSGCAL  0xF4		//System Gain Calibration 
#define SYNC     0xFC
#define STANDBY  0xFD
#define RESET1    0xFE

/*****************************�����������*********************/
#define GAIN_1   0x00
#define GAIN_2   0x01
#define GAIN_4   0x02
#define GAIN_8   0x03
#define GAIN_16  0x04
#define GAIN_32  0x05
#define GAIN_64  0x06

/*****************************��������ads1256�ɼ����ʴ���*******/
#define RATE_30000 0xF0
#define RATE_15000 0xE0
#define RATE_7500  0xD0                       
#define RATE_3750  0xC0
#define RATE_2000  0xB0
#define RATE_1000  0xA1
#define RATE_500   0x92
#define RATE_100   0x82
#define RATE_60    0x72
#define RATE_50    0x63
#define RATE_30    0x53
#define RATE_25    0x43
#define RATE_15    0x33
#define RATE_10    0x23
#define RATE_5     0x13
#define RATE_2_5   0x03

/*****************************����ads1256ͨ��ѡ��**************/
//����������ͨ��
#define MUXP_AIN0  0x00
#define MUXP_AIN1  0x10
#define MUXP_AIN2  0x20
#define MUXP_AIN3  0x30
#define MUXP_AIN4  0x40
#define MUXP_AIN5  0x50
#define MUXP_AIN6  0x60
#define MUXP_AIN7  0x70
#define MUXP_AINCOM 0x80
//���帺����ͨ��
#define MUXN_AIN0   0x00
#define MUXN_AIN1   0x01
#define MUXN_AIN2   0x02
#define MUXN_AIN3   0x03
#define MUXN_AIN4   0x04
#define MUXN_AIN5   0x05
#define MUXN_AIN6   0x06
#define MUXN_AIN7   0x07
#define MUXN_AINCOM 0x08

#define MEDIAN_LEN  5                     //��ֱ�˲����ܳ��ȣ�һ��ѡȡ����   
#define MEDIAN      2                     //��ֵ���˲������е�λ��
#define N           50					  //��Ȩ�˲����ܳ���


#define ADCCHANEL1  (MUXP_AIN0|MUXN_AINCOM)
#define ADCCHANEL2  (MUXP_AIN1|MUXN_AINCOM)
#define ADCCHANEL3  (MUXP_AIN2|MUXN_AINCOM)
#define ADCCHANEL4  (MUXP_AIN3|MUXN_AINCOM)
#define ADCCHANEL5  (MUXP_AIN4|MUXN_AINCOM)
#define ADCCHANEL6  (MUXP_AIN5|MUXN_AINCOM)
#define ADCCHANEL7  (MUXP_AIN6|MUXN_AINCOM)
#define ADCCHANEL8  (MUXP_AIN7|MUXN_AINCOM)



void delayXus(uint16_t us);
void spiWriteByte(uint8_t txData);
uint8_t spiReadByte(void);
void spiWriteRegData(uint8_t port,uint8_t regAdd, uint8_t regData);
void ads1256Init(void);
int32_t ads1256ReadValue(uint8_t port,uint8_t channel);
void setGain(uint8_t port,uint8_t gainSelect);
void setRate(uint8_t port,uint8_t rate);
void setmode(uint8_t mode);




float filterlowerpass(float adc);
float kalman_filter(float ADC_Value);
void read_vol(void);

float kalman_filter(float ADC_Value);
float filterlowerpass(float adc);
int32_t get_chanel_value(uint8_t port,uint32_t chanel );

void getadcinit(void);
int32_t get_port_adcvalue(uint32_t port);
int32_t getIportvalue(uint32_t port);
int32_t getVportvalue(uint32_t port);

void startcliab(void);
uint8_t readpin(uint8_t chanel);

void cs_line(uint8_t port,uint8_t status);
int32_t filter(int32_t adcode) ;
uint8_t spiReadRegData(uint8_t port,uint8_t regAdd);
void ctrl_io(uint8_t port,uint8_t level);
#endif
