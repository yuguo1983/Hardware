#ifndef _CALIB_THREAD_H_
#define _CALIB_THREAD_H_

#include <stdint.h>




#define MAX_PORT         (4)



typedef enum
{
	CALIB_TYPE_NONE,
	CALIB_TYPE_V,
	CALIB_TYPE_I,
}
_enumCalibType;


//calib base data ,just voltage,current
typedef struct
{
	int32_t VMonMin;    	//V mon值0
	int32_t VMonMax;			//V mon值1
	
	int32_t VVOutMin;	//万用表测出2
	int32_t VVOutMax;	//万用表测出3
	
	int32_t ImonMin;	//4 A
	int32_t ImonMax;	//5 A
	
	int32_t IOutMin;	//6  万用表测出
	int32_t IOutMax;	//7  万用表测出
	
	int32_t IMon1Min;     //8
	int32_t IMon1Max;    //9
	
	int32_t IOut1Min;     //uA 实际值10
	int32_t IOut1Max;     	//11
	
	int32_t IMon2Min;     //mA mon值12
	int32_t IMon2Max;    //13
	
	int32_t IOut2Min;     //mA 实际值//14
	int32_t IOut2Max;     //15
	
//	int32_t uimAOffset; //空载最小值,在uA校准时候来记录16
//	int32_t uiuAOffset; //空载最大值,在uA校准时候来记录17
//	
//	uint32_t uiIsValid;  //是否校准过18

}
_srtCalibData;
#define SLOPE_ITEM_OFFSET(member)	(((uint32_t)(&(((_srtCalibData *)0)->member))) / sizeof(uint32_t))
//calib information,include port0,1,2,3 calib result
typedef struct
{
	_srtCalibData Port1;
	_srtCalibData Port2;
	_srtCalibData Port3;
	_srtCalibData Port4;
//	_srtCalibData Port5;
//	_srtCalibData Port6;
//	_srtCalibData Port7;
//	_srtCalibData Port8;
//	_srtCalibData Port9;
//	_srtCalibData Port10;
//	_srtCalibData Port11;
//	_srtCalibData Port12;
//	_srtCalibData Port13;
//	_srtCalibData Port14;
//	_srtCalibData Port15;
//	_srtCalibData Port16;
//	_srtCalibData Port17;
//	_srtCalibData Port18;
//	_srtCalibData Port19;
//	_srtCalibData Port20;	
}
_srtCalibInfor;


void CALIB_THREAD_Init(void);
int CALIB_THREAD_Poll(void);
uint32_t CALIB_THREAD_VOutToDACCode(uint32_t uiPort,int32_t iValue);
uint32_t CALIB_THREAD_VMonToValue(uint32_t uiPort,int32_t iCode);
uint32_t CALIB_THREAD_VMonToOffset(uint32_t uiPort,int32_t iCode);
uint32_t CALIB_THREAD_IMonToValue(uint32_t uiPort,int32_t iValue);

_srtCalibData *CALIB_THREAD_GetInfor(uint32_t uiPort);




typedef struct
{
	uint32_t uiChannel;      //校准通道
	uint32_t uiIsFinish;     //校准是否完成
	uint32_t uiResult;       //校准结果
	uint32_t uiRecordVValue; //实际电压值,根据万用表测量
	uint32_t uiRecordAValue; //实际电流值,根据万用表测量
	uint32_t uiIRange;       //校准档位mA/uA
	uint32_t uiType;         //校准类型,电压校准/电流校准
	uint32_t uiTrigger;      //触发信号
	uint32_t uiStatus;       //状态机
	uint32_t uiTick;         //间隔
	uint32_t uiStartTick;    //起始时	
}
_srtCalibPoll;
#define CALIB_ITEM_OFFSET(member)	(((uint32_t)(&(((_srtCalibPoll *)0)->member))) / sizeof(uint32_t))

_srtCalibPoll *CALIB_THREAD_GetPoll(void);
int CALIB_THREAD_StartChannel(uint32_t uiChannel);
int CALIB_THREAD_RecordChannel(uint32_t uiValue,uint32_t uiType);
int CALIB_THREAD_SetIRange(uint32_t uiRange);
int CALIB_THREAD_StartType(uint32_t uiType);
int CALIB_THREAD_RecordTriiger(void);
int CALIB_THREAD_CheckValid(uint32_t uiPort);
void CALIB_THREAD_ValidDefault(void);
int CALIB_THREAD_SetCVmode(uint32_t mode);


uint32_t CALIB_THREAD_VToVset(uint32_t uiPort,int32_t uiCode);
uint32_t CALIB_THREAD_IToSet(uint32_t uiPort,int32_t uiValue);
uint32_t CALIB_THREAD_ImonToValue(uint32_t uiPort,int32_t uiValue);
uint32_t CALIB_THREAD_VoutToIout(uint32_t uiPort,int32_t uiVIN);

#endif
