#ifndef _SWITCH_H
#define _SWITCH_H
/****************************����ͷ�ļ���***********************/
#include "include.h"


typedef enum
{
	C_AA=1,
	C_MA,
	C_UA,
}_RAIN_TYPE;

typedef enum{
GAIN1 =1,
GAIN2 ,
GAIN13 	,
GAIN61 ,
}_GAIN_TPYE;


typedef struct {
uint32_t RANGE_TYPE;
uint32_t GAIN_TYPE;	
uint32_t rain_buf;
uint32_t gain_buf;
}_range_type;


typedef struct {
_range_type	port1;
_range_type	port2;
_range_type	port3;
_range_type	port4;
}_port_number;

#define _port_num_offset(member)	(((uint32_t)(&(((_port_number *)0)->member))) / sizeof(uint32_t))
void thread_gain_scan(uint32_t uport);
void thread_range_scan(uint32_t uport);
void thread_init(void);


#endif
