

#include "include.h"



#define CALIB_DAC_UMIN    100

#define CALIB_DAC_UMAX    1100


#define CALIB_CC_UMIN    60
#define CALIB_CC_UMAX    250

#define CALIB_CC_MIN    10
#define CALIB_CC_MAX    100

#define CALIB_POLL_TIMEOUT    (10*60*1000)

#define CALIB_FLAG1_VALID     (0xAA55)
#define CALIB_FLAG2_VALID     (0x55AA)

extern _port_number  port_number;
_srtCalibInfor srtCalibInfor;
 _srtCalibPoll  srtCalibPoll;
extern _Mult_port mult_port;
//record v calib dac out code
static int32_t uiVMinCode = 0;
static int32_t uiVMaxCode = 0;

/***************************************************************************
    Function           :void CALIB_THREAD_ValidDefault(void)
    Description        :У׼������λ,������µĴ洢��,����û�д洢У׼�����Ը�λ��ʼ��
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
void CALIB_THREAD_ValidDefault(void)
{
//	int i = 0;
//	//channel 0
//	_srtCalibData *psrtBase;
//	
////	uiVMinCode = AD5692_ValueToCode(CALIB_DAC_UMIN);
////	uiVMaxCode = AD5692_ValueToCode(CALIB_DAC_UMAX);
//	
//	psrtBase = &srtCalibInfor.Port1;

//	for(i = 0; i < MAX_PORT; i++,psrtBase++)
//	{		
//		//initial v mon
//		psrtBase->uiVMonMin = 0x47E;
//		psrtBase->uiVMonMax = 0x2DCE;
//		
//		//initial v out
//		psrtBase->uiVOutMin = 0x4DD;
//		psrtBase->uiVOutMax = 0x37AB;
//	}
//	
//	psrtBase = &srtCalibInfor.Port1;
//	for(i = 0; i <= MAX_PORT; i++,psrtBase++)
//	{
//		MEMORY_WriteDWord(CAL_PARAM_ADDR(i,0),psrtBase->uiVMonMin);
//		MEMORY_WriteDWord(CAL_PARAM_ADDR(i,1),psrtBase->uiVMonMax);
//		MEMORY_WriteDWord(CAL_PARAM_ADDR(i,2),psrtBase->uiVOutMin);
//		MEMORY_WriteDWord(CAL_PARAM_ADDR(i,3),psrtBase->uiVOutMax);
//	}
}
typedef enum
{
	CALIB_POLL_IDLE,
	CALIB_START_FIND,
	CALIB_CHECK_MIN,
	CALIB_CHECK_MAX,
}
_enumCalibCheck;

/***************************************************************************
    Function           :void CALIB_THREAD_Init(void)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
void CALIB_THREAD_Init(void)
{
	int i = 0;
	uint32_t uiLen = 0;
	uint32_t *puiTemp;
	_srtCalibData *psrtBase;
	
	uiVMinCode = 1;//AD5692_ValueToCode(CALIB_DAC_UMIN);
	uiVMaxCode = 2;//AD5692_ValueToCode(CALIB_DAC_UMAX);
	
    srtCalibPoll.uiIRange = 1;
	srtCalibPoll.uiType   = CALIB_TYPE_NONE;
	srtCalibPoll.uiStatus = CALIB_POLL_IDLE;
	uiLen = (SLOPE_ITEM_OFFSET(IOut2Max) - SLOPE_ITEM_OFFSET(VMonMin) + 1);
	
	// \��ȡУ׼������,��ѹУ׼����,mAУ׼����,uAУ׼���� \
	//initial v mon
	psrtBase = &srtCalibInfor.Port1;
	for(i = 0; i < MAX_PORT; i++,psrtBase++)	
	{
		puiTemp = &(psrtBase->VMonMin);	
	  MEMORY_ReadDWords(CAL_PARAM_ADDR(i,0),puiTemp,uiLen);
		for(int i=0;i<uiLen;i++)
		printf("%d  ",*puiTemp++);
		printf("\r\n ");
	}
}

/***************************************************************************
    Function           :int CALIB_THREAD_CheckValid(uint32_t uiPort)
    Description        :����Ƿ����У׼��
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int CALIB_THREAD_CheckValid(uint32_t uiPort)
{
//	if(CALIB_FLAG2_VALID != CALIB_THREAD_GetInfor(uiPort)->uiIsValid)
//	{
//		return -1;
//	}
	
	return 1;
}
extern const uint32_t ChannelRemap[];
/***************************************************************************
    Function           :void CALIB_THREAD_VOutToDAC(uint32_t uiPort,uint32_t uiVOUT) 
    Description        :�����ѹת��ΪDAC�m
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
uint32_t CALIB_THREAD_ImonToValue(uint32_t uiPort,int32_t uiValue)
{
	int32_t uiGain = 0;
	int32_t uiOffset = 0;
	int32_t uiCodeMin = 0;
	int32_t uiCodeMax = 0;
	int32_t uiOutMin = 0;
	int32_t uiOutMax = 0;		
	int64_t uliValue = 0;
	_srtCalibData *psrtInfor;
	_DataType    *psrtBase;
	_range_type  *range_type;
	range_type=&port_number.port1;
	range_type+=uiPort;

	
	
	psrtInfor = &srtCalibInfor.Port1;
	psrtInfor += uiPort;
	
	
	psrtBase=&mult_port.port1;
	psrtBase += uiPort;
	
	psrtBase->Itype=range_type->RANGE_TYPE;
	if(psrtBase->Itype==	C_AA)
	{
	uiCodeMin = psrtInfor->IOutMin;
	uiCodeMax = psrtInfor->IOutMax;
	
	uiOutMin = psrtInfor->ImonMin;
	uiOutMax = psrtInfor->ImonMax;	
	}
	else if(psrtBase->Itype==C_MA)
	{
	uiCodeMin = psrtInfor->IOut1Min;
	uiCodeMax = psrtInfor->IOut1Max;	
	
	uiOutMin =psrtInfor->IMon1Min; 
	uiOutMax =psrtInfor->IMon1Max; 	
	}
	else if(psrtBase->Itype==C_UA)
	{
	uiCodeMin = psrtInfor->IOut2Min;
	uiCodeMax = psrtInfor->IOut2Max;	
	
	uiOutMin =psrtInfor->IMon2Min; 
	uiOutMax =psrtInfor->IMon2Max; 	
	}	
	uiGain = uiOutMax - uiOutMin;
	uiOffset = uiCodeMax - uiCodeMin;
		
	
	//dbSlope = (double)uiGain/(double)uiOffset;	
	//vout = voumin + (dacx - dacmin)*slope;
	//dacx = (vout-voutmin)/slope + dacmin;	

//	uliValue = uiValue;
//	uliValue *= 10;		
	uliValue = (uiValue - uiOutMin);
//	uliValue -= uiOutMin;	
	uliValue *= uiOffset;	
	uliValue /= uiGain;	
	uliValue += uiCodeMin;
	
	return (uint32_t)uliValue;
}


/***************************************************************************
    Function           :void CALIB_THREAD_VMonToValue(uint32_t uiPort,uint32_t uiVOUT) 
    Description        :VMon ת��Ϊ��ѹ��
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
uint32_t CALIB_THREAD_VMonToValue(uint32_t uiPort,int32_t uiCode)
{
	int32_t uiGain = 0;
	int32_t uiOffset = 0;
	int32_t uiMonMin = 0;
	int32_t uiMonMax = 0;
	int32_t uiOutMin = 0;
	int32_t uiOutMax = 0;	
	int64_t uliValue = 0;
	_srtCalibData *psrtInfor;
	
	psrtInfor = &srtCalibInfor.Port1;
	psrtInfor += uiPort;
	
	uiMonMin = psrtInfor->VMonMin;
	uiMonMax = psrtInfor->VMonMax;
	uiOutMin = psrtInfor->VVOutMin;
	uiOutMax = psrtInfor->VVOutMax;
	
	uiGain = uiOutMax - uiOutMin;
	uiOffset = uiMonMax - uiMonMin;
	
	//dbSlope = (double)uiGain/(double)uiOffset;
	//vout = voumin + (dacx - dacmin)*slope;
	//dacx = (vout-voutmin)/slope + dacmin;

  uliValue = (uiCode - uiMonMin);
	
	uliValue *= uiGain;
	uliValue /= uiOffset;	
	uliValue += uiOutMin;
	
//	uliValue += 5;
//	uliValue /= 10;	
	return (uint32_t)uliValue;
}


/***************************************************************************
    Function           :void CALIB_THREAD_VMonToValue(uint32_t uiPort,uint32_t uiVOUT) 
    Description        :VMon ת��Ϊ��ѹ��
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
/*
uint32_t CALIB_THREAD_VToVset(uint32_t uiPort,int32_t uiCode)
{
	int32_t uiGain = 0;
	int32_t uiOffset = 0;
	int32_t uiMonMin = 0;
	int32_t uiMonMax = 0;
	int32_t uiOutMin = 0;
	int32_t uiOutMax = 0;	
	int64_t uliValue = 0;
	_srtCalibData *psrtInfor;
	
	psrtInfor = &srtCalibInfor.Port1;
	psrtInfor += uiPort;
	
	uiMonMin = psrtInfor->VVOutMin;;
	uiMonMax =  psrtInfor->VVOutMax;	
	uiOutMin = CALIB_DAC_UMIN ;
	printf("%d\r\n",psrtInfor->VVOutMin);
	printf("%d\r\n",psrtInfor->VVOutMax);
	uiOutMax = CALIB_DAC_UMAX;
	
	uiGain = uiOutMax - uiOutMin;
	uiOffset = uiMonMax - uiMonMin;
	
	//dbSlope = (double)uiGain/(double)uiOffset;
	//vout = voumin + (dacx - dacmin)*slope;
	//dacx = (vout-voutmin)/slope + dacmin;

    uliValue = (uiCode - uiMonMin);
	
	uliValue *= uiGain;
	uliValue /= uiOffset;	
	uliValue += uiOutMin;
	
//	uliValue += 5;
//	uliValue /= 10;	
	return (uint32_t)uliValue;
}**/
/***************************************************************************
    Function           :void CALIB_THREAD_IMonCodeToValue(uint32_t uiPort,uint32_t uiVOUT) 
    Description        :IMon AD��ת��Ϊ��ѹ��
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
/*
uint32_t CALIB_THREAD_IToSet(uint32_t uiPort,int32_t uiValue)
{
	int32_t uiGain = 0;
	int32_t uiOffset = 0;
	int32_t uiMonMin = 0;
	int32_t uiMonMax = 0;
	int32_t uiOutMin = 0;
	int32_t uiOutMax = 0;
	int32_t uiIOffset = 0;
	
	int64_t uliValue = 0;
	int64_t uliOffset = 0;
	
	_srtCalibData *psrtInfor;
	
	psrtInfor = &srtCalibInfor.Port1;
	psrtInfor += uiPort;
	
	if(Mult_THREAD_GetInfor(uiPort)->Itype == C_AA)   //SDC_THREAD_GetInfor(uiPort)->uiIRange
	{
	    uiMonMin = psrtInfor->IOut1Min;
	    uiMonMax = psrtInfor->IOut1Max;
		
	    uiOutMin = CALIB_CC_MIN;
	    uiOutMax = CALIB_CC_MAX;
		
//		uiIOffset = psrtInfor->uimAOffset;
	}
  else if(Mult_THREAD_GetInfor(uiPort)->Itype == C_MA)
	{
	    uiMonMin = psrtInfor->IOut2Min;
	    uiMonMax = psrtInfor->IOut2Max;
		
	    uiOutMin = CALIB_CC_UMIN;
	    uiOutMax = CALIB_CC_UMAX;
		
//		uiIOffset = psrtInfor->uiuAOffset;
	}

	//hardware maybe have noise
//	if(uiValue - uiIOffset < 3)
//	{
//		uiIOffset = uiValue;
//		return 0;
//	}
	
	uiGain = uiOutMax - uiOutMin;
	uiOffset = uiMonMax - uiMonMin;
	
	//dbSlope = (double)uiGain/(double)uiOffset;
	//vout = voumin + (dacx - dacmin)*slope;
	//dacx = (vout-voutmin)/slope + dacmin;

	uliValue = (uiValue - uiMonMin);
	uliValue *= uiGain;	
	uliValue /= uiOffset;
	uliValue += uiOutMin;
	
	return (uint32_t)uliValue;
}
*/
/***************************************************************************
    Function           :_srtCalibPoll *CALIB_THREAD_GetPoll(void)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
_srtCalibPoll *CALIB_THREAD_GetPoll(void)
{
	return &srtCalibPoll;
}
/***************************************************************************
    Function           :_srtCalibInfor *CALIB_THREAD_GetInfor(void)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
_srtCalibData *CALIB_THREAD_GetInfor(uint32_t uiPort)
{
	_srtCalibData *psrtData;
	if(uiPort > MAX_PORT)
	{
	    return NULL;
	}
	psrtData = &srtCalibInfor.Port1;
	psrtData += uiPort;
	return psrtData;
}

/***************************************************************************
    Function           :static void CALIB_THREAD_StartFind(void)
    Description        :��ʼУ�������С����
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/

static void CALIB_THREAD_StartFind(void)
{
	_srtCalibData *psrtInfor;
   _DataType *DataType;
	// port 0 mation,board 4
	
	//initial v mon
	psrtInfor = &srtCalibInfor.Port1;
	psrtInfor += srtCalibPoll.uiChannel;			
  DataType=&mult_port.port1;
	DataType+= srtCalibPoll.uiChannel;
	DataType->Itype=srtCalibPoll.uiIRange;
	if(srtCalibPoll.uiType==CALIB_TYPE_V)
	{
		printf("palese input 1.3V\r\n");
	}
	else if(srtCalibPoll.uiType==CALIB_TYPE_I)
	{
		if(DataType->Itype==	C_AA)
		{
			printf("palese input 1.3V\r\n");
			printf("palese connect 3oh resistor\r\n");
		}
		if(DataType->Itype==	C_MA)
		{
			printf("palese input 1.3V\r\n");
			printf("palese connect 1000oh resistor\r\n");
		}
		if(DataType->Itype==	C_UA)
		{
			printf("palese input 1.3V\r\n");
			printf("palese connect 1000000oh resistor\r\n");		
		}		
	}

}
/***************************************************************************
    Function           :static int CALIB_THREAD_GetMin(void)
    Description        :��¼��С��ѹ����СmA����СuA��
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/




static int CALIB_THREAD_GetMin(void)
{
	_srtCalibData *psrtInfor;
  _DataType  *DataType;
	DataType=&mult_port.port1;
	DataType+=srtCalibPoll.uiChannel;
	get_port_adcvalue(srtCalibPoll.uiChannel);
	//wait write VOUT Min,Current Min,than record vmon min,Imon min
	if(srtCalibPoll.uiTrigger)
	{
		psrtInfor = &srtCalibInfor.Port1;
		psrtInfor += srtCalibPoll.uiChannel;	
	  if(srtCalibPoll.uiType==CALIB_TYPE_V)
		{
		psrtInfor->VMonMin=DataType->Vvalue;    //remember votage minvalue
		psrtInfor->VVOutMin=srtCalibPoll.uiRecordVValue;//remember testing  minvalue
		}
		else if(srtCalibPoll.uiType==CALIB_TYPE_I)
		{
			if(srtCalibPoll.uiIRange==C_AA)
			{
				psrtInfor->ImonMin=DataType->Avalue;    //remember votage minvalue
				psrtInfor->IOutMin=srtCalibPoll.uiRecordAValue;//remember testing  minvalue
				printf("palese input 13V\r\n");
			}
			else if(srtCalibPoll.uiIRange==C_MA)
			{
				psrtInfor->IMon1Min=DataType->mAvalue;    //remember votage minvalue
				psrtInfor->IOut1Min=srtCalibPoll.uiRecordAValue;//remember testing  minvalue
				printf("palese input 13V\r\n");
			}
			else if(srtCalibPoll.uiIRange==C_UA)
			{
				psrtInfor->IMon2Min=DataType->uAvalue;    //remember votage minvalue
				psrtInfor->IOut2Min=srtCalibPoll.uiRecordAValue;//remember testing  minvalue
				printf("palese input 13V\r\n");
			}		
		}
		srtCalibPoll.uiTrigger = 0;	
		srtCalibPoll.uiTick = TIM_CORE_GetTick();
		srtCalibPoll.uiStartTick = srtCalibPoll.uiTick;
		srtCalibPoll.uiStatus = CALIB_CHECK_MAX;
		return 1;
	}
	
	
	
	//check timeout
	if(TIM_CORE_GetTick() > (srtCalibPoll.uiStartTick + CALIB_POLL_TIMEOUT))
	{
		srtCalibPoll.uiResult = 2;
	    srtCalibPoll.uiType = CALIB_TYPE_NONE;
		srtCalibPoll.uiStatus = CALIB_POLL_IDLE;
		
		return -1;
	}
	return 0;
}

/***************************************************************************
    Function           :static int CALIB_THREAD_GetMax(void)
    Description        :��¼����ѹ�����mA�����uA��
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
static int CALIB_THREAD_GetMax(void)
{
	_srtCalibData *psrtInfor;
	_DataType  *DataType;
	//wait write VOUT MAX,Current MAX,than record vmon max,Imon max
	if(srtCalibPoll.uiTrigger)
	{
		
		psrtInfor = &srtCalibInfor.Port1;
		psrtInfor += srtCalibPoll.uiChannel;
		DataType=&mult_port.port1;
		DataType+=srtCalibPoll.uiChannel;
		get_port_adcvalue(srtCalibPoll.uiChannel);
		
		if(srtCalibPoll.uiType==CALIB_TYPE_V)
		{
			psrtInfor->VMonMax = DataType->Vvalue;
			psrtInfor->VVOutMax = srtCalibPoll.uiRecordVValue;
			MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,0),psrtInfor->VMonMin);
			MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,1),psrtInfor->VMonMax);
			MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,2),psrtInfor->VVOutMin);
			MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,3),psrtInfor->VVOutMax);
//			MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,16),psrtInfor->uimAOffset);
//			MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,17),psrtInfor->uiuAOffset);
		}
		else if(srtCalibPoll.uiType==CALIB_TYPE_I)
		{
			if(C_AA == srtCalibPoll.uiIRange)
			{
				psrtInfor->ImonMax = Mult_THREAD_GetInfor(srtCalibPoll.uiChannel)->Avalue;
				psrtInfor->IOutMax = srtCalibPoll.uiRecordAValue;
				
				//check calib parameter is valid
	
					MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,4),psrtInfor->ImonMin);
					MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,5),psrtInfor->ImonMax);
					MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,6),psrtInfor->IOutMin);
					MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,7),psrtInfor->IOutMax);
			}
			else if(C_MA == srtCalibPoll.uiIRange)
			{
				psrtInfor->IMon1Max = Mult_THREAD_GetInfor(srtCalibPoll.uiChannel)->mAvalue;
				
				psrtInfor->IOut1Max = srtCalibPoll.uiRecordAValue;
				//check calib parameter is valid
					MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,8),psrtInfor->IMon1Min);
					MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,9),psrtInfor->IMon1Max);
					MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,10),psrtInfor->IOut1Min);
					MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,11),psrtInfor->IOut1Max);
			}		
			else if(C_UA == srtCalibPoll.uiIRange)
			{
				psrtInfor->IMon2Max = Mult_THREAD_GetInfor(srtCalibPoll.uiChannel)->mAvalue;
				
				psrtInfor->IOut2Max = srtCalibPoll.uiRecordAValue;
				//check calib parameter is valid
					MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,12),psrtInfor->IMon2Min);
					MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,13),psrtInfor->IMon2Max);
					MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,14),psrtInfor->IOut2Min);
					MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,15),psrtInfor->IOut2Max);
			}		
		}
		//finish
		srtCalibPoll.uiResult = 1;
		srtCalibPoll.uiIsFinish = 0;				
		srtCalibPoll.uiTrigger = 0;	
		srtCalibPoll.uiTick = TIM_CORE_GetTick();
	  srtCalibPoll.uiType = CALIB_TYPE_NONE;
		srtCalibPoll.uiStatus = CALIB_POLL_IDLE;
		printf("cliab finish!!\r\n");
		return 1;
	}
	
	//check timeout
	if(TIM_CORE_GetTick() > (srtCalibPoll.uiStartTick + CALIB_POLL_TIMEOUT))
	{
		srtCalibPoll.uiResult = 3;
	    srtCalibPoll.uiType = CALIB_TYPE_NONE;
		srtCalibPoll.uiStatus = CALIB_POLL_IDLE;
		
		return -1;
	}
	return 0;
}

/***************************************************************************
    Function           :int CALIB_THREAD_SetIRange(uint32_t uiPort,uint32_t uiRange)
    Description        :���õ�����λ
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int CALIB_THREAD_SetIRange(uint32_t uiRange)
{	
	if(uiRange > C_UA)
	{
		return -1;
	}
	
	if(CALIB_POLL_IDLE == srtCalibPoll.uiStatus)
	{
		if(srtCalibPoll.uiIRange != uiRange)
		{			
			srtCalibPoll.uiIRange = uiRange;
		}
		return 1;		
	}
	return -2;
}


/***************************************************************************
    Function           :int CALIB_THREAD_StartType(uint32_t uiType)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int CALIB_THREAD_StartType(uint32_t uiType)
{
	if(uiType > CALIB_TYPE_I)
	{
		return -1;
	}
	if(CALIB_POLL_IDLE == srtCalibPoll.uiStatus)
	{
		srtCalibPoll.uiType = uiType;
	    return 1;
	}
	
	return -2;
}
/***************************************************************************
    Function           :int CALIB_THREAD_StartChannel(uint32_t uiChannel,uint32_t uiType)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int CALIB_THREAD_StartChannel(uint32_t uiChannel)
{
	//calib process is started
	if((uiChannel > MAX_PORT) || \
		(srtCalibPoll.uiIsFinish) || \
	    (CALIB_TYPE_NONE == srtCalibPoll.uiType) || 
	    (CALIB_POLL_IDLE != srtCalibPoll.uiStatus))
	{
		printf("%d  ,%d  ,%d"  ,srtCalibPoll.uiIsFinish,srtCalibPoll.uiType,srtCalibPoll.uiStatus);
		return -1;
	}

	if(srtCalibPoll.uiChannel != uiChannel)
	{
		srtCalibPoll.uiChannel = uiChannel;	
	}
	
	srtCalibPoll.uiTrigger = 1;
	return 1;
}
/***************************************************************************
    Function           :int CALIB_THREAD_RecordChannel(uint32_t uiValue,uint32_t uiType)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int CALIB_THREAD_RecordChannel(uint32_t uiValue,uint32_t uiType)
{
	if(uiValue)
	{
		if(CALIB_TYPE_I == uiType)
		{
			srtCalibPoll.uiRecordAValue = uiValue;
	        srtCalibPoll.uiTrigger = 1;
		}
		else
		{
			srtCalibPoll.uiRecordVValue = uiValue;
	        srtCalibPoll.uiTrigger = 1;

		}
	 
		return 1;
	}
	
	return -1;
}
/***************************************************************************
    Function           :int CALIB_THREAD_RecordTriiger(void)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int CALIB_THREAD_RecordTriiger(void)
{
	if((CALIB_TYPE_NONE == srtCalibPoll.uiType) || \
	   (CALIB_POLL_IDLE == srtCalibPoll.uiStatus))
	{
		return -1;
	}
	
//	srtCalibPoll.uiTrigger = 1;
	return 1;
}

/***************************************************************************
    Function           :void CALIB_THREAD_CheckVOut(void)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
static void CALIB_THREAD_CheckVOut(void)
{
	if(CALIB_POLL_IDLE == srtCalibPoll.uiStatus)
	{
		//wait start calib process
		if(srtCalibPoll.uiTrigger)
		{
			srtCalibPoll.uiTrigger = 0;
			srtCalibPoll.uiTick = TIM_CORE_GetTick();
			
			srtCalibPoll.uiResult = 0;
			srtCalibPoll.uiIsFinish = 1;
			srtCalibPoll.uiRecordVValue = 0;
			srtCalibPoll.uiRecordAValue = 0;
			srtCalibPoll.uiStatus = CALIB_START_FIND;
			printf("CALIB_START_FIND\r\n");
		}
	}
	else if(CALIB_START_FIND == srtCalibPoll.uiStatus)
	{
		//start find,umin
		if(TIM_CORE_GetTick() > (srtCalibPoll.uiTick + 100))
		{
      CALIB_THREAD_StartFind();
			srtCalibPoll.uiTick = TIM_CORE_GetTick();
			srtCalibPoll.uiStartTick = srtCalibPoll.uiTick;
			srtCalibPoll.uiStatus = CALIB_CHECK_MIN;			
		}
	}
	else if(CALIB_CHECK_MIN == srtCalibPoll.uiStatus)
	{
		//GET,VMON min
		if(TIM_CORE_GetTick() > (srtCalibPoll.uiTick + 300))
		{        
			if(CALIB_THREAD_GetMin() < 0)
			{}
			printf("CALIB_THREAD_GetMin\r\n");
		}
	}
	else if(CALIB_CHECK_MAX == srtCalibPoll.uiStatus)
	{
		//GET,VMON MAX
		if(TIM_CORE_GetTick() > (srtCalibPoll.uiTick + 300))
		{
			if(CALIB_THREAD_GetMax() < 0)
			{}
			printf("CALIB_THREAD_GetMax\r\n");	
		}
	}
}
/***************************************************************************
    Function           :int CALIB_THREAD_Poll(void)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int CALIB_THREAD_Poll(void)
{
	CALIB_THREAD_CheckVOut();

	return 1;
}
