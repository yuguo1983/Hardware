#include "include.h"

static void open_curA(uint8_t port);
static void open_curmA(uint8_t port);
static void open_curuA(uint8_t port);
static void open_gain1(uint8_t port);
static void open_gain2(uint8_t port);
static void open_gain13(uint8_t port);
static void open_gain61(uint8_t port);

_port_number  port_number;


void thread_init(void)
{
	_range_type *range;
	range=&port_number.port1;

	for(int i=0;i<MAX_PORT;i++)
	{
		range+=i;
		range->GAIN_TYPE=GAIN13;

	  thread_gain_scan(i);
	}
	range=&port_number.port1;
	for(int i=0;i<MAX_PORT;i++)
	{
		range+=i;
		range->RANGE_TYPE=C_AA;
	  thread_range_scan(i);
	}
}
void thread_gain_scan(uint32_t uport)
{

	_range_type *part;
	part = &port_number.port1;
	part+=uport;
	if(part->GAIN_TYPE!=part->rain_buf)
	{
		part->rain_buf=part->GAIN_TYPE;
		if(part->rain_buf==GAIN1)
		{
			open_gain1( uport);
		}
		else if(part->rain_buf==GAIN2)
		{
			open_gain2( uport);
		}
		else if(part->rain_buf==GAIN13)
		{
			open_gain13( uport);
		}
		else if(part->rain_buf==GAIN61)
		{
			open_gain61( uport);
		}	
}

}




void thread_range_scan(uint32_t uport)
{
	_range_type *part;
	part = &port_number.port1;
	part+=uport;
	if(part->gain_buf!=part->RANGE_TYPE)
	{
  if(part->gain_buf==C_AA)
	{
		open_curA(uport);
	}
	else if(part->gain_buf==C_MA)
	{
		open_curmA(uport);
	}
	else if(part->gain_buf==C_UA)
	{
		open_curuA(uport);
	}
}

}

static void open_gain1(uint8_t port)
{
	switch (port)
	{
		case  0:
						HAL_GPIO_WritePin(IN_G1_A0_GPIO_Port,  IN_G1_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(IN_G1_A1_GPIO_Port,  IN_G1_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  1:                  
						HAL_GPIO_WritePin(OUT_G1_A0_GPIO_Port, OUT_G1_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(OUT_G1_A1_GPIO_Port, OUT_G1_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  2:                  
						HAL_GPIO_WritePin(IN_G2_A0_GPIO_Port,  IN_G2_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(IN_G2_A1_GPIO_Port,  IN_G2_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  3:                  
						HAL_GPIO_WritePin(OUT_G2_A0_GPIO_Port, OUT_G2_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(OUT_G2_A1_GPIO_Port, OUT_G2_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  4:                  
						HAL_GPIO_WritePin(IN_G3_A0_GPIO_Port,  IN_G3_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(IN_G3_A1_GPIO_Port,  IN_G3_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  5:                  
						HAL_GPIO_WritePin(OUT_G3_A0_GPIO_Port, OUT_G3_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(OUT_G3_A1_GPIO_Port, OUT_G3_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  6:                  
						HAL_GPIO_WritePin(IN_G4_A0_GPIO_Port,  IN_G4_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(IN_G4_A1_GPIO_Port,  IN_G4_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  7:                  
						HAL_GPIO_WritePin(OUT_G4_A0_GPIO_Port, OUT_G4_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(OUT_G4_A1_GPIO_Port, OUT_G4_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  8:                  
						HAL_GPIO_WritePin(IN_G5_A0_GPIO_Port,  IN_G5_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(IN_G5_A1_GPIO_Port,  IN_G5_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  9:                  
						HAL_GPIO_WritePin(OUT_G5_A0_GPIO_Port, OUT_G5_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(OUT_G5_A1_GPIO_Port, OUT_G5_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  10:                 
						HAL_GPIO_WritePin(IN_G6_A0_GPIO_Port,  IN_G6_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(IN_G6_A1_GPIO_Port,  IN_G6_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  11:                 
						HAL_GPIO_WritePin(OUT_G6_A0_GPIO_Port, OUT_G6_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(OUT_G6_A1_GPIO_Port, OUT_G6_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  12:                 
						HAL_GPIO_WritePin(IN_G7_A0_GPIO_Port,  IN_G7_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(IN_G7_A1_GPIO_Port,  IN_G7_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  13:                 
						HAL_GPIO_WritePin(OUT_G7_A0_GPIO_Port, OUT_G7_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(OUT_G7_A1_GPIO_Port, OUT_G7_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  14:                 
						HAL_GPIO_WritePin(IN_G8_A0_GPIO_Port,  IN_G8_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(IN_G8_A1_GPIO_Port,  IN_G8_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  15:                 
						HAL_GPIO_WritePin(OUT_G8_A0_GPIO_Port, OUT_G8_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(OUT_G8_A1_GPIO_Port, OUT_G8_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  16:                 
						HAL_GPIO_WritePin(IN_G9_A0_GPIO_Port,  IN_G9_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(IN_G9_A1_GPIO_Port,  IN_G9_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  17:                 
						HAL_GPIO_WritePin(OUT_G9_A0_GPIO_Port, OUT_G9_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(OUT_G9_A1_GPIO_Port, OUT_G9_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  18:                 
						HAL_GPIO_WritePin(IN_G10_A0_GPIO_Port, IN_G10_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(IN_G10_A1_GPIO_Port, IN_G10_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  19:                 
						HAL_GPIO_WritePin(OUT_G10_A0_GPIO_Port, OUT_G10_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(OUT_G10_A1_GPIO_Port, OUT_G10_A1_Pin, GPIO_PIN_RESET);
		break;
		default : break;
	}
}

static void open_gain2(uint8_t port)
{
	switch (port)
	{
		case  0:
						HAL_GPIO_WritePin(IN_G1_A0_GPIO_Port,  IN_G1_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(IN_G1_A1_GPIO_Port,  IN_G1_A1_Pin, GPIO_PIN_SET);
		break;                    
		case  1:                  
						HAL_GPIO_WritePin(OUT_G1_A0_GPIO_Port, OUT_G1_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(OUT_G1_A1_GPIO_Port, OUT_G1_A1_Pin, GPIO_PIN_SET);
		break;                    
		case  2:                  
						HAL_GPIO_WritePin(IN_G2_A0_GPIO_Port,  IN_G2_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(IN_G2_A1_GPIO_Port,  IN_G2_A1_Pin, GPIO_PIN_SET);
		break;                    
		case  3:                  
						HAL_GPIO_WritePin(OUT_G2_A0_GPIO_Port, OUT_G2_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(OUT_G2_A1_GPIO_Port, OUT_G2_A1_Pin, GPIO_PIN_SET);
		break;                    
		case  4:                  
						HAL_GPIO_WritePin(IN_G3_A0_GPIO_Port,  IN_G3_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(IN_G3_A1_GPIO_Port,  IN_G3_A1_Pin, GPIO_PIN_SET);
		break;                    
		case  5:                  
						HAL_GPIO_WritePin(OUT_G3_A0_GPIO_Port, OUT_G3_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(OUT_G3_A1_GPIO_Port, OUT_G3_A1_Pin, GPIO_PIN_SET);
		break;                    
		case  6:                  
						HAL_GPIO_WritePin(IN_G4_A0_GPIO_Port,  IN_G4_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(IN_G4_A1_GPIO_Port,  IN_G4_A1_Pin, GPIO_PIN_SET);
		break;                    
		case  7:                  
						HAL_GPIO_WritePin(OUT_G4_A0_GPIO_Port, OUT_G4_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(OUT_G4_A1_GPIO_Port, OUT_G4_A1_Pin, GPIO_PIN_SET);
		break;                    
		case  8:                  
						HAL_GPIO_WritePin(IN_G5_A0_GPIO_Port,  IN_G5_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(IN_G5_A1_GPIO_Port,  IN_G5_A1_Pin, GPIO_PIN_SET);
		break;                    
		case  9:                  
						HAL_GPIO_WritePin(OUT_G5_A0_GPIO_Port, OUT_G5_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(OUT_G5_A1_GPIO_Port, OUT_G5_A1_Pin, GPIO_PIN_SET);
		break;                    
		case  10:                 
						HAL_GPIO_WritePin(IN_G6_A0_GPIO_Port,  IN_G6_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(IN_G6_A1_GPIO_Port,  IN_G6_A1_Pin, GPIO_PIN_SET);
		break;                    
		case  11:                 
						HAL_GPIO_WritePin(OUT_G6_A0_GPIO_Port, OUT_G6_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(OUT_G6_A1_GPIO_Port, OUT_G6_A1_Pin, GPIO_PIN_SET);
		break;                    
		case  12:                 
						HAL_GPIO_WritePin(IN_G7_A0_GPIO_Port,  IN_G7_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(IN_G7_A1_GPIO_Port,  IN_G7_A1_Pin, GPIO_PIN_SET);
		break;                    
		case  13:                 
						HAL_GPIO_WritePin(OUT_G7_A0_GPIO_Port, OUT_G7_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(OUT_G7_A1_GPIO_Port, OUT_G7_A1_Pin, GPIO_PIN_SET);
		break;                    
		case  14:                 
						HAL_GPIO_WritePin(IN_G8_A0_GPIO_Port,  IN_G8_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(IN_G8_A1_GPIO_Port,  IN_G8_A1_Pin, GPIO_PIN_SET);
		break;                    
		case  15:                 
						HAL_GPIO_WritePin(OUT_G8_A0_GPIO_Port, OUT_G8_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(OUT_G8_A1_GPIO_Port, OUT_G8_A1_Pin, GPIO_PIN_SET);
		break;                    
		case  16:                 
						HAL_GPIO_WritePin(IN_G9_A0_GPIO_Port,  IN_G9_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(IN_G9_A1_GPIO_Port,  IN_G9_A1_Pin, GPIO_PIN_SET);
		break;                    
		case  17:                 
						HAL_GPIO_WritePin(OUT_G9_A0_GPIO_Port, OUT_G9_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(OUT_G9_A1_GPIO_Port, OUT_G9_A1_Pin, GPIO_PIN_SET);
		break;                    
		case  18:                 
						HAL_GPIO_WritePin(IN_G10_A0_GPIO_Port, IN_G10_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(IN_G10_A1_GPIO_Port, IN_G10_A1_Pin, GPIO_PIN_SET);
		break;                    
		case  19:                 
						HAL_GPIO_WritePin(OUT_G10_A0_GPIO_Port, OUT_G10_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(OUT_G10_A1_GPIO_Port, OUT_G10_A1_Pin, GPIO_PIN_SET);
		break;
		default : break;
	}
}

static void open_gain13(uint8_t port)
{
	switch (port)
	{
		case  0:
						HAL_GPIO_WritePin(IN_G1_A0_GPIO_Port, IN_G1_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(IN_G1_A1_GPIO_Port, IN_G1_A1_Pin, GPIO_PIN_SET);
		break;
		case  1:
						HAL_GPIO_WritePin(OUT_G1_A0_GPIO_Port, OUT_G1_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(OUT_G1_A1_GPIO_Port, OUT_G1_A1_Pin, GPIO_PIN_SET);
		break;
		case  2:
						HAL_GPIO_WritePin(IN_G2_A0_GPIO_Port, IN_G2_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(IN_G2_A1_GPIO_Port, IN_G2_A1_Pin, GPIO_PIN_SET);
		break;
		case  3:
						HAL_GPIO_WritePin(OUT_G2_A0_GPIO_Port, OUT_G2_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(OUT_G2_A1_GPIO_Port, OUT_G2_A1_Pin, GPIO_PIN_SET);
		break;
		case  4:
						HAL_GPIO_WritePin(IN_G3_A0_GPIO_Port, IN_G3_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(IN_G3_A1_GPIO_Port, IN_G3_A1_Pin, GPIO_PIN_SET);
		break;
		case  5:
						HAL_GPIO_WritePin(OUT_G3_A0_GPIO_Port, OUT_G3_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(OUT_G3_A1_GPIO_Port, OUT_G3_A1_Pin, GPIO_PIN_SET);
		break;
		case  6:
						HAL_GPIO_WritePin(IN_G4_A0_GPIO_Port, IN_G4_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(IN_G4_A1_GPIO_Port, IN_G4_A1_Pin, GPIO_PIN_SET);
		break;
		case  7:
						HAL_GPIO_WritePin(OUT_G4_A0_GPIO_Port, OUT_G4_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(OUT_G4_A1_GPIO_Port, OUT_G4_A1_Pin, GPIO_PIN_SET);
		break;
		case  8:
						HAL_GPIO_WritePin(IN_G5_A0_GPIO_Port, IN_G5_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(IN_G5_A1_GPIO_Port, IN_G5_A1_Pin, GPIO_PIN_SET);
		break;
		case  9:
						HAL_GPIO_WritePin(OUT_G5_A0_GPIO_Port, OUT_G5_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(OUT_G5_A1_GPIO_Port, OUT_G5_A1_Pin, GPIO_PIN_SET);
		break;
		case  10:
						HAL_GPIO_WritePin(IN_G6_A0_GPIO_Port, IN_G6_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(IN_G6_A1_GPIO_Port, IN_G6_A1_Pin, GPIO_PIN_SET);
		break;
		case  11:
						HAL_GPIO_WritePin(OUT_G6_A0_GPIO_Port, OUT_G6_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(OUT_G6_A1_GPIO_Port, OUT_G6_A1_Pin, GPIO_PIN_SET);
		break;
		case  12:
						HAL_GPIO_WritePin(IN_G7_A0_GPIO_Port, IN_G7_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(IN_G7_A1_GPIO_Port, IN_G7_A1_Pin, GPIO_PIN_SET);
		break;
		case  13:
						HAL_GPIO_WritePin(OUT_G7_A0_GPIO_Port, OUT_G7_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(OUT_G7_A1_GPIO_Port, OUT_G7_A1_Pin, GPIO_PIN_SET);
		break;
		case  14:
						HAL_GPIO_WritePin(IN_G8_A0_GPIO_Port, IN_G8_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(IN_G8_A1_GPIO_Port, IN_G8_A1_Pin, GPIO_PIN_SET);
		break;
		case  15:
						HAL_GPIO_WritePin(OUT_G8_A0_GPIO_Port, OUT_G8_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(OUT_G8_A1_GPIO_Port, OUT_G8_A1_Pin, GPIO_PIN_SET);
		break;
		case  16:
						HAL_GPIO_WritePin(IN_G9_A0_GPIO_Port, IN_G9_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(IN_G9_A1_GPIO_Port, IN_G9_A1_Pin, GPIO_PIN_SET);
		break;
		case  17:
						HAL_GPIO_WritePin(OUT_G9_A0_GPIO_Port, OUT_G9_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(OUT_G9_A1_GPIO_Port, OUT_G9_A1_Pin, GPIO_PIN_SET);
		break;
		case  18:
						HAL_GPIO_WritePin(IN_G10_A0_GPIO_Port, IN_G10_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(IN_G10_A1_GPIO_Port, IN_G10_A1_Pin, GPIO_PIN_SET);
		break;
		case  19:
						HAL_GPIO_WritePin(OUT_G10_A0_GPIO_Port, OUT_G10_A0_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(OUT_G10_A1_GPIO_Port, OUT_G10_A1_Pin, GPIO_PIN_SET);
		break;
		default : break;
	}
}


static void open_gain61(uint8_t port)
{
	switch (port)
	{
		case  0:
						HAL_GPIO_WritePin(IN_G1_A0_GPIO_Port,  IN_G1_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(IN_G1_A1_GPIO_Port,  IN_G1_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  1:                  
						HAL_GPIO_WritePin(OUT_G1_A0_GPIO_Port, OUT_G1_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(OUT_G1_A1_GPIO_Port, OUT_G1_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  2:                  
						HAL_GPIO_WritePin(IN_G2_A0_GPIO_Port,  IN_G2_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(IN_G2_A1_GPIO_Port,  IN_G2_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  3:                  
						HAL_GPIO_WritePin(OUT_G2_A0_GPIO_Port, OUT_G2_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(OUT_G2_A1_GPIO_Port, OUT_G2_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  4:                  
						HAL_GPIO_WritePin(IN_G3_A0_GPIO_Port,  IN_G3_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(IN_G3_A1_GPIO_Port,  IN_G3_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  5:                  
						HAL_GPIO_WritePin(OUT_G3_A0_GPIO_Port, OUT_G3_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(OUT_G3_A1_GPIO_Port, OUT_G3_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  6:                  
						HAL_GPIO_WritePin(IN_G4_A0_GPIO_Port,  IN_G4_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(IN_G4_A1_GPIO_Port,  IN_G4_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  7:                  
						HAL_GPIO_WritePin(OUT_G4_A0_GPIO_Port, OUT_G4_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(OUT_G4_A1_GPIO_Port, OUT_G4_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  8:                  
						HAL_GPIO_WritePin(IN_G5_A0_GPIO_Port,  IN_G5_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(IN_G5_A1_GPIO_Port,  IN_G5_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  9:                  
						HAL_GPIO_WritePin(OUT_G5_A0_GPIO_Port, OUT_G5_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(OUT_G5_A1_GPIO_Port, OUT_G5_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  10:                 
						HAL_GPIO_WritePin(IN_G6_A0_GPIO_Port,  IN_G6_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(IN_G6_A1_GPIO_Port,  IN_G6_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  11:                 
						HAL_GPIO_WritePin(OUT_G6_A0_GPIO_Port, OUT_G6_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(OUT_G6_A1_GPIO_Port, OUT_G6_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  12:                 
						HAL_GPIO_WritePin(IN_G7_A0_GPIO_Port,  IN_G7_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(IN_G7_A1_GPIO_Port,  IN_G7_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  13:                 
						HAL_GPIO_WritePin(OUT_G7_A0_GPIO_Port, OUT_G7_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(OUT_G7_A1_GPIO_Port, OUT_G7_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  14:                 
						HAL_GPIO_WritePin(IN_G8_A0_GPIO_Port,  IN_G8_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(IN_G8_A1_GPIO_Port,  IN_G8_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  15:                 
						HAL_GPIO_WritePin(OUT_G8_A0_GPIO_Port, OUT_G8_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(OUT_G8_A1_GPIO_Port, OUT_G8_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  16:                 
						HAL_GPIO_WritePin(IN_G9_A0_GPIO_Port,  IN_G9_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(IN_G9_A1_GPIO_Port,  IN_G9_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  17:                 
						HAL_GPIO_WritePin(OUT_G9_A0_GPIO_Port, OUT_G9_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(OUT_G9_A1_GPIO_Port, OUT_G9_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  18:                 
						HAL_GPIO_WritePin(IN_G10_A0_GPIO_Port, IN_G10_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(IN_G10_A1_GPIO_Port, IN_G10_A1_Pin, GPIO_PIN_RESET);
		break;                    
		case  19:                 
						HAL_GPIO_WritePin(OUT_G10_A0_GPIO_Port, OUT_G10_A0_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(OUT_G10_A1_GPIO_Port, OUT_G10_A1_Pin, GPIO_PIN_RESET);
		break;
		default : break;
	}
}


static void open_curA(uint8_t port)
{
	switch(port)
	{
		case 0:
				HAL_GPIO_WritePin(CU_SW1_A0_GPIO_Port, CU_SW1_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_SW1_A1_GPIO_Port, CU_SW1_A1_Pin, GPIO_PIN_RESET);
		break;
		case 1:
				HAL_GPIO_WritePin(CU_LD1_A0_GPIO_Port, CU_LD1_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_LD1_A1_GPIO_Port, CU_LD1_A1_Pin, GPIO_PIN_RESET);
		break;
		case 2:
				HAL_GPIO_WritePin(CU_SW2_A0_GPIO_Port, CU_SW2_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_SW2_A1_GPIO_Port, CU_SW2_A1_Pin, GPIO_PIN_RESET);
		break;	
		case 3:
				HAL_GPIO_WritePin(CU_LD2_A0_GPIO_Port, CU_LD2_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_LD2_A1_GPIO_Port, CU_LD2_A1_Pin, GPIO_PIN_RESET);
		break;
		
		case 4:
				HAL_GPIO_WritePin(CU_SW3_A0_GPIO_Port, CU_SW3_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_SW3_A1_GPIO_Port, CU_SW3_A1_Pin, GPIO_PIN_RESET);
		break;
		case 5:
				HAL_GPIO_WritePin(CU_LD3_A0_GPIO_Port, CU_LD3_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_LD3_A1_GPIO_Port, CU_LD3_A1_Pin, GPIO_PIN_RESET);
		break;
		case 6:
				HAL_GPIO_WritePin(CU_SW4_A0_GPIO_Port, CU_SW4_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_SW4_A1_GPIO_Port, CU_SW4_A1_Pin, GPIO_PIN_RESET);
		break;	
		case 7:
				HAL_GPIO_WritePin(CU_LD4_A0_GPIO_Port, CU_LD4_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_LD4_A1_GPIO_Port, CU_LD4_A1_Pin, GPIO_PIN_RESET);
		break;
		case 8:
				HAL_GPIO_WritePin(CU_SW5_A0_GPIO_Port, CU_SW5_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_SW5_A1_GPIO_Port, CU_SW5_A1_Pin, GPIO_PIN_RESET);
		break;
		case 9:
				HAL_GPIO_WritePin(CU_LD5_A0_GPIO_Port, CU_LD5_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_LD5_A1_GPIO_Port, CU_LD5_A1_Pin, GPIO_PIN_RESET);
		break;
		case 10:
				HAL_GPIO_WritePin(CU_SW6_A0_GPIO_Port, CU_SW6_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_SW6_A1_GPIO_Port, CU_SW6_A1_Pin, GPIO_PIN_RESET);
		break;	
		case 11:
				HAL_GPIO_WritePin(CU_LD6_A0_GPIO_Port, CU_LD6_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_LD6_A1_GPIO_Port, CU_LD6_A1_Pin, GPIO_PIN_RESET);
		break;
		case 12:
				HAL_GPIO_WritePin(CU_SW7_A0_GPIO_Port, CU_SW7_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_SW7_A1_GPIO_Port, CU_SW7_A1_Pin, GPIO_PIN_RESET);
		break;
		case 13:
				HAL_GPIO_WritePin(CU_LD7_A0_GPIO_Port, CU_LD7_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_LD7_A1_GPIO_Port, CU_LD7_A1_Pin, GPIO_PIN_RESET);
		break;
		case 14:
				HAL_GPIO_WritePin(CU_SW8_A0_GPIO_Port, CU_SW8_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_SW8_A1_GPIO_Port, CU_SW8_A1_Pin, GPIO_PIN_RESET);
		break;	
		case 15:
				HAL_GPIO_WritePin(CU_LD8_A0_GPIO_Port, CU_LD8_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_LD8_A1_GPIO_Port, CU_LD8_A1_Pin, GPIO_PIN_RESET);
		break;	
		case 16:
				HAL_GPIO_WritePin(CU_SW9_A0_GPIO_Port, CU_SW9_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_SW9_A1_GPIO_Port, CU_SW9_A1_Pin, GPIO_PIN_RESET);
		break;
		case 17:
				HAL_GPIO_WritePin(CU_LD9_A0_GPIO_Port, CU_LD9_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_LD9_A1_GPIO_Port, CU_LD9_A1_Pin, GPIO_PIN_RESET);
		break;
		case 18:
				HAL_GPIO_WritePin(CU_SW10_A0_GPIO_Port, CU_SW10_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_SW10_A1_GPIO_Port, CU_SW10_A1_Pin, GPIO_PIN_RESET);
		break;	
		case 19:
				HAL_GPIO_WritePin(CU_LD10_A0_GPIO_Port, CU_LD10_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_LD10_A1_GPIO_Port, CU_LD10_A1_Pin, GPIO_PIN_RESET);
		break;		
		default : break;
	}
}


static void open_curmA(uint8_t port)
{
	switch(port)
	{
		case 0:
				HAL_GPIO_WritePin(CU_SW1_A0_GPIO_Port,  CU_SW1_A0_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(CU_SW1_A1_GPIO_Port,  CU_SW1_A1_Pin, GPIO_PIN_RESET);
		break;                
		case 1:               
				HAL_GPIO_WritePin(CU_LD1_A0_GPIO_Port,  CU_LD1_A0_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(CU_LD1_A1_GPIO_Port,  CU_LD1_A1_Pin, GPIO_PIN_RESET);
		break;                
		case 2:               
				HAL_GPIO_WritePin(CU_SW2_A0_GPIO_Port,  CU_SW2_A0_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(CU_SW2_A1_GPIO_Port,  CU_SW2_A1_Pin, GPIO_PIN_RESET);
		break;	              
		case 3:               
				HAL_GPIO_WritePin(CU_LD2_A0_GPIO_Port,  CU_LD2_A0_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(CU_LD2_A1_GPIO_Port,  CU_LD2_A1_Pin, GPIO_PIN_RESET);
		break;                
		                      
		case 4:               
				HAL_GPIO_WritePin(CU_SW3_A0_GPIO_Port,  CU_SW3_A0_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(CU_SW3_A1_GPIO_Port,  CU_SW3_A1_Pin, GPIO_PIN_RESET);
		break;                
		case 5:               
				HAL_GPIO_WritePin(CU_LD3_A0_GPIO_Port,  CU_LD3_A0_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(CU_LD3_A1_GPIO_Port,  CU_LD3_A1_Pin, GPIO_PIN_RESET);
		break;                
		case 6:               
				HAL_GPIO_WritePin(CU_SW4_A0_GPIO_Port,  CU_SW4_A0_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(CU_SW4_A1_GPIO_Port,  CU_SW4_A1_Pin, GPIO_PIN_RESET);
		break;	              
		case 7:               
				HAL_GPIO_WritePin(CU_LD4_A0_GPIO_Port,  CU_LD4_A0_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(CU_LD4_A1_GPIO_Port,  CU_LD4_A1_Pin, GPIO_PIN_RESET);
		break;                
		case 8:               
				HAL_GPIO_WritePin(CU_SW5_A0_GPIO_Port,  CU_SW5_A0_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(CU_SW5_A1_GPIO_Port,  CU_SW5_A1_Pin, GPIO_PIN_RESET);
		break;                
		case 9:               
				HAL_GPIO_WritePin(CU_LD5_A0_GPIO_Port,  CU_LD5_A0_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(CU_LD5_A1_GPIO_Port,  CU_LD5_A1_Pin, GPIO_PIN_RESET);
		break;                
		case 10:              
				HAL_GPIO_WritePin(CU_SW6_A0_GPIO_Port,  CU_SW6_A0_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(CU_SW6_A1_GPIO_Port,  CU_SW6_A1_Pin, GPIO_PIN_RESET);
		break;	              
		case 11:              
				HAL_GPIO_WritePin(CU_LD6_A0_GPIO_Port,  CU_LD6_A0_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(CU_LD6_A1_GPIO_Port,  CU_LD6_A1_Pin, GPIO_PIN_RESET);
		break;                
		case 12:              
				HAL_GPIO_WritePin(CU_SW7_A0_GPIO_Port,  CU_SW7_A0_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(CU_SW7_A1_GPIO_Port,  CU_SW7_A1_Pin, GPIO_PIN_RESET);
		break;                
		case 13:              
				HAL_GPIO_WritePin(CU_LD7_A0_GPIO_Port,  CU_LD7_A0_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(CU_LD7_A1_GPIO_Port,  CU_LD7_A1_Pin, GPIO_PIN_RESET);
		break;                
		case 14:              
				HAL_GPIO_WritePin(CU_SW8_A0_GPIO_Port,  CU_SW8_A0_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(CU_SW8_A1_GPIO_Port,  CU_SW8_A1_Pin, GPIO_PIN_RESET);
		break;	              
		case 15:              
				HAL_GPIO_WritePin(CU_LD8_A0_GPIO_Port,  CU_LD8_A0_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(CU_LD8_A1_GPIO_Port,  CU_LD8_A1_Pin, GPIO_PIN_RESET);
		break;	              
		case 16:              
				HAL_GPIO_WritePin(CU_SW9_A0_GPIO_Port,  CU_SW9_A0_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(CU_SW9_A1_GPIO_Port,  CU_SW9_A1_Pin, GPIO_PIN_RESET);
		break;                
		case 17:              
				HAL_GPIO_WritePin(CU_LD9_A0_GPIO_Port,  CU_LD9_A0_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(CU_LD9_A1_GPIO_Port,  CU_LD9_A1_Pin, GPIO_PIN_RESET);
		break;                
		case 18:              
				HAL_GPIO_WritePin(CU_SW10_A0_GPIO_Port, CU_SW10_A0_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(CU_SW10_A1_GPIO_Port, CU_SW10_A1_Pin, GPIO_PIN_RESET);
		break;	              
		case 19:              
				HAL_GPIO_WritePin(CU_LD10_A0_GPIO_Port, CU_LD10_A0_Pin, GPIO_PIN_SET);
				HAL_GPIO_WritePin(CU_LD10_A1_GPIO_Port, CU_LD10_A1_Pin, GPIO_PIN_RESET);
		break;		
		default : break;
	}
}

static void open_curuA(uint8_t port)
{
	switch(port)
	{
		case 0:
				HAL_GPIO_WritePin(CU_SW1_A0_GPIO_Port,  CU_SW1_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_SW1_A1_GPIO_Port,  CU_SW1_A1_Pin, GPIO_PIN_SET);
		break;                
		case 1:               
				HAL_GPIO_WritePin(CU_LD1_A0_GPIO_Port,  CU_LD1_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_LD1_A1_GPIO_Port,  CU_LD1_A1_Pin, GPIO_PIN_SET);
		break;                
		case 2:               
				HAL_GPIO_WritePin(CU_SW2_A0_GPIO_Port,  CU_SW2_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_SW2_A1_GPIO_Port,  CU_SW2_A1_Pin, GPIO_PIN_SET);
		break;	              
		case 3:               
				HAL_GPIO_WritePin(CU_LD2_A0_GPIO_Port,  CU_LD2_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_LD2_A1_GPIO_Port,  CU_LD2_A1_Pin, GPIO_PIN_SET);
		break;                
		                      
		case 4:               
				HAL_GPIO_WritePin(CU_SW3_A0_GPIO_Port,  CU_SW3_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_SW3_A1_GPIO_Port,  CU_SW3_A1_Pin, GPIO_PIN_SET);
		break;                
		case 5:               
				HAL_GPIO_WritePin(CU_LD3_A0_GPIO_Port,  CU_LD3_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_LD3_A1_GPIO_Port,  CU_LD3_A1_Pin, GPIO_PIN_SET);
		break;                
		case 6:               
				HAL_GPIO_WritePin(CU_SW4_A0_GPIO_Port,  CU_SW4_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_SW4_A1_GPIO_Port,  CU_SW4_A1_Pin, GPIO_PIN_SET);
		break;	              
		case 7:               
				HAL_GPIO_WritePin(CU_LD4_A0_GPIO_Port,  CU_LD4_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_LD4_A1_GPIO_Port,  CU_LD4_A1_Pin, GPIO_PIN_SET);
		break;                
		case 8:               
				HAL_GPIO_WritePin(CU_SW5_A0_GPIO_Port,  CU_SW5_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_SW5_A1_GPIO_Port,  CU_SW5_A1_Pin, GPIO_PIN_SET);
		break;                
		case 9:               
				HAL_GPIO_WritePin(CU_LD5_A0_GPIO_Port,  CU_LD5_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_LD5_A1_GPIO_Port,  CU_LD5_A1_Pin, GPIO_PIN_SET);
		break;                
		case 10:              
				HAL_GPIO_WritePin(CU_SW6_A0_GPIO_Port,  CU_SW6_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_SW6_A1_GPIO_Port,  CU_SW6_A1_Pin, GPIO_PIN_SET);
		break;	              
		case 11:              
				HAL_GPIO_WritePin(CU_LD6_A0_GPIO_Port,  CU_LD6_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_LD6_A1_GPIO_Port,  CU_LD6_A1_Pin, GPIO_PIN_SET);
		break;                
		case 12:              
				HAL_GPIO_WritePin(CU_SW7_A0_GPIO_Port,  CU_SW7_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_SW7_A1_GPIO_Port,  CU_SW7_A1_Pin, GPIO_PIN_SET);
		break;                
		case 13:              
				HAL_GPIO_WritePin(CU_LD7_A0_GPIO_Port,  CU_LD7_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_LD7_A1_GPIO_Port,  CU_LD7_A1_Pin, GPIO_PIN_SET);
		break;                
		case 14:              
				HAL_GPIO_WritePin(CU_SW8_A0_GPIO_Port,  CU_SW8_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_SW8_A1_GPIO_Port,  CU_SW8_A1_Pin, GPIO_PIN_SET);
		break;	              
		case 15:              
				HAL_GPIO_WritePin(CU_LD8_A0_GPIO_Port,  CU_LD8_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_LD8_A1_GPIO_Port,  CU_LD8_A1_Pin, GPIO_PIN_SET);
		break;	              
		case 16:              
				HAL_GPIO_WritePin(CU_SW9_A0_GPIO_Port,  CU_SW9_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_SW9_A1_GPIO_Port,  CU_SW9_A1_Pin, GPIO_PIN_SET);
		break;                
		case 17:              
				HAL_GPIO_WritePin(CU_LD9_A0_GPIO_Port,  CU_LD9_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_LD9_A1_GPIO_Port,  CU_LD9_A1_Pin, GPIO_PIN_SET);
		break;                
		case 18:              
				HAL_GPIO_WritePin(CU_SW10_A0_GPIO_Port, CU_SW10_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_SW10_A1_GPIO_Port, CU_SW10_A1_Pin, GPIO_PIN_SET);
		break;	              
		case 19:              
				HAL_GPIO_WritePin(CU_LD10_A0_GPIO_Port, CU_LD10_A0_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(CU_LD10_A1_GPIO_Port, CU_LD10_A1_Pin, GPIO_PIN_SET);
		break;		
		default : break;
	}
}





