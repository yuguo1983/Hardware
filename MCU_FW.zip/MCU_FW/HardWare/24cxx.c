#include "include.h"

//初始化IIC接口

int AT24CXX_Init(void)
{
	bsp_InitI2C();
	return 1;
}

//在AT24CXX指定地址读出一个数据

//ReadAddr:开始读数的地址  

//返回值  :读到的数据

uint8_t AT24CXX_ReadOneByte(uint32_t ReadAddr)
{   
	uint8_t temp=0;        
    i2c_Start();  
	if(EE_TYPE>AT24C16)            //为了兼容24Cxx中其他的版本
	{
		i2c_SendByte(ADDRESS);    //发送写命令
		i2c_WaitAck();
		i2c_SendByte(ReadAddr>>8);    //发送高地址
		i2c_WaitAck();  
	}else      i2c_SendByte(ADDRESS+((ReadAddr/256)<<1));   //发送器件地址0XA0,写数据  
	i2c_WaitAck(); 
    i2c_SendByte(ReadAddr%256);   //发送低地址
	i2c_WaitAck();     
	i2c_Start();     
	i2c_SendByte(ADDRESS|0x01);           //进入接收模式    
	i2c_WaitAck();  
    temp=i2c_ReadByte();     //读一个字节，非应答信号信号    
    i2c_Stop();        //产生一个停止条件     
	return temp;

}

//在AT24CXX指定地址写入一个数据

//WriteAddr  :写入数据的目的地址    

//DataToWrite:要写入的数据

int AT24CXX_WriteOneByte(uint32_t WriteAddr,uint8_t DataToWrite)

{            

    i2c_Start();  
	if(EE_TYPE>AT24C16)
	{
		i2c_SendByte(ADDRESS);     //发送写命令
		i2c_WaitAck();
		i2c_SendByte(WriteAddr>>8);    //发送高地址

	}else
	{
		i2c_SendByte(ADDRESS+((WriteAddr/256)<<1));   //发送器件地址0XA0,写数据 
	}  
	i2c_WaitAck();    
    i2c_SendByte(WriteAddr%256);   //发送低地址
	i2c_WaitAck();      
	i2c_SendByte(DataToWrite);     //发送字节    
	i2c_WaitAck();         
	i2c_Stop();    //产生一个停止条件 
	HAL_Delay(10);  

	return 1;
}

//在AT24CXX里面的指定地址开始写入长度为Len的数据

//该函数用于写入16bit或者32bit的数据.

//WriteAddr  :开始写入的地址  

//DataToWrite:数据数组首地址

//Len        :要写入数据的长度2,4

void AT24CXX_WriteLenByte(uint16_t WriteAddr,uint32_t DataToWrite,uint8_t Len)
{ 
	uint8_t t;
	for(t=0;t<Len;t++)
	{
		AT24CXX_WriteOneByte(WriteAddr+t,(DataToWrite>>(8*t))&0xff);
	}    
}

 



int AT24CXX_WriteDWord(uint32_t WriteAddr,uint32_t DATA)
{
	uint8_t temp[4]={0};
	temp[0]=((DATA>>24)&	0xff);
	temp[1]=((DATA>>16)&	0xff);
	temp[2]=((DATA>>8) &	0xff);
	temp[3]=((DATA>>0) &	0xff);
	AT24CXX_Write(WriteAddr,temp,4);
	return 1;
}



int AT24CXX_WriteDWords(uint32_t WriteAddr,uint32_t *DATA,uint32_t len)
{
	uint8_t t;
	
	for(t=0;t<len;t++)
	{
		AT24CXX_WriteDWord(WriteAddr+t*4,*DATA++);
	} 
return 1;  
}











//在AT24CXX里面的指定地址开始读出长度为Len的数据

//该函数用于读出16bit或者32bit的数据.

//ReadAddr   :开始读出的地址 

//返回值     :数据

//Len        :要读出数据的长度2,4

uint32_t AT24CXX_ReadLenByte(uint16_t ReadAddr,uint8_t Len)
{ 
	uint8_t t;
	uint32_t temp=0;
	for(t=0;t<Len;t++) 
	{
		temp<<=8;
		temp+=AT24CXX_ReadOneByte(ReadAddr+Len-t-1);    
	}
	return temp;     
}




uint32_t AT24CXX_ReadDWord(uint32_t ReadAddr)
{
	uint8_t temp[4]={0};
	uint32_t data=0;
	AT24CXX_Read(ReadAddr,temp,4);
	data=temp[0];
	data=data<<8;
	data|=temp[1];
	data=data<<8;
	data|=temp[2];
	data=data<<8;
	data|=temp[3];
	return data;
}
#define MEMORY_BUFF_LEN (256)
static unsigned char ucMemBuff[MEMORY_BUFF_LEN] = {0};
int AT24CXX_ReadDWords(uint32_t ReadAddr,uint32_t *data,uint32_t len)
{
		volatile int i = 0;
	unsigned char *pucFrame;
	uint32_t uiTempValue = 0;
	volatile uint32_t uiTempAddr = 0;
	AT24CXX_Read(ReadAddr,ucMemBuff,len*4);
	pucFrame=ucMemBuff;
	for(i = 0; i < len; i++)
    {
		uiTempValue = *pucFrame++;
		
		uiTempValue <<= 8;
		uiTempValue |= *pucFrame++;
		
		uiTempValue <<= 8;		
		uiTempValue |= *pucFrame++;
		
		uiTempValue <<= 8;
		uiTempValue |= *pucFrame++;
		
		*data++ = uiTempValue;
		}
	return 1;

}









//检查AT24CXX是否正常

//这里用了24XX的最后一个地址(255)来存储标志字.

//如果用其他24C系列,这个地址要修改

//返回1:检测失败

//返回0:检测成功

uint8_t AT24CXX_Check(void)
{
	uint8_t temp;
	temp=AT24CXX_ReadOneByte(255);//避免每次开机都写AT24CXX    
	if(temp==0X55)return 0;    
	else//排除第一次初始化的情况
	{
		AT24CXX_WriteOneByte(255,0X55);
		temp=AT24CXX_ReadOneByte(255);   
	if(temp==0X55)return 0;
	}
	return 1;   
}

 

//在AT24CXX里面的指定地址开始读出指定个数的数据

//ReadAddr :开始读出的地址 对24c02为0~255

//pBuffer  :数据数组首地址

//NumToRead:要读出数据的个数

int AT24CXX_Read(uint32_t ReadAddr,uint8_t *pBuffer,uint32_t NumToRead)
{
	while(NumToRead)
	{
		*pBuffer++=AT24CXX_ReadOneByte(ReadAddr++);
		NumToRead--;
	}
	return 1;
}  

//在AT24CXX里面的指定地址开始写入指定个数的数据

//WriteAddr :开始写入的地址 对24c02为0~255

//pBuffer   :数据数组首地址

//NumToWrite:要写入数据的个数

int AT24CXX_Write(uint32_t WriteAddr,uint8_t *pBuffer,uint32_t NumToWrite)
{
	while(NumToWrite--)
	{
		AT24CXX_WriteOneByte(WriteAddr,*pBuffer);
		WriteAddr++;
		pBuffer++;
	}
	return 1;
}

