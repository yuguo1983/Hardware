#ifndef _IIC_H
#define _IIC_H
#include "main.h"
#include "stdio.h"




#define I2C_SCL_GPIO_Port GPIOF
#define I2C_SCL_Pin GPIO_PIN_2

#define I2C_SDA_GPIO_Port GPIOF
#define I2C_SDA_Pin GPIO_PIN_3





/* ????SCL?SDA?? */
#define I2C_SCL_1() (I2C_SCL_GPIO_Port->BSRR= I2C_SCL_Pin )   /* SCL4 = 1 */
#define I2C_SCL_0() (I2C_SCL_GPIO_Port->BSRR= (uint32_t)I2C_SCL_Pin<<16U)   /* SCL4 = 0 */
#define I2C_SDA_1() (I2C_SDA_GPIO_Port->BSRR= I2C_SDA_Pin )   /* SDA4 = 1 */
#define I2C_SDA_0() (I2C_SDA_GPIO_Port->BSRR= (uint32_t)I2C_SDA_Pin<<16U)   /* SDA4 = 0 */
  

#define I2C_SDA_READ() ((I2C_SDA_GPIO_Port->IDR & I2C_SDA_Pin) != 0) 
#define I2C_SCL_READ() ((I2C_SCL_GPIO_Port->IDR & I2C_SCL_Pin) != 0) 







void bsp_InitI2C(void);
void IIC_DelayUS(uint32_t n);
static void i2c_Delay(void);
void i2c_Start(void);
void i2c_Stop(void);
void i2c_SendByte(uint8_t _ucByte);
uint8_t i2c_ReadByte(void);
uint8_t i2c_WaitAck(void);
void i2c_Ack(void);
void i2c_NAck(void);
uint8_t i2c_CheckDevice(uint8_t _Address);
void i2c_reStart(void);
#endif
