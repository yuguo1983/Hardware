#include "include.h"


#define W25Q_PageSize 256

extern uint8_t port; 
extern SPI_HandleTypeDef hspi2;

void FLASH_INIT(void)
{   

}



//SPIx ��дһ���ֽ�
//TxData:Ҫд����ֽ�
//����ֵ:��ȡ�����ֽ�
unsigned char SendData(unsigned char reg) 
{
	uint8_t temp=0;
	HAL_SPI_TransmitReceive(&hspi2,&reg,&temp,1,10);
	return temp;
}
  
void W25Q_WriteEnable(void)
{
  W25_CS_0();
  SendData(WriteEnable);
  W25_CS_1();
}

void W25Q_WriteDisable(void)
{
  W25_CS_0();
  SendData(WriteDisable);
  W25_CS_1();
}

unsigned char W25Q_ReadStatusRegister(void)
{
  unsigned char StatusRegister = 0;
  
  W25_CS_0();
  SendData(ReadStatusRegister);
  StatusRegister = SendData(Dummy_Byte);
  W25_CS_1();
  
  return StatusRegister;
}

unsigned char W25Q_ReadStatusRegister2(void)
{
  unsigned char StatusRegister = 0;
  
  W25_CS_0();
  SendData(ReadStatusRegister2);
  StatusRegister = SendData(Dummy_Byte);
  W25_CS_1();
  
  return StatusRegister;
}

unsigned char W25Q_ReadStatusRegister3(void)
{
  unsigned char StatusRegister = 0;
  
  W25_CS_0();
  SendData(ReadStatusRegister3);
  StatusRegister = SendData(Dummy_Byte);
  W25_CS_1();
  
  return StatusRegister;
}

void W25Q_WriteStatusRegister(unsigned char Byte)
{
  W25_CS_0();
  SendData(WriteStatusRegister);
  SendData(Byte);
  W25_CS_1();
}

void GD25Q_WriteStatusRegister(unsigned int Word)
{
  W25_CS_0();
  SendData(WriteStatusRegister);
  SendData((unsigned char)Word);
  SendData((unsigned char)(Word>>8));
  W25_CS_1();
}

void W25Q_WriteStatusRegister2(unsigned char Byte)
{
  W25_CS_0();
  SendData(WriteStatusRegister2);
  SendData(Byte);
  W25_CS_1();
}

void W25Q_WriteAddressRegister(unsigned char Byte)
{
  W25_CS_0();
  SendData(WriteAddressRegister);
  SendData(Byte);
  W25_CS_1();
}

unsigned char W25Q_ReadAddressRegister(void)
{
  unsigned char AddressRegister = 0;
  
  W25_CS_0();
  SendData(ReadAddressRegister);
  AddressRegister = SendData(Dummy_Byte);
  W25_CS_1();
  
  return AddressRegister;
}

unsigned char W25Q_ByteRead(unsigned long ReadAddr)
{
  unsigned long Re;
  
  W25_CS_0();
  
  SendData(Read_Data);
  SendData((ReadAddr & 0xFF0000) >> 16);
  SendData((ReadAddr& 0xFF00) >> 8);
  SendData(ReadAddr & 0xFF);
  
  Re = SendData(Dummy_Byte);

  W25_CS_1();
  
  return Re;
}

unsigned char W25Q_FasttRead(unsigned long ReadAddr)
{
  unsigned long Temp = 0;
  
  W25_CS_0();
  
  SendData(FastReadData);
  SendData((ReadAddr & 0xFF0000) >> 16);
  SendData((ReadAddr& 0xFF00) >> 8);
  SendData(ReadAddr & 0xFF);
  
  SendData(Dummy_Byte);
  
  Temp = SendData(Dummy_Byte);

  W25_CS_1();
  
  return Temp;
}

void W25Q_BufferRead(unsigned char* pBuffer, unsigned long ReadAddr, unsigned int NumByteToRead)
{
  if(ReadAddr >= 16777216)      //2^24
  {
    W25Q_WriteEnable();
    W25Q_WriteAddressRegister(0x01);
  }
  W25_CS_0();
  SendData(Read_Data);
  SendData((ReadAddr & 0xFF0000) >> 16);
  SendData((ReadAddr& 0xFF00) >> 8);
  SendData(ReadAddr & 0xFF);

  while(NumByteToRead--)
  {
    *pBuffer = SendData(Dummy_Byte);
    pBuffer++;
  }
  W25_CS_1();
//  W25Q_WriteEnable();
  W25Q_WriteAddressRegister(0x00);
}

void W25Q_SectorErase(unsigned long SectorAddr)
{
  W25Q_WriteEnable();
  W25_CS_0();
  SendData(SectorErase);
  SendData((SectorAddr & 0xFF0000) >> 16);
  SendData((SectorAddr & 0xFF00) >> 8);
  SendData(SectorAddr & 0xFF);
  W25_CS_1();
  W25Q_WaitForWriteEnd();
}

void W25Q_BlockErase(unsigned long BlockAddr)
{
  W25Q_WriteEnable();
  W25_CS_0();
  SendData(BlockErase);
  
  SendData((BlockAddr & 0xFF0000) >> 16);
  SendData((BlockAddr & 0xFF00) >> 8);
  SendData(BlockAddr & 0xFF);
  W25_CS_1();
  W25Q_WaitForWriteEnd();
}

uint8_t W25Q_ChipErase(void)
{
	uint8_t ret=0;
  W25Q_WriteEnable();
  W25_CS_0();
  SendData(ChipErase);
  W25_CS_1();
 ret= W25Q_WaitForWriteEnd();
	return ret;
}

void W25Q_PowerDown()
{
  W25Q_WriteEnable();
  W25_CS_0();
  SendData(Power_Down);
  W25_CS_1();
  W25Q_WaitForWriteEnd();
}

void W25Q_ReleasePowerDown()
{
  W25Q_WriteEnable();
  W25_CS_0();
  SendData(ReleacePowerDown);
  W25_CS_1();
  W25Q_WaitForWriteEnd();
}

unsigned char W25Q_ReadDeviceID(void)
{
  unsigned char DeviceID = 0;
  W25_CS_0();
  
  SendData(ReadDeviceID);
  SendData(Dummy_Byte);
  SendData(Dummy_Byte);
  SendData(Dummy_Byte);
  
  DeviceID = SendData(Dummy_Byte);
  
  W25_CS_1();      
  
  return DeviceID;
}

unsigned int W25Q_ReadManuID_DeviceID(unsigned long ReadManu_DeviceID_Addr)
{
  unsigned int ManuID_DeviceID = 0;
  unsigned char ManufacturerID = 0,  DeviceID = 0;
  
  W25_CS_0();
  SendData(ReadManuIDDeviceID);
  
  SendData((ReadManu_DeviceID_Addr & 0xFF0000) >> 16);
  SendData((ReadManu_DeviceID_Addr & 0xFF00) >> 8);
  SendData(ReadManu_DeviceID_Addr & 0xFF);
  
  if(ReadManu_DeviceID_Addr==1)
  {
    DeviceID = SendData(Dummy_Byte);
    ManufacturerID = SendData(Dummy_Byte);
  }
  else 
  {
    ManufacturerID = SendData(Dummy_Byte);
    DeviceID = SendData(Dummy_Byte);
  }
  ManuID_DeviceID = ((ManufacturerID<<8) | DeviceID);
  W25_CS_1();      
  
  return ManuID_DeviceID;
}


unsigned long W25Q_ReadJedecID(void)
{
  unsigned long JEDECID = 0, Temp0 = 0, Temp1 = 0, Temp2 = 0;
  
  W25_CS_0();
  SendData(ReadJedec_ID);
  Temp0 = SendData(Dummy_Byte);
  Temp1 = SendData(Dummy_Byte);
  Temp2 = SendData(Dummy_Byte);
  W25_CS_1();  
  JEDECID = (Temp0 << 16) | (Temp1 << 8) | Temp2;
  
  return JEDECID;
}


void W25Q_ByteWrite(unsigned char Byte, unsigned long WriteAddr)
{
  W25Q_WriteEnable(); 
  W25_CS_0();
  SendData(Page_Program);
  SendData((WriteAddr & 0xFF0000) >> 16);
  SendData((WriteAddr & 0xFF00) >> 8);  
  SendData(WriteAddr & 0xFF);
  
  SendData(Byte); 
  W25_CS_1();
  W25Q_WaitForWriteEnd();
}

void W25Q_PageWrite(unsigned char* pBuffer, unsigned long WriteAddr, unsigned int NumByteToWrite)
{
  if(WriteAddr >= 16777216)     //2^24
  {
    W25Q_WriteEnable();
    W25Q_WriteAddressRegister(0x01);
  }
  W25Q_WriteEnable(); 
  W25_CS_0();
  SendData(Page_Program);
  SendData((WriteAddr & 0xFF0000) >> 16);
  SendData((WriteAddr & 0xFF00) >> 8);  
  SendData(WriteAddr & 0xFF);
  
  while(NumByteToWrite--)
  {
    SendData(*pBuffer);
    pBuffer++; 
  }
  W25_CS_1();
  W25Q_WaitForWriteEnd();
//  W25Q_WriteEnable();
  W25Q_WriteAddressRegister(0x00);
}






void W25Q_BufferWrite(unsigned char* pBuffer, unsigned long WriteAddr, unsigned int NumByteToWrite)
{
  unsigned char NumOfPage = 0, NumOfSingle = 0, Addr = 0, count = 0, temp = 0;

  Addr = WriteAddr % W25Q_PageSize;                                        
  count = W25Q_PageSize - Addr;
  NumOfPage =  NumByteToWrite / W25Q_PageSize;
  NumOfSingle = NumByteToWrite % W25Q_PageSize;
  
  if(Addr == 0) /* WriteAddr is SPI_FLASH_PageSize aligned  */                  //��ַ��ҳ�����
  {
    if(NumOfPage == 0) /* NumByteToWrite < SPI_FLASH_PageSize */                //����һҳ����
    {
      W25Q_PageWrite(pBuffer, WriteAddr, NumByteToWrite);
    }
    else /* NumByteToWrite > SPI_FLASH_PageSize */ 
    {
      while(NumOfPage--)
      {
        W25Q_PageWrite(pBuffer, WriteAddr, W25Q_PageSize);
        WriteAddr +=  W25Q_PageSize;
        pBuffer += W25Q_PageSize;  
      }    
     
      W25Q_PageWrite(pBuffer, WriteAddr, NumOfSingle);
    }
  }
  else /* WriteAddr is not SPI_FLASH_PageSize aligned  */                       //��ַ�Ƿ�ҳ�����
  {
    if(NumOfPage== 0) /* NumByteToWrite < SPI_FLASH_PageSize */
    {
      if(NumOfSingle > count) /* (NumByteToWrite + WriteAddr) > SPI_FLASH_PageSize */
      {
        temp = NumOfSingle - count;
      
        W25Q_PageWrite(pBuffer, WriteAddr, count);
        WriteAddr +=  count;
        pBuffer += count; 
        
        W25Q_PageWrite(pBuffer, WriteAddr, temp);
      }
      else
      {
        W25Q_PageWrite(pBuffer, WriteAddr, NumByteToWrite);
      }
    }
    else /* NumByteToWrite > SPI_FLASH_PageSize */
    {
      NumByteToWrite -= count;
      NumOfPage =  NumByteToWrite / W25Q_PageSize;
      NumOfSingle = NumByteToWrite % W25Q_PageSize;
      
      W25Q_PageWrite(pBuffer, WriteAddr, count);
      WriteAddr +=  count;
      pBuffer += count;  
     
      while(NumOfPage--)
      {
        W25Q_PageWrite(pBuffer, WriteAddr, W25Q_PageSize);
        WriteAddr +=  W25Q_PageSize;
        pBuffer += W25Q_PageSize;
      }
      
      if(NumOfSingle != 0)
      {
        W25Q_PageWrite(pBuffer, WriteAddr, NumOfSingle);
      }
    }
  }
}

uint8_t W25Q_WaitForWriteEnd(void)
{
  unsigned char FLASH_Status = 0;
  unsigned long i = 0;
  W25_CS_0();
  SendData(ReadStatusRegister);
  do
  {
    FLASH_Status = SendData(Dummy_Byte);
    i++;
    //if(i>=500000) break;      //������   
    if(i>=500000000)
		{		
			return 1;
//			break;   //����Ĳ���
		}

  } while((FLASH_Status & WriteStatusRegister) == 0x01);
  
  W25_CS_1();
	return 0;
}

void W25Q_EnterQPIMode(void)
{
  W25Q_WriteEnable();
  W25_CS_0();
  SendData(EnterQPIMode);
  W25_CS_1();
  W25Q_WaitForWriteEnd();
}
