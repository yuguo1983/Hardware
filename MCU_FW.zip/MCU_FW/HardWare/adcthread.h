#ifndef _ADC_THREAD_H_
#define _ADC_THREAD_H_

#include <stdint.h>

#include "include.h"
typedef uint32_t (*pfunADCCallback)(uint32_t,uint32_t);

#define ADC_BUFF_LEN (8)

typedef struct
{
    //MON
    volatile uint32_t vuiCount; //int count
	volatile uint32_t vuiInit;  //is initial
    volatile uint32_t vuiIndex; //buff index
    volatile uint32_t vuiIsReflash;	//is reflash
    volatile int32_t viSum;     //sum
    int32_t iCode;              //filter adc code
    int32_t iValue;	            //calcute result 
    volatile int16_t Buff[ADC_BUFF_LEN];
}
_srtADCPort;

typedef struct
{
    _srtADCPort Port1;  //adc module port 1
    _srtADCPort Port2;  //adc module port 1
    _srtADCPort Port3;  //adc module port 1
    _srtADCPort Port4;  //adc module port 1
    _srtADCPort Port5;  //adc module port 1
    _srtADCPort Port6;  //adc module port 1
    _srtADCPort Port7;  //adc module port 1
    _srtADCPort Port8;  //adc module port 1

	
    volatile uint32_t vuiChannel;   //sample channel
    volatile uint32_t vuiIsTimeOut; //is adc int time out
    volatile uint32_t vuiTick;      //is adc int tick
    uint32_t uiSPS;                //channel sps	
}
_srtADCModule;              //adc module can be

typedef struct
{
    _srtADCModule Module1;  //hardware have two adc module
}
_srtADCChannel;

#define ADC_MONIT_CHANNEL_MAX (7)

typedef struct
{
    //MON
	int32_t uiVCheck;	
	int32_t uimACheck;	
	int32_t uiuACheck;	
    int32_t uiCode;        //filter adc code
    uint32_t uiIsReflash;	//is reflash
	pfunADCCallback pCallback;
}
_srtADCBase;

typedef struct
{
    _srtADCBase Base1;
    _srtADCBase Base2;
    _srtADCBase Base3;
    _srtADCBase Base4;

}
_srtADCThread;


//typedef struct
//{
//	volatile uint32_t uiStatus;
//	volatile uint32_t uiIsReflash;
//	volatile uint32_t uiTick ;
//	uint32_t uiPCode;
//	uint32_t uiPValue;
//	uint32_t uiShuntR;           //shunt resistor
//	uint32_t uiMaxExpected;      //expect
//}
//_srtINABase;
//typedef struct
//{
//    _srtINABase Base1;
//    _srtINABase Base2;
//    _srtINABase Base3;
//    _srtINABase Base4;
//    _srtINABase Base5;
//    _srtINABase Base6;
//    _srtINABase Base7;
//    _srtINABase Base8;
//    _srtINABase Base9;
//    _srtINABase Base10;
//}
//_srtINAThread;
void ADC_THREAD_Init(void);
_srtADCBase *ADC_THREAD_GetInfor( uint32_t uiPort);
int ADC_THREAD_Poll(uint32_t uiPort);
int ADC_THREAD_ClearOff(uint32_t uiPort);
void ADC_THREAD_Callback(uint32_t uiChannel,uint32_t uiPort,int16_t siTemp);

//void INA2XX_THREAD_Init(void);
//int INA2XX_THREAD_Callback(uint32_t uiPort);
//int INA2XX_THREAD_SetOVC(uint32_t uiPort,uint32_t uiVoltage,uint32_t uiCurrent);

#endif
