/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __CALIBRATION_H
#define __CALIBRATION_H



#include "include.h"

typedef struct
{
	int32_t  uivmonmin;
	int32_t  uivmonmax;
	
	int32_t  uivmin;
	int32_t  uivmax;
	
	int32_t  uiCodeMin ;
	int32_t  uiCodeMax ;
	
	int32_t  uiOutMin ;
	int32_t  uiOutMax ;

	int32_t uimAOffset; //������Сֵ,��uAУ׼ʱ������¼
	int32_t uiuAOffset; //�������ֵ,��uAУ׼ʱ������¼
	
	uint32_t uiIsValid;  //�Ƿ�У׼��
}
_CalibData;
#define CLIB_ITEM_OFFSET(member)	(((uint32_t)(&(((_CalibData *)0)->member))) / sizeof(uint32_t))
typedef struct {
_CalibData port1;
_CalibData port2;
}_Port_num;

typedef struct{
uint32_t chanel;
uint32_t ustick;
uint32_t starttick;
uint32_t triger;
uint32_t recovervol;
uint32_t recovercou;
uint32_t type;
uint32_t rain;
uint32_t finsh;
uint32_t valid;
uint32_t status;
}_Cliab_poll;

extern uint8_t stata_flag;


void check_calib(void);
uint16_t  set_cur(uint16_t input_value);
uint16_t  cov_vol(uint16_t input_value);
void start_calib(uint8_t ch,uint16_t *const_arr ,uint16_t input_value,uint16_t *input_arr);

uint64_t CALIB_VOutToDACCode(int64_t uiValue);
uint64_t CALIB_IOutToDACCode(int64_t uiValue);

uint64_t CALIB_IdisToDACCode(int64_t uiValue);











#endif
