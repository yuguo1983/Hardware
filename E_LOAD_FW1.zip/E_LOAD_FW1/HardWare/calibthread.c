#include <stdint.h>
#include <stddef.h>
#include "include.h"
#include "calibthread.h"


#define CALIB_DAC_UMIN    100

#define CALIB_DAC_UMAX    1100


#define CALIB_CC_UMIN    60
#define CALIB_CC_UMAX    250

#define CALIB_CC_MIN    10
#define CALIB_CC_MAX    100

#define CALIB_POLL_TIMEOUT    (10*60*1000)

#define CALIB_FLAG1_VALID     (0xAA55)
#define CALIB_FLAG2_VALID     (0x55AA)


_srtCalibInfor srtCalibInfor;
 _srtCalibPoll  srtCalibPoll;
extern _ADC_port adc_num;
//record v calib dac out code
static int32_t uiVMinCode = 0;
static int32_t uiVMaxCode = 0;

/***************************************************************************
    Function           :void CALIB_THREAD_ValidDefault(void)
    Description        :У׼������λ,������µĴ洢��,����û�д洢У׼�����Ը�λ��ʼ��
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
void CALIB_THREAD_ValidDefault(void)
{
//	int i = 0;
//	//channel 0
//	_srtCalibData *psrtBase;
//	
////	uiVMinCode = AD5692_ValueToCode(CALIB_DAC_UMIN);
////	uiVMaxCode = AD5692_ValueToCode(CALIB_DAC_UMAX);
//	
//	psrtBase = &srtCalibInfor.Port1;

//	for(i = 0; i < MAX_PORT; i++,psrtBase++)
//	{		
//		//initial v mon
//		psrtBase->uiVMonMin = 0x47E;
//		psrtBase->uiVMonMax = 0x2DCE;
//		
//		//initial v out
//		psrtBase->uiVOutMin = 0x4DD;
//		psrtBase->uiVOutMax = 0x37AB;
//	}
//	
//	psrtBase = &srtCalibInfor.Port1;
//	for(i = 0; i <= MAX_PORT; i++,psrtBase++)
//	{
//		MEMORY_WriteDWord(CAL_PARAM_ADDR(i,0),psrtBase->uiVMonMin);
//		MEMORY_WriteDWord(CAL_PARAM_ADDR(i,1),psrtBase->uiVMonMax);
//		MEMORY_WriteDWord(CAL_PARAM_ADDR(i,2),psrtBase->uiVOutMin);
//		MEMORY_WriteDWord(CAL_PARAM_ADDR(i,3),psrtBase->uiVOutMax);
//	}
}
typedef enum
{
	CALIB_POLL_IDLE,
	CALIB_START_FIND,
	CALIB_CHECK_MIN,
	CALIB_CHECK_MAX,
}
_enumCalibCheck;

/***************************************************************************
    Function           :void CALIB_THREAD_Init(void)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
void CALIB_THREAD_Init(void)
{
	int i = 0;
	uint32_t uiLen = 0;
	uint32_t *puiTemp;
	_srtCalibData *psrtBase;
	
	uiVMinCode = 1;//AD5692_ValueToCode(CALIB_DAC_UMIN);
	uiVMaxCode = 2;//AD5692_ValueToCode(CALIB_DAC_UMAX);
	
    srtCalibPoll.uiIRange = 1;
	srtCalibPoll.uiType   = CALIB_TYPE_NONE;
	srtCalibPoll.uiStatus = CALIB_POLL_IDLE;
	uiLen = (SLOPE_ITEM_OFFSET(uiuAOffset) - SLOPE_ITEM_OFFSET(CVVMin) + 1);
	
	// \��ȡУ׼������,��ѹУ׼����,mAУ׼����,uAУ׼���� \
	//initial v mon
	psrtBase = &srtCalibInfor.Port1;
	for(i = 0; i < MAX_PORT; i++,psrtBase++)	
	{
		puiTemp = &(psrtBase->CVVMin);	
	  MEMORY_ReadDWords(CAL_PARAM_ADDR(i,0),puiTemp,uiLen);
		for(int i=0;i<uiLen;i++)
		printf("0x:%x  ",*puiTemp++);
		printf("\r\n ");
	}
}

/***************************************************************************
    Function           :int CALIB_THREAD_CheckValid(uint32_t uiPort)
    Description        :����Ƿ����У׼��
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int CALIB_THREAD_CheckValid(uint32_t uiPort)
{
	if(CALIB_FLAG2_VALID != CALIB_THREAD_GetInfor(uiPort)->uiIsValid)
	{
		return -1;
	}
	
	return 1;
}
extern const uint32_t ChannelRemap[];
/***************************************************************************
    Function           :void CALIB_THREAD_VOutToDAC(uint32_t uiPort,uint32_t uiVOUT) 
    Description        :�����ѹת��ΪDAC�m
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
uint32_t CALIB_THREAD_ImonToValue(uint32_t uiPort,int32_t uiValue)
{
	int32_t uiGain = 0;
	int32_t uiOffset = 0;
	int32_t uiCodeMin = 0;
	int32_t uiCodeMax = 0;
	int32_t uiOutMin = 0;
	int32_t uiOutMax = 0;		
	int64_t uliValue = 0;
	_srtCalibData *psrtInfor;
	_DataType    *psrtBase;
	
	psrtInfor = &srtCalibInfor.Port1;
	psrtInfor += uiPort;
	
	
	psrtBase=&adc_num.port1;
	psrtBase += uiPort;
	if(psrtBase->Itype==ISAA)
	{
	uiCodeMin = psrtInfor->CCIOut1Min;
	uiCodeMax = psrtInfor->CCIOut1Max;
	
	uiOutMin = psrtInfor->CCIMon1Min;
	uiOutMax = psrtInfor->CCIMon1Max;
	
		
	}
	else if(psrtBase->Itype==ISMA)
	{
	uiCodeMin = psrtInfor->CCIOut2Min;
	uiCodeMax = psrtInfor->CCIOut2Max;	
	
	uiOutMin =psrtInfor->CCIMon2Min; 
	uiOutMax =psrtInfor->CCIMon2Max; 	
		
	}
	
	uiGain = uiOutMax - uiOutMin;
	uiOffset = uiCodeMax - uiCodeMin;
		
	
	//dbSlope = (double)uiGain/(double)uiOffset;	
	//vout = voumin + (dacx - dacmin)*slope;
	//dacx = (vout-voutmin)/slope + dacmin;	

//	uliValue = uiValue;
//	uliValue *= 10;		
	uliValue = (uiValue - uiOutMin);
//	uliValue -= uiOutMin;	
	uliValue *= uiOffset;	
	uliValue /= uiGain;	
	uliValue += uiCodeMin;
	
	return (uint32_t)uliValue;
}



/***************************************************************************
    Function           :void CALIB_THREAD_VMonToValue(uint32_t uiPort,uint32_t uiVOUT) 
    Description        :CR MODE
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
uint32_t CALIB_THREAD_VoutToIout(uint32_t uiPort,int32_t uiValue)
{
	int32_t uiGain = 0;
	int32_t uiOffset = 0;
	int32_t uiMonMin = 0;
	int32_t uiMonMax = 0;
	int32_t uiOutMin = 0;
	int32_t uiOutMax = 0;
	int32_t uiIOffset = 0;
	
	int64_t uliValue = 0;
	int64_t uliOffset = 0;
	
	_DataType  *datatype;
	
	datatype=&adc_num.port1;
	datatype+=uiPort;
	    uiMonMin = datatype->ledvf;
	    uiMonMax = 14288;
		
	    uiOutMin = 250;
	    uiOutMax = 5;
		

 

	//hardware maybe have noise
//	if(uiValue - uiIOffset < 3)
//	{
//		uiIOffset = uiValue;
//		return 0;
//	}
	
	uiGain = uiOutMax - uiOutMin;
	uiOffset = uiMonMax - uiMonMin;
	
	//dbSlope = (double)uiGain/(double)uiOffset;
	//vout = voumin + (dacx - dacmin)*slope;
	//dacx = (vout-voutmin)/slope + dacmin;

	uliValue = (uiValue - uiMonMin);
	uliValue *= uiGain;	
	uliValue /= uiOffset;
	uliValue += uiOutMin;
	
	return (uint32_t)uliValue;
}


/***************************************************************************
    Function           :void CALIB_THREAD_VMonToValue(uint32_t uiPort,uint32_t uiVOUT) 
    Description        :VMon ת��Ϊ��ѹ��
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
uint32_t CALIB_THREAD_VMonToValue(uint32_t uiPort,int32_t uiCode)
{
	int32_t uiGain = 0;
	int32_t uiOffset = 0;
	int32_t uiMonMin = 0;
	int32_t uiMonMax = 0;
	int32_t uiOutMin = 0;
	int32_t uiOutMax = 0;	
	int64_t uliValue = 0;
	_srtCalibData *psrtInfor;
	
	psrtInfor = &srtCalibInfor.Port1;
	psrtInfor += uiPort;
	
	uiMonMin = psrtInfor->CVMonMin;
	uiMonMax = psrtInfor->CVMonMax;
	uiOutMin = psrtInfor->CVVOutMin;
	uiOutMax = psrtInfor->CVVOutMax;
	
	uiGain = uiOutMax - uiOutMin;
	uiOffset = uiMonMax - uiMonMin;
	
	//dbSlope = (double)uiGain/(double)uiOffset;
	//vout = voumin + (dacx - dacmin)*slope;
	//dacx = (vout-voutmin)/slope + dacmin;

  uliValue = (uiCode - uiMonMin);
	
	uliValue *= uiGain;
	uliValue /= uiOffset;	
	uliValue += uiOutMin;
	
//	uliValue += 5;
//	uliValue /= 10;	
	return (uint32_t)uliValue;
}


/***************************************************************************
    Function           :void CALIB_THREAD_VMonToValue(uint32_t uiPort,uint32_t uiVOUT) 
    Description        :VMon ת��Ϊ��ѹ��
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
uint32_t CALIB_THREAD_VToVset(uint32_t uiPort,int32_t uiCode)
{
	int32_t uiGain = 0;
	int32_t uiOffset = 0;
	int32_t uiMonMin = 0;
	int32_t uiMonMax = 0;
	int32_t uiOutMin = 0;
	int32_t uiOutMax = 0;	
	int64_t uliValue = 0;
	_srtCalibData *psrtInfor;
	
	psrtInfor = &srtCalibInfor.Port1;
	psrtInfor += uiPort;
	
	uiMonMin = psrtInfor->CVVOutMin;;
	uiMonMax =  psrtInfor->CVVOutMax;	
	uiOutMin = CALIB_DAC_UMIN ;
	printf("%d\r\n",psrtInfor->CVVOutMin);
	printf("%d\r\n",psrtInfor->CVVOutMax);
	uiOutMax = CALIB_DAC_UMAX;
	
	uiGain = uiOutMax - uiOutMin;
	uiOffset = uiMonMax - uiMonMin;
	
	//dbSlope = (double)uiGain/(double)uiOffset;
	//vout = voumin + (dacx - dacmin)*slope;
	//dacx = (vout-voutmin)/slope + dacmin;

    uliValue = (uiCode - uiMonMin);
	
	uliValue *= uiGain;
	uliValue /= uiOffset;	
	uliValue += uiOutMin;
	
//	uliValue += 5;
//	uliValue /= 10;	
	return (uint32_t)uliValue;
}
/***************************************************************************
    Function           :void CALIB_THREAD_IMonCodeToValue(uint32_t uiPort,uint32_t uiVOUT) 
    Description        :IMon AD��ת��Ϊ��ѹ��
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
uint32_t CALIB_THREAD_IToSet(uint32_t uiPort,int32_t uiValue)
{
	int32_t uiGain = 0;
	int32_t uiOffset = 0;
	int32_t uiMonMin = 0;
	int32_t uiMonMax = 0;
	int32_t uiOutMin = 0;
	int32_t uiOutMax = 0;
	int32_t uiIOffset = 0;
	
	int64_t uliValue = 0;
	int64_t uliOffset = 0;
	
	_srtCalibData *psrtInfor;
	
	psrtInfor = &srtCalibInfor.Port1;
	psrtInfor += uiPort;
	
	if(ADC_THREAD_GetInfor(uiPort)->Itype == ISAA)   //SDC_THREAD_GetInfor(uiPort)->uiIRange
	{
	    uiMonMin = psrtInfor->CCIOut1Min;
	    uiMonMax = psrtInfor->CCIOut1Max;
		
	    uiOutMin = CALIB_CC_MIN;
	    uiOutMax = CALIB_CC_MAX;
		
//		uiIOffset = psrtInfor->uimAOffset;
	}
  else if(ADC_THREAD_GetInfor(uiPort)->Itype == ISMA)
	{
	    uiMonMin = psrtInfor->CCIOut2Min;
	    uiMonMax = psrtInfor->CCIOut2Max;
		
	    uiOutMin = CALIB_CC_UMIN;
	    uiOutMax = CALIB_CC_UMAX;
		
//		uiIOffset = psrtInfor->uiuAOffset;
	}

	//hardware maybe have noise
//	if(uiValue - uiIOffset < 3)
//	{
//		uiIOffset = uiValue;
//		return 0;
//	}
	
	uiGain = uiOutMax - uiOutMin;
	uiOffset = uiMonMax - uiMonMin;
	
	//dbSlope = (double)uiGain/(double)uiOffset;
	//vout = voumin + (dacx - dacmin)*slope;
	//dacx = (vout-voutmin)/slope + dacmin;

	uliValue = (uiValue - uiMonMin);
	uliValue *= uiGain;	
	uliValue /= uiOffset;
	uliValue += uiOutMin;
	
	return (uint32_t)uliValue;
}

/***************************************************************************
    Function           :_srtCalibPoll *CALIB_THREAD_GetPoll(void)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
_srtCalibPoll *CALIB_THREAD_GetPoll(void)
{
	return &srtCalibPoll;
}
/***************************************************************************
    Function           :_srtCalibInfor *CALIB_THREAD_GetInfor(void)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
_srtCalibData *CALIB_THREAD_GetInfor(uint32_t uiPort)
{
	_srtCalibData *psrtData;
	if(uiPort > MAX_PORT)
	{
	    return NULL;
	}
	psrtData = &srtCalibInfor.Port1;
	psrtData += uiPort;
	return psrtData;
}

/***************************************************************************
    Function           :static void CALIB_THREAD_StartFind(void)
    Description        :��ʼУ�������С����
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/

static void CALIB_THREAD_StartFind(void)
{
	_srtCalibData *psrtInfor;
   _DataType *DataType;
	// port 0 mation,board 4
	
	//initial v mon
	psrtInfor = &srtCalibInfor.Port1;
	psrtInfor += srtCalibPoll.uiChannel;			
  DataType=&adc_num.port1;
	DataType+= srtCalibPoll.uiChannel;
	DataType->mode=srtCalibPoll.uiMODE;
	DataType->Itype=srtCalibPoll.uiIRange;
	if(srtCalibPoll.uiMODE==ISCV)
	{
		setcvvoltege(srtCalibPoll.uiChannel,CALIB_DAC_UMIN);
		
	}
		if(srtCalibPoll.uiMODE==ISCC)
	{
		if(srtCalibPoll.uiIRange==ISAA)
		{
			setccvoltege(srtCalibPoll.uiChannel,CALIB_CC_MIN);
		}
		else
			{
				setccvoltege(srtCalibPoll.uiChannel,CALIB_CC_UMIN);
			}
	}
	 if(srtCalibPoll.uiMODE==ISCR)
	{
		printf("palese turn power to 1.3V\r\n");
//		setccvoltege(srtCalibPoll.uiChannel,CALIB_CC_UMIN);
	}

}
/***************************************************************************
    Function           :static int CALIB_THREAD_GetMin(void)
    Description        :��¼��С��ѹ����СmA����СuA��
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
static int CALIB_THREAD_GetMin(void)
{
	_srtCalibData *psrtInfor;
  _DataType  *DataType;
	DataType=&adc_num.port1;
	DataType+=srtCalibPoll.uiChannel;
	get_port_adcvalue(srtCalibPoll.uiChannel);
	//wait write VOUT Min,Current Min,than record vmon min,Imon min
	if(srtCalibPoll.uiTrigger)
	{
		psrtInfor = &srtCalibInfor.Port1;
		psrtInfor += srtCalibPoll.uiChannel;	
	if(srtCalibPoll.uiMODE==ISCV)
	{
		psrtInfor->CVMonMin=DataType->Vvalue;
		psrtInfor->CVVOutMin=srtCalibPoll.uiRecordVValue;
	}
	if(srtCalibPoll.uiMODE==ISCC)
	{
		if(srtCalibPoll.uiIRange==ISAA)
		{
			psrtInfor->CCIMon1Min=DataType->Avalue;
			psrtInfor->CCIOut1Min=srtCalibPoll.uiRecordAValue;
		}
		else if(srtCalibPoll.uiIRange==ISMA)
		{
			psrtInfor->CCIMon2Min=DataType->mAvalue;
			psrtInfor->CCIOut2Min=srtCalibPoll.uiRecordAValue;
		
		}
	
	}
	if(srtCalibPoll.uiMODE==ISCR)
	{
		psrtInfor->CCMONMin=DataType->Vvalue;    //remember votage minvalue
		printf("CCMONMin:%d\r\n",DataType->Vvalue);
		psrtInfor->CCVOUTMin=srtCalibPoll.uiRecordVValue;//remember testing  minvalue
		printf("palese turn power to 13V\r\n");
	}
	
	if(srtCalibPoll.uiMODE==ISCV)
	{
		setcvvoltege(srtCalibPoll.uiChannel,CALIB_DAC_UMAX);
		
	}
		if(srtCalibPoll.uiMODE==ISCC)
	{
		if(srtCalibPoll.uiIRange==ISAA)
		{
		setccvoltege(srtCalibPoll.uiChannel,CALIB_CC_MAX);
		}
		else 
		{
		setccvoltege(srtCalibPoll.uiChannel,CALIB_CC_UMAX);
		}
	}
		srtCalibPoll.uiTrigger = 0;	
		srtCalibPoll.uiTick = TIM_CORE_GetTick();
		srtCalibPoll.uiStartTick = srtCalibPoll.uiTick;
		srtCalibPoll.uiStatus = CALIB_CHECK_MAX;
		return 1;
	}
	
	
	
	//check timeout
	if(TIM_CORE_GetTick() > (srtCalibPoll.uiStartTick + CALIB_POLL_TIMEOUT))
	{
		srtCalibPoll.uiResult = 2;
	    srtCalibPoll.uiType = CALIB_TYPE_NONE;
		srtCalibPoll.uiStatus = CALIB_POLL_IDLE;
		
		return -1;
	}
	return 0;
}

/***************************************************************************
    Function           :static int CALIB_THREAD_GetMax(void)
    Description        :��¼����ѹ�����mA�����uA��
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
static int CALIB_THREAD_GetMax(void)
{
	_srtCalibData *psrtInfor;
	_DataType  *DataType;
	//wait write VOUT MAX,Current MAX,than record vmon max,Imon max
	if(srtCalibPoll.uiTrigger)
	{
		
		psrtInfor = &srtCalibInfor.Port1;
		psrtInfor += srtCalibPoll.uiChannel;
		DataType=&adc_num.port1;
		DataType+=srtCalibPoll.uiChannel;
		get_port_adcvalue(srtCalibPoll.uiChannel);
    if(ISCV == srtCalibPoll.uiMODE)
		{
			psrtInfor->CVMonMax = DataType->Vvalue;

			psrtInfor->CVVOutMax = srtCalibPoll.uiRecordVValue;
			MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,2),psrtInfor->CVMonMin);
			MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,3),psrtInfor->CVMonMax);
			MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,4),psrtInfor->CVVOutMin);
			MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,5),psrtInfor->CVVOutMax);
			MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,22),psrtInfor->uimAOffset);
			MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,23),psrtInfor->uiuAOffset);


		}
		else if(ISCC == srtCalibPoll.uiMODE)
		{
			if(ISAA == srtCalibPoll.uiIRange)
			{
				psrtInfor->CCIMon1Max = ADC_THREAD_GetInfor(srtCalibPoll.uiChannel)->Avalue;
				psrtInfor->CCIOut1Max = srtCalibPoll.uiRecordAValue;
				
				//check calib parameter is valid
	
					MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,14),psrtInfor->CCIMon1Min);
					MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,15),psrtInfor->CCIMon1Max);
					MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,16),psrtInfor->CCIOut1Min);
					MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,17),psrtInfor->CCIOut1Max);
					

			}
			else if(ISMA == srtCalibPoll.uiIRange)
			{
				psrtInfor->CCIMon2Max = ADC_THREAD_GetInfor(srtCalibPoll.uiChannel)->mAvalue;
				
				psrtInfor->CCIOut2Max = srtCalibPoll.uiRecordAValue;

				//check calib parameter is valid

					MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,18),psrtInfor->CCIMon2Min);
					MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,19),psrtInfor->CCIMon2Max);
					MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,20),psrtInfor->CCIOut2Min);
					MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,21),psrtInfor->CCIOut2Max);

			}		
		}
		
		else if(ISCR== srtCalibPoll.uiMODE)
		{
			
			psrtInfor->CCMONMax = DataType->Vvalue;
			printf("CCMONMax:%d\r\n",DataType->Vvalue);
			psrtInfor->CCVOUTMax = srtCalibPoll.uiRecordVValue;
			MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,10),psrtInfor->CCMONMin);
			MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,11),psrtInfor->CCMONMax);
			MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,12),psrtInfor->CCVOUTMin);
			MEMORY_WriteDWord(CAL_PARAM_ADDR(srtCalibPoll.uiChannel,13),psrtInfor->CCVOUTMax);
		}

		//finish
		srtCalibPoll.uiResult = 1;
		srtCalibPoll.uiIsFinish = 0;				
		srtCalibPoll.uiTrigger = 0;	
		srtCalibPoll.uiTick = TIM_CORE_GetTick();
	  srtCalibPoll.uiType = CALIB_TYPE_NONE;
		srtCalibPoll.uiStatus = CALIB_POLL_IDLE;
		printf("cliab finish!!\r\n");
		return 1;
	}
	
	//check timeout
	if(TIM_CORE_GetTick() > (srtCalibPoll.uiStartTick + CALIB_POLL_TIMEOUT))
	{
		srtCalibPoll.uiResult = 3;
	    srtCalibPoll.uiType = CALIB_TYPE_NONE;
		srtCalibPoll.uiStatus = CALIB_POLL_IDLE;
		
		return -1;
	}
	return 0;
}

/***************************************************************************
    Function           :int CALIB_THREAD_SetIRange(uint32_t uiPort,uint32_t uiRange)
    Description        :���õ�����λ
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int CALIB_THREAD_SetIRange(uint32_t uiRange)
{	
	if(uiRange > ISMA)
	{
		return -1;
	}
	
	if(CALIB_POLL_IDLE == srtCalibPoll.uiStatus)
	{
		if(srtCalibPoll.uiIRange != uiRange)
		{			
			srtCalibPoll.uiIRange = uiRange;
		}
		return 1;		
	}
	return -2;
}


/***************************************************************************
    Function           :int CALIB_THREAD_SetCVmode(uint32_t uiPort,uint32_t mode)
    Description        :����??
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/

int CALIB_THREAD_SetCVmode(uint32_t mode)
{
	if(mode>4)
	{
		return -1;
	}
	else if(srtCalibPoll.uiMODE != mode)
		{			
			srtCalibPoll.uiMODE = mode;
			return 1;
		}
 return -2;
}
/***************************************************************************
    Function           :int CALIB_THREAD_StartType(uint32_t uiType)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int CALIB_THREAD_StartType(uint32_t uiType)
{
	if(uiType > ISCR)
	{
		return -1;
	}
	if(CALIB_POLL_IDLE == srtCalibPoll.uiStatus)
	{
		srtCalibPoll.uiType = uiType;
	    return 1;
	}
	
	return -2;
}
/***************************************************************************
    Function           :int CALIB_THREAD_StartChannel(uint32_t uiChannel,uint32_t uiType)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int CALIB_THREAD_StartChannel(uint32_t uiChannel)
{
	//calib process is started
	if((uiChannel > MAX_PORT) || \
		(srtCalibPoll.uiIsFinish) || \
//	    (CALIB_TYPE_NONE == srtCalibPoll.uiType) || 
	    (CALIB_POLL_IDLE != srtCalibPoll.uiStatus))
	{
		printf("%d  ,%d  ,%d"  ,srtCalibPoll.uiIsFinish,srtCalibPoll.uiType,srtCalibPoll.uiStatus);
		return -1;
	}

	if(srtCalibPoll.uiChannel != uiChannel)
	{
		srtCalibPoll.uiChannel = uiChannel;	
	}
	
	srtCalibPoll.uiTrigger = 1;
	return 1;
}
/***************************************************************************
    Function           :int CALIB_THREAD_RecordChannel(uint32_t uiValue,uint32_t uiType)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int CALIB_THREAD_RecordChannel(uint32_t uiValue,uint32_t uiType)
{
	if(uiValue)
	{
		if(CALIB_TYPE_I == uiType)
		{
			srtCalibPoll.uiRecordAValue = uiValue;
	        srtCalibPoll.uiTrigger = 1;
		}
		else
		{
			srtCalibPoll.uiRecordVValue = uiValue;
	        srtCalibPoll.uiTrigger = 1;

		}
	 
		return 1;
	}
	
	return -1;
}
/***************************************************************************
    Function           :int CALIB_THREAD_RecordTriiger(void)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int CALIB_THREAD_RecordTriiger(void)
{
	if((CALIB_TYPE_NONE == srtCalibPoll.uiType) || \
	   (CALIB_POLL_IDLE == srtCalibPoll.uiStatus))
	{
		return -1;
	}
	
//	srtCalibPoll.uiTrigger = 1;
	return 1;
}

/***************************************************************************
    Function           :void CALIB_THREAD_CheckVOut(void)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
static void CALIB_THREAD_CheckVOut(void)
{
	if(CALIB_POLL_IDLE == srtCalibPoll.uiStatus)
	{
		//wait start calib process
		if(srtCalibPoll.uiTrigger)
		{
			srtCalibPoll.uiTrigger = 0;
			srtCalibPoll.uiTick = TIM_CORE_GetTick();
			
			srtCalibPoll.uiResult = 0;
			srtCalibPoll.uiIsFinish = 1;
			srtCalibPoll.uiRecordVValue = 0;
			srtCalibPoll.uiRecordAValue = 0;
			srtCalibPoll.uiStatus = CALIB_START_FIND;
//			printf("CALIB_START_FIND\r\n");
		}
	}
	else if(CALIB_START_FIND == srtCalibPoll.uiStatus)
	{
		//start find,umin
		if(TIM_CORE_GetTick() > (srtCalibPoll.uiTick + 100))
		{
      CALIB_THREAD_StartFind();
			srtCalibPoll.uiTick = TIM_CORE_GetTick();
			srtCalibPoll.uiStartTick = srtCalibPoll.uiTick;
			srtCalibPoll.uiStatus = CALIB_CHECK_MIN;	
//			printf("CALIB_CHECK_MIN\r\n");			
		}
	}
	else if(CALIB_CHECK_MIN == srtCalibPoll.uiStatus)
	{
		//GET,VMON min
		if(TIM_CORE_GetTick() > (srtCalibPoll.uiTick + 300))
		{        
			if(CALIB_THREAD_GetMin() < 0)
			{}
//			printf("CALIB_THREAD_GetMin\r\n");
		}
	}
	else if(CALIB_CHECK_MAX == srtCalibPoll.uiStatus)
	{
		//GET,VMON MAX
		if(TIM_CORE_GetTick() > (srtCalibPoll.uiTick + 300))
		{
			if(CALIB_THREAD_GetMax() < 0)
			{}
//			printf("CALIB_THREAD_GetMax\r\n");	
		}
	}
}
/***************************************************************************
    Function           :int CALIB_THREAD_Poll(void)
    Description        :
    Input Parameter    :    
    Output Parameter   :   
    Who  Make it  ?    :                
    History            :                            Date/Time:12-03-2013 
****************************************************************************/
int CALIB_THREAD_Poll(void)
{
	CALIB_THREAD_CheckVOut();

	return 1;
}
