#include "iic.h"
#define I2C_WR 0 /* ???bit */
#define I2C_RD 1 /* ???bit */
/* ??I2C?????GPIO??, ?????????4?????????SCL?SDA??? */

/*
*********************************************************************************************************
*    ? ? ?: bsp_InitI2C
*    ????: ??I2C???GPIO,????IO?????
*    ?    ?:  ?
*    ? ? ?: ?
*********************************************************************************************************
*/
void bsp_InitI2C(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};

	__HAL_RCC_GPIOC_CLK_ENABLE();

	GPIO_InitStruct.Pin = I2C_SCL_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
		 
	GPIO_InitStruct.Pin = I2C_SDA_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
	 
	
	
    /* ???????, ??I2C????????????? */
    i2c_Stop();
}

/*
*********************************************************************************************************
*    ? ? ?: i2c_Delay
*    ????: I2C?????,??400KHz
*    ?    ?:  ?
*    ? ? ?: ?
*********************************************************************************************************
*/



void IIC_DelayUS(uint32_t n)
{
    uint32_t ticks;
    uint32_t told;
    uint32_t tnow;
    uint32_t tcnt = 0;
    uint32_t reload;

    reload = SysTick->LOAD;
    ticks = n * (SystemCoreClock / 1000000); /* ?????? */

    tcnt = 0;
    told = SysTick->VAL; /* ????????? */

    while (1)
    {
        tnow = SysTick->VAL;
        if (tnow != told)
        {
            /* SYSTICK????????? */
            if (tnow < told)
            {
                tcnt += told - tnow;
            }
            /* ?????? */
            else
            {
                tcnt += reload - tnow + told;
            }
            told = tnow;

            /* ????/????????,??? */
            if (tcnt >= ticks)
            {
                break;
            }
        }
    }
}


static void i2c_Delay(void)
{
        IIC_DelayUS(20);
}

/*
*********************************************************************************************************
*    ? ? ?: i2c_Start
*    ????: CPU??I2C??????
*    ?    ?:  ?
*    ? ? ?: ?
*********************************************************************************************************
*/      
void i2c_reStart(void)
{

		 I2C_SDA_0();
		 i2c_Delay();
		 I2C_SDA_1();
		 i2c_Delay();
		 I2C_SCL_1();
		 i2c_Delay();
		 I2C_SDA_0();
		 i2c_Delay();
}
void i2c_Start(void)
{
    I2C_SDA_1();
    I2C_SCL_1();
    i2c_Delay();
    I2C_SDA_0();
    i2c_Delay();
    I2C_SCL_0();
    i2c_Delay();
}

/*
*********************************************************************************************************
*    ? ? ?: i2c_stop
*    ????: CPU??I2C??????
*    ?    ?:  ?
*    ? ? ?: ?
*********************************************************************************************************
*/
void i2c_Stop(void)
{
    I2C_SDA_0();
    I2C_SCL_1();
    i2c_Delay();
    I2C_SDA_1();
    i2c_Delay(); 
}

/*
*********************************************************************************************************
*    ? ? ?: i2c_SendByte
*    ????: CPU?I2C??????8bit??
*    ?    ?:  _ucByte : ???????
*    ? ? ?: ?
*********************************************************************************************************
*/
void i2c_SendByte(uint8_t _ucByte)
{
    uint8_t i;
    for (i = 0; i < 8; i++)
    {
        if (_ucByte & 0x80)
        {
            I2C_SDA_1();
        }
        else
        {
            I2C_SDA_0();
        }
        i2c_Delay();
        I2C_SCL_1();
        i2c_Delay();
        I2C_SCL_0();
        if (i == 7)
        {
            I2C_SDA_1(); // ????
        }
        _ucByte <<= 1; /* ????bit */
                                     //        i2c_Delay();
    }
 
}

/*
*********************************************************************************************************

*********************************************************************************************************
*/
uint8_t i2c_ReadByte(void)
{
    uint8_t i;
    uint8_t value;
   /* ???1?bit????bit7 */
    value = 0;
    for (i = 0; i < 8; i++)
    {
        value <<= 1;
        I2C_SCL_1();
        i2c_Delay();
        if (I2C_SDA_READ())
        {
            value++;
        }
        I2C_SCL_0();
        i2c_Delay();
    }
    return value;
}

/*
*********************************************************************************************************
*    ? ? ?: i2c_WaitAck
*    ????: CPU??????,??????ACK????
*    ?    ?:  ?
*    ? ? ?: ??0??????,1???????
*********************************************************************************************************
*/
uint8_t i2c_WaitAck(void)
{
    uint8_t re;
    I2C_SDA_1(); /* CPU??SDA?? */
    i2c_Delay();
    I2C_SCL_1(); /* CPU??SCL = 1, ???????ACK?? */
    i2c_Delay();
    if (I2C_SDA_READ()) /* CPU??SDA???? */
    {
        re = 1;
    }
    else
    {
        re = 0;
    }
    I2C_SCL_0();
    i2c_Delay();
    return re;
}

/*
*********************************************************************************************************
*    ? ? ?: i2c_Ack
*    ????: CPU????ACK??
*    ?    ?:  ?
*    ? ? ?: ?
*********************************************************************************************************
*/
void i2c_Ack(void)
{
    I2C_SDA_0();
    i2c_Delay();
    I2C_SCL_1();
    i2c_Delay();
    I2C_SCL_0();
    i2c_Delay();
    I2C_SDA_1();
}

/*
*********************************************************************************************************
*    ? ? ?: i2c_NAck
*    ????: CPU??1?NACK??
*    ?    ?:  ?
*    ? ? ?: ?
*********************************************************************************************************
*/
void i2c_NAck(void)
{
    I2C_SDA_1(); /* CPU??SDA = 1 */
    i2c_Delay();
    I2C_SCL_1(); /* CPU??1??? */
    i2c_Delay();
    I2C_SCL_0();
    i2c_Delay();
}

/*
*********************************************************************************************************

*********************************************************************************************************
*/
uint8_t i2c_CheckDevice(uint8_t _Address)
{
    uint8_t ucAck;
	if (I2C_SDA_READ() && I2C_SCL_READ())
		{
			i2c_Start();
			i2c_SendByte(_Address | I2C_WR);
			ucAck = i2c_WaitAck(); 
			i2c_Stop();
        return ucAck;
		}	
    return 1;
}


