/****************************************************************************
*
*     stm32f1xx_hal_conf.h ?????? ??
*
****************************************************************************/
#include "include.h"

#define isInvert	0	
void DAC8554_Write_ch_data(uint8_t cmd, uint8_t ch, uint8_t isPowerdown, uint16_t data)
{
	uint8_t i =0x0;
	uint8_t tmpCmd =0x00;
	uint8_t ADDR=0x01;
	uint32_t sData =0x0;
	
	tmpCmd = ((ADDR & 0x01)<<6|(cmd & 0x03) <<4) | ((ch & 0x03) <<1) | ((isPowerdown & 0x01) <<0);		// ?????
	
	if( ChPower_down_ON == isPowerdown )	data &= 0xC000;								// ?????
#if (1 == isInvert)	
	sData = ((uint8_t)(~tmpCmd) <<16) | (uint16_t)(~data);		// ????
#else
	sData = (tmpCmd <<16) | data;								// ????
#endif	

#if (1 == isInvert)	
	oSYNC_0;
	//oENABLE_1;
	oSYNC_1;	
#else	
  oSYNC_1;
	//oENABLE_0;
	oSYNC_0;
#endif	
	for( i =0; i <24; i++ )	// 24???: 8???? + 16????
	{
		if( 0x800000 ==(sData & 0x800000) )		oDIN_1;
		else									oDIN_0;
#if (1 == isInvert)	
		oSCLK_0;
		__NOP();__NOP();
		oSCLK_1;
#else		
		oSCLK_1;
//		__NOP();
		oSCLK_0;
#endif
		sData = sData << 1;
	}


#if (1 == isInvert)	
	oLDAC_1;
	__NOP();
	oLDAC_0;
	//oENABLE_0;	
#else	
	oLDAC_0;
//	__NOP();
	oLDAC_1;
	//oENABLE_1;
#endif	
	
	
}

void dac8554_init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	__HAL_RCC_GPIOB_CLK_ENABLE();
	
	GPIO_InitStruct.Pin = GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
	
//	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_15, GPIO_PIN_RESET);
}

void set_vol( uint8_t ch ,uint16_t vol)
{
	uint32_t temp=0;
	uint8_t  sch=0;
	temp=(vol*65536/2500);
	//temp=temp<<16;
	switch (ch)
	{
		case 1: sch=0; break ;
		case 2: sch=1; break ;
	  case 3: sch=2; break ;
	  case 4: sch=3; break ;
		default: ;
	}
DAC8554_Write_ch_data(0x00, sch, 0x00, temp);

}
extern _ADC_port adc_num;
void setcvvoltege(uint32_t chanel,uint16_t voltage)
{
	
	_DataType  *datatype;
	
	datatype=&adc_num.port1;
	datatype+=chanel;
	if(datatype->mode==ISCV)
	{
	if(voltage==0)
	{
	set_vol(chanel*2+2,2490);
	}
	set_vol(chanel*2+1,0);
	switch (chanel)
	{
		case 0:
		case 1:	
		
		set_vol(chanel*2+2,voltage);
		if(chanel==0)
		{
		setaminrain(0);
		setamaxrain(1);
		}
		else if(chanel==1)
		{
			setbminrain(0);
			setbmaxrain(1);
		
		}
		break;
		default: ;
	}
	}
	
	else if(datatype->mode==ISCLED)
	{
		set_vol(chanel*2+1,0);
	switch (chanel)
	{
		case 0:
		case 1:	
		set_vol(chanel*2+2,voltage);
		if(chanel==0)
		{
		setaminrain(0);
		setamaxrain(1);
		}
		else if(chanel==1)
		{
			setbminrain(0);
			setbmaxrain(1);
		
		}
		break;
		default: break;
	}
	
	
	}


}
uint16_t tempreg=0;
void setccvoltege(uint32_t chanel,uint16_t voltage)
{	
	_DataType  *datatype;
	datatype=&adc_num.port1;
	datatype+=chanel;
	

	if(datatype->mode==ISCC)
	{
	set_vol(chanel*2+2,2490);	
	switch (chanel)
	{
		case 0:
		case 1:	
		if(datatype->Itype==ISAA)
		{ 
			if(chanel==0)
			{
			setaminrain(0);
			setamaxrain(1);
			}
			else if(chanel==1)
			{
			setbminrain(0);
			setbmaxrain(1);			
			}
		}
		else if(datatype->Itype==ISMA)
		{
			if(chanel==0)
			{
			setaminrain(1);
			setamaxrain(0);
			}
			else if(chanel==1)
			{
			setbminrain(1);
			setbmaxrain(0);			
			}
		
		}
		if(tempreg!=voltage)
		{
			if(tempreg<voltage)
			{
			for(int i=tempreg;i<voltage+1;i++)
			{
				set_vol(chanel*2+1,i);
				bsp_DelayUS(datatype->uptimes*100/10);
			}
			}
		 if(tempreg>voltage)
			{
				for(int j=tempreg;j>voltage;j--)
				{
					set_vol(chanel*2+1,j);
					bsp_DelayUS(datatype->dntimes*100/10);			
				}
			}
			tempreg=voltage;
		}
		break;
		default: break;
	}
	}
	else if((datatype->mode==ISCR)||(datatype->mode==ISCLED))
	{ 
		set_vol(chanel*2+2,2490);	
		if(voltage==0)
		{
			setaminrain(0);
			setamaxrain(0);
			setbminrain(0);
			setbmaxrain(0);		
			set_vol(chanel*2+1,0);
		}
		switch (chanel)
	{
		case 0:
		case 1:	
		if(chanel==0)
			{
			setaminrain(0);
			setamaxrain(1);
			}
			else if(chanel==1)
			{
			setbminrain(0);
			setbmaxrain(1);			
			}	
		set_vol(chanel*2+1,voltage);
		break;
		default: break;
	}
	
	}

}


