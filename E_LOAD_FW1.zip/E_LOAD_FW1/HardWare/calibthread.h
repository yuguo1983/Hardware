#ifndef _CALIB_THREAD_H_
#define _CALIB_THREAD_H_

#include <stdint.h>




#define MAX_PORT         (2)



typedef enum
{
	CALIB_TYPE_NONE,
	CALIB_TYPE_V,
	CALIB_TYPE_I,
}
_enumCalibType;


//calib base data ,just voltage,current
typedef struct
{
	int32_t CVVMin;    	//CV万用表测量最小电压 0
	int32_t CVVMax;			//CV万用表测量最大电压1
	
	int32_t CVMonMin;    	//CV mon值2
	int32_t CVMonMax;			//CV mon值3
	
	int32_t CVVOutMin;	//万用表测出4
	int32_t CVVOutMax;	//万用表测出5
	
	int32_t CVImonMin;	//CV mon值6
	int32_t CVImonMax;	//CV mon值7
	
	int32_t CVIOutMin;	//万用表测出8
	int32_t CVIOutMax;	//万用表测出9
	
	
	int32_t CCMONMin;	//CC mon值10
	int32_t CCMONMax; //CC mon值11
	
	int32_t CCVOUTMin;	//万用表测出12
	int32_t CCVOUTMax;  //万用表测出13
	
	int32_t CCIMon1Min;     //uA mon值14
	int32_t CCIMon1Max;    //15
	
	int32_t CCIOut1Min;     //uA 实际值16
	int32_t CCIOut1Max;     	//17
	
	int32_t CCIMon2Min;     //mA mon值18
	int32_t CCIMon2Max;    //19
	
	int32_t CCIOut2Min;     //mA 实际值//20
	int32_t CCIOut2Max;     //21
	
	int32_t uimAOffset; //空载最小值,在uA校准时候来记录22
	int32_t uiuAOffset; //空载最大值,在uA校准时候来记录23
	
	uint32_t uiIsValid;  //是否校准过24
	
	
}
_srtCalibData;
#define SLOPE_ITEM_OFFSET(member)	(((uint32_t)(&(((_srtCalibData *)0)->member))) / sizeof(uint32_t))
//calib information,include port0,1,2,3 calib result
typedef struct
{
	_srtCalibData Port1;
	_srtCalibData Port2;
}
_srtCalibInfor;


void CALIB_THREAD_Init(void);
int CALIB_THREAD_Poll(void);
uint32_t CALIB_THREAD_VOutToDACCode(uint32_t uiPort,int32_t iValue);
uint32_t CALIB_THREAD_VMonToValue(uint32_t uiPort,int32_t iCode);
uint32_t CALIB_THREAD_VMonToOffset(uint32_t uiPort,int32_t iCode);
uint32_t CALIB_THREAD_IMonToValue(uint32_t uiPort,int32_t iValue);

_srtCalibData *CALIB_THREAD_GetInfor(uint32_t uiPort);


typedef enum{
ISNULL=0,
ISCV=1,
ISCC=2,
ISCLED=3,
ISCR=4,
}_MODE_TYPE;



typedef struct
{
	uint32_t uiChannel;      //校准通道
	uint32_t uiIsFinish;     //校准是否完成
	uint32_t uiResult;       //校准结果
	uint32_t uiRecordVValue; //实际电压值,根据万用表测量
	uint32_t uiRecordAValue; //实际电流值,根据万用表测量
	uint32_t uiIRange;       //校准档位mA/uA
	uint32_t uiType;         //校准类型,电压校准/电流校准
	uint32_t uiTrigger;      //触发信号
	uint32_t uiStatus;       //状态机
	uint32_t uiTick;         //间隔
	uint32_t uiStartTick;    //起始时刻
	uint32_t uiMODE;  //是否为CV模式
}
_srtCalibPoll;
#define CALIB_ITEM_OFFSET(member)	(((uint32_t)(&(((_srtCalibPoll *)0)->member))) / sizeof(uint32_t))

_srtCalibPoll *CALIB_THREAD_GetPoll(void);
int CALIB_THREAD_StartChannel(uint32_t uiChannel);
int CALIB_THREAD_RecordChannel(uint32_t uiValue,uint32_t uiType);
int CALIB_THREAD_SetIRange(uint32_t uiRange);
int CALIB_THREAD_StartType(uint32_t uiType);
int CALIB_THREAD_RecordTriiger(void);
int CALIB_THREAD_CheckValid(uint32_t uiPort);
void CALIB_THREAD_ValidDefault(void);
int CALIB_THREAD_SetCVmode(uint32_t mode);


uint32_t CALIB_THREAD_VToVset(uint32_t uiPort,int32_t uiCode);
uint32_t CALIB_THREAD_IToSet(uint32_t uiPort,int32_t uiValue);
uint32_t CALIB_THREAD_ImonToValue(uint32_t uiPort,int32_t uiValue);
uint32_t CALIB_THREAD_VoutToIout(uint32_t uiPort,int32_t uiVIN);

#endif
