/***************************************************************************
	*OLED����
	* Copyright (c) 2016 shen zheng gmt
	* All rights reserved.
	* File: $Id: BspDriverOLED.c,v 01.00 2016/10/26 14:36:40 liuf Exp $
	*1��OLED����SPI��ʽ������Ĭ�ϲ���spi����ֻдģʽ��OLED���ֵ�spi clock���
	*Ϊ10MHz���˴�SPI��������ʱ��Ϊ84MHz������Ϊ16��Ƶ
	*2��SPI֧��DMA���ͣ����ʱ����DMA��������жϲ��֣�����CS,���ͷ���Դ������
	*���֣���Ļ�޷�����������ģʽ�£���DMA��������жϲ������öϵ㣬Ȼ���ٴ�����
	*���������������Ļ��
	*3��Ϊ�˽�������⣬�˴����˼·�ʹ���DMA�������˼·��ͬ��DMA��������жϺ�
	*����SPI ���ͣ�������Ϊ�գ��жϣ���spi�����жϲ��֣�����CS���ͷ���Դ������ͨ��
*****************************************************************************/


#include "include.h"



typedef struct
{
    int (*Init)(void);

    int (* WriteByte)(uint32_t uiAddr,unsigned char ucData);
    int (* WriteDWord)(uint32_t uiAddr,uint32_t uiData);
    int (* WriteDWords)(uint32_t uiAddr,uint32_t *puiTemp,uint32_t uiLen);
    int (* WriteBytes)(uint32_t uiAddr,unsigned char *pucFrame,uint32_t uiLen);

    unsigned char (* ReadByte)(uint32_t uiAddr);
    uint32_t (* ReadDWord)(uint32_t uiAddr);
    int (* ReadBytes)(uint32_t uiAddr,unsigned char *pucFrame,uint32_t uiLen);
    int (* ReadDWords)(uint32_t uiAddr,uint32_t *puiTemp,uint32_t uiLen);
}
_srtAPI_Memory;

static _srtAPI_Memory MemoryAPI = 
{
	AT24CXX_Init,
	
	AT24CXX_WriteOneByte,
	AT24CXX_WriteDWord,
	AT24CXX_WriteDWords,
	AT24CXX_Write,
	
	AT24CXX_ReadOneByte,
	AT24CXX_ReadDWord,
	AT24CXX_Read,
	AT24CXX_ReadDWords,
};

#define MEMROY_VALID_CHECK (0xAA5555AA)
/**********************************************************************************************
	Function		:int MEMORY_Init(void)
	Description		:�洢�����,Ĭ�ϴ洢���Ļ���ַ�洢��0xAA5555AA,�����⵽�õ�ַ��ֵ��ΪУ��ֵ,
                     ����Ϊ�ô洢��Ϊ�µĴ洢��,��ʱ��Ҫ��λ���ֲ���,�������ڲ���,���������	
	Input Parameter	:    
	Output Parameter:   
	Who	Make it	?	:        		
	History			:							Date/Time:12-03-2013
**********************************************************************************************/ 
int MEMORY_Init(void)
{
	uint32_t uiData = 0;
	
	if(NULL != MemoryAPI.Init)
	{
		MemoryAPI.Init();
		
		uiData = MEMORY_ReadDWord(MEMORY_BASE_ADDR);
		
		//У��OK
		if(MEMROY_VALID_CHECK == uiData)
		{}
		else
		{
			//У��ʧ��,is new memroy storage
			{
				MEMORY_WriteDWord(MEMORY_BASE_ADDR,MEMROY_VALID_CHECK); //check memory

		        uiData = MEMORY_ReadDWord(MEMORY_BASE_ADDR);
		        if(MEMROY_VALID_CHECK == uiData)                        //is ok
				{
					
					CALIB_THREAD_ValidDefault();
				}
				else
				{
//					UART_THREAD_Reset();
					//У��ʧ��,memory��дʧ��,˵��Ӳ����������,�п��������߳������洢��������
					return -1;
				}
			}
		}
	}
	return 1;
}
/**********************************************************************************************
	Function		:unsigned char MEMORY_ReadByte(uint32_t uiAddr)
	Description		:      
	Input Parameter	:    
	Output Parameter:   
	Who	Make it	?	:        		
	History			:							Date/Time:12-03-2013
**********************************************************************************************/ 
unsigned char MEMORY_ReadByte(uint32_t uiAddr)
{
	if(NULL != MemoryAPI.ReadByte)
	{
		return MemoryAPI.ReadByte(uiAddr);
	}
	return 0;
}
/**********************************************************************************************
	Function		:void MEMORY_ReadBytes(uint32_t uiAddr,unsigned char *pucFrame,uint32_t uiLen)
	Description		:      
	Input Parameter	:    
	Output Parameter:   
	Who	Make it	?	:        		
	History			:							Date/Time:12-03-2013
**********************************************************************************************/ 
void MEMORY_ReadBytes(uint32_t uiAddr,unsigned char *pucFrame,uint32_t uiLen)
{
	if(NULL != MemoryAPI.ReadBytes)
	{
		 MemoryAPI.ReadBytes(uiAddr,pucFrame,uiLen);
	}
}
/**********************************************************************************************
	Function		:uint32_t MEMORY_ReadDWord(uint32_t uiAddr)
	Description		:      
	Input Parameter	:    
	Output Parameter:   
	Who	Make it	?	:        		
	History			:							Date/Time:12-03-2013
**********************************************************************************************/ 
uint32_t MEMORY_ReadDWord(uint32_t uiAddr)
{
	if(NULL != MemoryAPI.ReadDWord)
	{
		return MemoryAPI.ReadDWord(uiAddr);
	}
	return 0;
}
/**********************************************************************************************
	Function		:void MEMORY_ReadDWords(uint32_t uiAddr,uint32_t *puiTemp,uint32_t uiLen)
	Description		:      
	Input Parameter	:    
	Output Parameter:   
	Who	Make it	?	:        		
	History			:							Date/Time:12-03-2013
**********************************************************************************************/ 
void MEMORY_ReadDWords(uint32_t uiAddr,uint32_t *puiTemp,uint32_t uiLen)
{
	if(NULL != MemoryAPI.ReadDWords)
	{
		MemoryAPI.ReadDWords(uiAddr,puiTemp,uiLen);
	}
}
/**********************************************************************************************
	Function		:void MEMORY_WriteByte(uint32_t uiAddr,unsigned char ucData)
	Description		:      
	Input Parameter	:    
	Output Parameter:   
	Who	Make it	?	:        		
	History			:							Date/Time:12-03-2013
**********************************************************************************************/ 
void MEMORY_WriteByte(uint32_t uiAddr,unsigned char ucData)
{
	if(NULL != MemoryAPI.WriteByte)
	{
		MemoryAPI.WriteByte(uiAddr,ucData);
	}
}
/**********************************************************************************************
	Function		:void MEMORY_WriteBytes(uint32_t uiAddr,unsigned char *pucFrame,uint32_t uiLen)
	Description		:      
	Input Parameter	:    
	Output Parameter:   
	Who	Make it	?	:        		
	History			:							Date/Time:12-03-2013
**********************************************************************************************/ 
void MEMORY_WriteBytes(uint32_t uiAddr,unsigned char *pucFrame,uint32_t uiLen)
{
	if(NULL != MemoryAPI.WriteBytes)
	{
		MemoryAPI.WriteBytes(uiAddr,pucFrame,uiLen);
	}
}
/**********************************************************************************************
	Function		:void MEMORY_WriteDWord(uint32_t uiAddr,uint32_t uiData)
	Description		:      
	Input Parameter	:    
	Output Parameter:   
	Who	Make it	?	:        		
	History			:							Date/Time:12-03-2013
**********************************************************************************************/ 
void MEMORY_WriteDWord(uint32_t uiAddr,uint32_t uiData)
{
	if(NULL != MemoryAPI.WriteDWord)
	{
		MemoryAPI.WriteDWord(uiAddr,uiData);
	}
}
/**********************************************************************************************
	Function		:void MEMORY_WriteDWords(uint32_t uiAddr,uint32_t *puiTemp,uint32_t uiLen)
	Description		:      
	Input Parameter	:    
	Output Parameter:   
	Who	Make it	?	:        		
	History			:							Date/Time:12-03-2013
**********************************************************************************************/ 
void MEMORY_WriteDWords(uint32_t uiAddr,uint32_t *puiTemp,uint32_t uiLen)
{
	if(NULL != MemoryAPI.WriteDWords)
	{
		MemoryAPI.WriteDWords(uiAddr,puiTemp,uiLen);
	}
}
