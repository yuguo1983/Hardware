/* Includes ------------------------------------------------------------------*/
#include "include.h"

uint16_t setarr[]={50,100,200,500,1000,2000,3000};
uint16_t inputarr[]={0};
uint8_t stata_flag=1;


void start_calib(uint8_t ch,uint16_t *const_arr ,uint16_t input_value,uint16_t *input_arr)
{
	uint8_t i,j=0;
	uint8_t finish_flag=0;
	i=sizeof(const_arr);
	if(finish_flag==0)
	{
		if(j<i)
		{
		set_vol( ch ,const_arr[j]);
		if(input_value!=0)
			{
		*input_arr=input_value;
		input_value=0;
	  j++;
			}
		
		else 
			finish_flag=1;
		}
	}

}

//最小二乘法做直线拟合，用于校准电压，电流
uint8_t leastSquareLinearFit(float x[], float y[],  int num, float *_a, float *_b)
{
	
    float sum_x2 = 0.0;
    float sum_y  = 0.0;
    float sum_x  = 0.0;
    float sum_xy = 0.0;



        for (int i = 0; i < num; ++i) {
            sum_x2 += x[i]*x[i];
            sum_y  += y[i];
            sum_x  += x[i];
            sum_xy += x[i]*y[i];
        }
  
    *_a = (num*sum_xy - sum_x*sum_y)/(num*sum_x2 - sum_x*sum_x);
    *_b = (sum_x2*sum_y - sum_x*sum_xy)/(num*sum_x2-sum_x*sum_x);


    return 0;
}

  
void  get_vol_min(void)
{
	_CalibData *Calib;
	_Cliab_poll Cliab_poll;
	_Port_num port;
	Calib=&port.port1;
	Calib+=Cliab_poll.chanel;
	float adc_code;
	adc_code=ads1256ReadValue(MUXP_AIN1|MUXN_AINCOM); 
	if(Cliab_poll.type==CALIB_TYPE_V)
	Calib->uiCodeMin=adc_code;
	Calib->uiOutMin=Cliab_poll.recovervol;
}



void get_vol_max(int16_t vol_value)
{
	_CalibData *Calib;
	_Port_num  port;
	Calib =&port.port1;
	float adc_code;
	adc_code=ads1256ReadValue(MUXP_AIN1|MUXN_AINCOM); 
	Calib->uiCodeMax=adc_code;
	Calib->uiOutMax=vol_value;

}

typedef enum
{
	CALIB_POLL_IDLE,
	CALIB_START_FIND,
	CALIB_CHECK_MIN,
	CALIB_CHECK_MAX,
}
_stata;


void check_calib(void)
{
	stata_flag=1;
	if(stata_flag==1)
	{
//	  get_vol_min();
		stata_flag=2;
	}
	else if(stata_flag==2)
	{
//	 get_vol_max((uint16_t)usRegInputBuf[40]);
	 stata_flag=0;
	}

}




uint64_t CALIB_VOutToDACCode(int64_t uiValue)
{
	int64_t uiGain = 0;
	int64_t uiOffset = 0;
	int64_t uiCodeMin = 0;
	int64_t uiCodeMax = 0;
	int64_t uiOutMin = 0;
	int64_t uiOutMax = 0;		
	int64_t uliValue = 0;

	
	uiCodeMin = 1490;
	uiCodeMax = 15750;
	
	uiOutMin = 329044;
	uiOutMax = 4335746;
	
	uiGain = uiOutMax - uiOutMin;
	uiOffset = uiCodeMax - uiCodeMin;
	
	//dbSlope = (double)uiGain/(double)uiOffset;	
	//vout = voumin + (dacx - dacmin)*slope;
	//dacx = (vout-voutmin)/slope + dacmin;	

//	uliValue = uiValue;
//	uliValue *= 10;		
	uliValue = (uiValue - uiOutMin);
//	uliValue -= uiOutMin;	
	uliValue *= uiOffset;	
	uliValue /= uiGain;	
	uliValue += uiCodeMin;
	
	return (uint32_t)uliValue;
}


uint64_t CALIB_IOutToDACCode(int64_t uiValue)
{

	int64_t uiGain = 0;
	int64_t uiOffset = 0;
	int64_t uiCodeMin = 0;
	int64_t uiCodeMax = 0;
	int64_t uiOutMin = 0;
	int64_t uiOutMax = 0;		
	int64_t uliValue = 0;

	
	uiCodeMin = 100;
	uiCodeMax = 990;
	
	uiOutMin = 187;
	uiOutMax = 1891;
	
	uiGain = uiOutMax - uiOutMin;
	uiOffset = uiCodeMax - uiCodeMin;
	
	//dbSlope = (double)uiGain/(double)uiOffset;	
	//vout = voumin + (dacx - dacmin)*slope;
	//dacx = (vout-voutmin)/slope + dacmin;	

//	uliValue = uiValue;
//	uliValue *= 10;		
	uliValue = (uiValue - uiOutMin);
//	uliValue -= uiOutMin;	
	uliValue *= uiOffset;	
	uliValue /= uiGain;	
	uliValue += uiCodeMin;
	
	return (uint32_t)uliValue;
}






uint64_t CALIB_IdisToDACCode(int64_t uiValue)
{

	int64_t uiGain = 0;
	int64_t uiOffset = 0;
	int64_t uiCodeMin = 0;
	int64_t uiCodeMax = 0;
	int64_t uiOutMin = 0;
	int64_t uiOutMax = 0;		
	int64_t uliValue = 0;

	
	uiCodeMin = 107;
	uiCodeMax = 1012;
	
	uiOutMin = 166323;
	uiOutMax = 1714496;
	
	uiGain = uiOutMax - uiOutMin;
	uiOffset = uiCodeMax - uiCodeMin;
	
	//dbSlope = (double)uiGain/(double)uiOffset;	
	//vout = voumin + (dacx - dacmin)*slope;
	//dacx = (vout-voutmin)/slope + dacmin;	

//	uliValue = uiValue;
//	uliValue *= 10;		
	uliValue = (uiValue - uiOutMin);
//	uliValue -= uiOutMin;	
	uliValue *= uiOffset;	
	uliValue /= uiGain;	
	uliValue += uiCodeMin;
	
	return (uint32_t)uliValue;
}












// void CALIB_THREAD_CheckVOut(void)
//{
//	if(CALIB_POLL_IDLE == srtCalibPoll.uiStatus)
//	{
//		//wait start calib process
//		if(srtCalibPoll.uiTrigger)
//		{
//			srtCalibPoll.uiTrigger = 0;
//			srtCalibPoll.uiTick = TIM_CORE_GetTick();
//			
//			srtCalibPoll.uiResult = 0;
//			srtCalibPoll.uiIsFinish = 1;
//			srtCalibPoll.uiRecordVValue = 0;
//			srtCalibPoll.uiRecordAValue = 0;
//			srtCalibPoll.uiStatus = CALIB_START_FIND;
//		}
//	}
//	else if(CALIB_START_FIND == srtCalibPoll.uiStatus)
//	{
//		//start find,umin
//		if(TIM_CORE_GetTick() > (srtCalibPoll.uiTick + 100))
//		{
//            CALIB_THREAD_StartFind();
//			srtCalibPoll.uiTick = TIM_CORE_GetTick();
//			srtCalibPoll.uiStartTick = srtCalibPoll.uiTick;
//			srtCalibPoll.uiStatus = CALIB_CHECK_MIN;			
//		}
//	}
//	else if(CALIB_CHECK_MIN == srtCalibPoll.uiStatus)
//	{
//		//GET,VMON min
//		if(TIM_CORE_GetTick() > (srtCalibPoll.uiTick + 300))
//		{        
//			if(CALIB_THREAD_GetMin() < 0)
//			{}
//		}
//	}
//	else if(CALIB_CHECK_MAX == srtCalibPoll.uiStatus)
//	{
//		//GET,VMON MAX
//		if(TIM_CORE_GetTick() > (srtCalibPoll.uiTick + 300))
//		{
//			if(CALIB_THREAD_GetMax() < 0)
//			{}
//		}
//	}
//}

