/***************************************************************
  ModBus读写操作的四个函数
  eMBRegInputCB eMBRegHoldingCB
  eMBRegCoilsCB	eMBRegDiscreteCB
**************************************************************/
#include "mb.h"
#include "mbport.h"
#include "include.h"

//Modbus规定寄存器起始地址为1
#define REG_INPUT_START 4001
#define REG_INPUT_NREGS 8
#define REG_HOLDING_START 4001
#define REG_HOLDING_NREGS 100


#define SET_MODE				10
#define SET_UPTIM				11
#define SET_DNTIM				12
#define SET_ITYPE				13
#define SET_VVALUE			14
#define SET_IVALUE			15
#define SET_RVALUE			16
#define SET_LEDVF				17
#define POWER						18



#define SET1_MODE				20
#define SET1_UPTIM			21
#define SET1_DNTIM			22
#define SET1_ITYPE			23
#define SET1_VVALUE			24
#define SET1_IVALUE			25
#define SET1_RVALUE			26
#define SET1_LEDVF			27
#define POWER1					28

//校准
#define START						40
#define SET_TYPE       	41//设置校准类型　1　2
#define ISMODE					42//设置校准模式　CV　CC
#define SET_RAIN				43//设置校准档位　A/MA
#define SET_CHANEL			44//设置校准通道　1，2
#define RECOVER_VALUE		45//输入万用表测的值

extern uint16_t aport_vol;
extern uint16_t aport_cur;
extern uint16_t bport_vol;
extern uint16_t bport_cur;


uint32_t idAddr[]={
	0x1FFFF7AC,  /*STM32F0唯一ID起始地址*/
	0x1FFFF7E8,  /*STM32F1唯一ID起始地址*/
	0x1FFF7A10,  /*STM32F2唯一ID起始地址*/
	0x1FFFF7AC,  /*STM32F3唯一ID起始地址*/
	0x1FFF7A10,  /*STM32F4唯一ID起始地址*/
	0x1FF0F420,  /*STM32F7唯一ID起始地址*/
	0x1FF80050,  /*STM32L0唯一ID起始地址*/
	0x1FF80050,  /*STM32L1唯一ID起始地址*/
	0x1FFF7590   /*STM32L4唯一ID起始地址*/
};

uint32_t GetSTM32ID(void)
{
	uint32_t id[3];
    id[0]=*(uint32_t*)(idAddr[0]);
    id[1]=*(uint32_t*)(idAddr[0]+4);
    id[2]=*(uint32_t*)(idAddr[0]+8);
	return id[0];
}



USHORT usRegInputBuf[8];
USHORT usRegHoldingBuf[100];
USHORT tempHoldingBuf[100];

//读输入寄存器 功能码0x04
eMBErrorCode
eMBRegInputCB(UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNRegs)
{
	eMBErrorCode eStatus = MB_ENOERR;
	int iRegIndex;

	if ((usAddress >= REG_INPUT_START) && (usAddress + usNRegs <= REG_INPUT_START + REG_INPUT_NREGS))
	{
		iRegIndex = (int)(usAddress - REG_INPUT_START);

		//拷贝用户空间到缓冲区
		uint32_t SN = GetSTM32ID();
		usRegInputBuf[0] = 0x4C47;//"LG"
		usRegInputBuf[1] = 0x4B4A;//"KJ"
		usRegInputBuf[2] = 0x2107;//VID
		usRegInputBuf[3] = 0x0058;//PID
		usRegInputBuf[4] = 0x0100;//HW Version
		usRegInputBuf[5] = 0x0101;//SW Version
		usRegInputBuf[6] = SN >> 16;
		usRegInputBuf[7] = SN;

		while (usNRegs > 0)
		{
			*pucRegBuffer++ = (unsigned char)(usRegInputBuf[iRegIndex] >> 8);	//PDU的先输出reg的高位；
			*pucRegBuffer++ = (unsigned char)(usRegInputBuf[iRegIndex] & 0xFF); //再输出低位；
			iRegIndex++;
			usNRegs--;
		}
	}
	else
	{
		eStatus = MB_ENOREG;
	}
	return eStatus;
}

extern _ADC_port adc_num;
extern  _srtCalibPoll srtCalibPoll;
_srtCalibData srtCalibData;
//读写保持寄存器 功能码读0x03写0x06
eMBErrorCode
eMBRegHoldingCB(UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNRegs, eMBRegisterMode eMode)
{
	eMBErrorCode eStatus = MB_ENOERR;
	int iRegIndex;
  _DataType  *datatype;
	datatype=&adc_num.port1;
	if ((usAddress >= REG_HOLDING_START) && (usAddress + usNRegs <= REG_HOLDING_START + REG_HOLDING_NREGS))
	{
		iRegIndex = (int)(usAddress - REG_HOLDING_START);
		switch (eMode)
		{
		case MB_REG_READ:
		
		usRegHoldingBuf[0] =	aport_vol;//
		usRegHoldingBuf[1] = 	aport_cur;//
		usRegHoldingBuf[2] = 	bport_vol;//
		usRegHoldingBuf[3] =	bport_cur;//

			
		
		
			usRegHoldingBuf[SET_TYPE]=tempHoldingBuf[SET_TYPE];
			usRegHoldingBuf[SET_CHANEL]=tempHoldingBuf[SET_CHANEL];
			usRegHoldingBuf[SET_RAIN]=tempHoldingBuf[SET_RAIN];
			usRegHoldingBuf[RECOVER_VALUE]=tempHoldingBuf[RECOVER_VALUE];
		
			
			
			while (usNRegs > 0)
			{
				*pucRegBuffer++ = (unsigned char)(usRegHoldingBuf[iRegIndex] >> 8);
				*pucRegBuffer++ = (unsigned char)(usRegHoldingBuf[iRegIndex] & 0xFF);
				iRegIndex++;
				usNRegs--;
			}
			break;

		case MB_REG_WRITE:
			while (usNRegs > 0)
			{
				usRegHoldingBuf[iRegIndex] = (*pucRegBuffer++) << 8;
				usRegHoldingBuf[iRegIndex] |= *pucRegBuffer++;
				iRegIndex++;
				usNRegs--;
			}
			
		if(usRegHoldingBuf[START]!=tempHoldingBuf[START])
		{
			tempHoldingBuf[START]=usRegHoldingBuf[START];
			if(tempHoldingBuf[START])
			{
				usRegHoldingBuf[START]=0;
				usRegHoldingBuf[SET_TYPE]=0;
				usRegHoldingBuf[SET_CHANEL]=0;
				usRegHoldingBuf[SET_RAIN]=0;
				usRegHoldingBuf[RECOVER_VALUE]=0;
				usRegHoldingBuf[ISMODE]=0;
				tempHoldingBuf[START]=0;
				tempHoldingBuf[SET_TYPE]=0;
				tempHoldingBuf[SET_CHANEL]=0;
				tempHoldingBuf[SET_RAIN]=0;
				tempHoldingBuf[RECOVER_VALUE]=0;
				tempHoldingBuf[ISMODE]=0;
				
			
			}
		}			
		else if(usRegHoldingBuf[SET_TYPE]!=tempHoldingBuf[SET_TYPE])
		{
			tempHoldingBuf[SET_TYPE]=usRegHoldingBuf[SET_TYPE];
			CALIB_THREAD_StartType(tempHoldingBuf[SET_TYPE]);
		}	
		else if(usRegHoldingBuf[SET_CHANEL]!=tempHoldingBuf[SET_CHANEL])
		{
			tempHoldingBuf[SET_CHANEL]=usRegHoldingBuf[SET_CHANEL];
			CALIB_THREAD_StartChannel(tempHoldingBuf[SET_CHANEL]-1);
		}
		else if(usRegHoldingBuf[SET_RAIN]!=tempHoldingBuf[SET_RAIN])
		{
			tempHoldingBuf[SET_RAIN]=usRegHoldingBuf[SET_RAIN];
			CALIB_THREAD_SetIRange(tempHoldingBuf[SET_RAIN]);
		}			
		else if(usRegHoldingBuf[RECOVER_VALUE]!=tempHoldingBuf[RECOVER_VALUE])
		{
			tempHoldingBuf[RECOVER_VALUE]=usRegHoldingBuf[RECOVER_VALUE];
			CALIB_THREAD_RecordChannel(tempHoldingBuf[RECOVER_VALUE],tempHoldingBuf[SET_TYPE]);
		}		
		else if(usRegHoldingBuf[ISMODE]!=tempHoldingBuf[ISMODE])
		{
			tempHoldingBuf[ISMODE]=usRegHoldingBuf[ISMODE];
			srtCalibPoll.uiMODE=tempHoldingBuf[ISMODE];
		}			
		
		
		
		updata_mb();
		
		
		
		}
	}
	else
	{
		eStatus = MB_ENOREG;
	}
	return eStatus;
}

void cr_chanel(void)
{
	if(adc_num.port1.mode==ISCR)
	{
		set1_res();
	}
	if(adc_num.port2.mode==ISCR)
	{
		set2_res();
	}
	if(adc_num.port1.mode==ISCLED)
	{
		cr1_led();
	}
		if(adc_num.port2.mode==ISCLED)
	{
		cr2_led();
	}
}	
uint16_t tempcurrent1=0;
uint16_t tempcurrent2=0;
void set1_res(void)
{
	int32_t vol=0;
	int32_t temp=0;
	uint32_t current=0;
  vol=adc_num.port1.Vvalue;
	temp=CALIB_THREAD_VMonToValue(0,vol);
  current=(temp/adc_num.port1.resvalue);
//	printf("temp:%d  ",current);
	if(current>1000)
	{
	   adc_num.port1.Itype=ISAA;
	}
	else 
	{
		adc_num.port1.Itype=ISMA;
	}
	
	if(adc_num.port1.mode==ISCR)
	{
		if(adc_num.port1.resvalue)
		{
			setccvoltege(0,CALIB_THREAD_IToSet(0,current));
		}
		else {;}
	}
}
void  set2_res(void)
{
	int32_t vol=0;
	int32_t temp=0;
	uint32_t current=0;
  vol=adc_num.port2.Vvalue;
	temp=CALIB_THREAD_VMonToValue(1,vol);
  current=temp/adc_num.port2.resvalue;
//	printf("temp1:%d  ",current);
	if(current>1000)
	{
	  adc_num.port2.Itype=ISAA;
	}
	else 
	{
		adc_num.port2.Itype=ISMA;
	}
	if(adc_num.port2.mode==ISCR)
	{
		if(adc_num.port2.resvalue)
		{
			setccvoltege(1,CALIB_THREAD_IToSet(1,current));
		}
		else {;}
	}
	
	}

//void cr1_led(void)
//{
//	int32_t vol=0;
//	int32_t temp=0;
//	int32_t current=0;
//  vol=adc_num.port1.Vvalue;
//	temp=CALIB_THREAD_VMonToValue(0,vol);
//	printf("vol:%d  mA",temp);
//	current=CALIB_THREAD_VoutToIout(0,temp);
//	if(current>3000)
//	{
//		current=0;
//	}
//	printf("current:%d  mA",current);
//	if(adc_num.port1.mode==ISCLED)
//	{
//		if(adc_num.port1.ledvf)
//		{
//			if(temp<=adc_num.port1.ledvf)
//			{
//				setccvoltege(0,0);

//			}
//			else if(temp>=adc_num.port1.ledvf)
//			{
//			setccvoltege(0,CALIB_THREAD_IToSet(0,current));			
//			}
//		}
//	}

//}	


//void cr2_led(void)
//{
//	int32_t vol=0;
//	int32_t temp=0;
//	int32_t current=0;
//  vol=adc_num.port2.Vvalue;
//	temp=CALIB_THREAD_VMonToValue(1,vol);
//	printf("vol:%d  mA",temp);
//	current=CALIB_THREAD_VoutToIout(1,temp);
//	if(current>3000)
//	{
//		current=0;
//	}
//	printf("current1:%d  mA\r\n",current);
//	if(adc_num.port2.mode==ISCLED)
//	{
//		if(adc_num.port2.ledvf)
//		{
//			if(temp<=adc_num.port2.ledvf)
//			{
//				setccvoltege(1,0);
//			}
//			else if(temp>=adc_num.port2.ledvf)
//			{
//				setccvoltege(1,CALIB_THREAD_IToSet(1,current));
//			}
//		}
//	}
//}


void cr1_led(void)
{	

	int32_t vol=0;
	int32_t voltemp=0;
	int32_t cureent=0;
	vol=adc_num.port1.Vvalue;
	voltemp=CALIB_THREAD_VMonToValue(0,vol);
	cureent=adc_num.port1.Avalue;
	cureent=CALIB_THREAD_ImonToValue(0,cureent);
	if(adc_num.port1.mode==ISCLED)
	{
		if(adc_num.port1.ledvf)
	{
		 if(voltemp>=adc_num.port1.ledvf&cureent<=100)
	   {
		   setcvvoltege(0,CALIB_THREAD_VToVset(0,adc_num.port1.ledvf+3000));
	   }
		 else if(voltemp>=adc_num.port1.ledvf&cureent>100&cureent<=1000)
		 {
			setcvvoltege(0,CALIB_THREAD_VToVset(0,10000));
		 }
		 else if(voltemp>=adc_num.port1.ledvf&cureent>1000)
		 {
			setcvvoltege(0,CALIB_THREAD_VToVset(0,13000));
		 }		
	}
	}
}
	
void cr2_led(void)
{	
		int32_t vol=0;
	int32_t voltemp=0;
	int32_t cureent=0;
	vol=adc_num.port2.Vvalue;
	voltemp=CALIB_THREAD_VMonToValue(1,vol);
	cureent=adc_num.port2.Avalue;
	cureent=CALIB_THREAD_ImonToValue(1,cureent);
	if(adc_num.port2.mode==ISCLED)
	{
		if(adc_num.port2.ledvf)
	{
		 if(voltemp>=adc_num.port2.ledvf&cureent<=1000)
	   {
		   setcvvoltege(1,CALIB_THREAD_VToVset(1,adc_num.port2.ledvf+3000));
	   }
		 else if(voltemp>=adc_num.port2.ledvf&cureent>1000&cureent<=1000)
		 {
			setcvvoltege(1,CALIB_THREAD_VToVset(1,11000));
		 }
		 else if(voltemp>=adc_num.port2.ledvf&cureent>1000)
		 {
			setcvvoltege(1,CALIB_THREAD_VToVset(1,13000));
		 }		
	}
	}
}
		
void updata_mb(void)
{
	_DataType  *datatype;
	
   if(usRegHoldingBuf[SET_MODE]!=tempHoldingBuf[SET_MODE])
		{
			tempHoldingBuf[SET_MODE]=usRegHoldingBuf[SET_MODE];
			datatype=&adc_num.port1;
			datatype->mode=tempHoldingBuf[SET_MODE];
		}	
   else if(usRegHoldingBuf[SET_UPTIM]!=tempHoldingBuf[SET_UPTIM])
		{
			tempHoldingBuf[SET_UPTIM]=usRegHoldingBuf[SET_UPTIM];
			datatype=&adc_num.port1;
			datatype->uptimes=tempHoldingBuf[SET_UPTIM];
			
		}			
   else if(usRegHoldingBuf[SET_DNTIM]!=tempHoldingBuf[SET_DNTIM])
		{
			tempHoldingBuf[SET_DNTIM]=usRegHoldingBuf[SET_DNTIM];
			datatype=&adc_num.port1;
			datatype->dntimes=tempHoldingBuf[SET_DNTIM];
			
		}	
		else if(usRegHoldingBuf[SET_ITYPE]!=tempHoldingBuf[SET_ITYPE])
		{
			tempHoldingBuf[SET_ITYPE]=usRegHoldingBuf[SET_ITYPE];
			datatype=&adc_num.port1;
			datatype->Itype=tempHoldingBuf[SET_ITYPE];
			
		}						
		else if(usRegHoldingBuf[SET_VVALUE]!=tempHoldingBuf[SET_VVALUE])
		{
			tempHoldingBuf[SET_VVALUE]=usRegHoldingBuf[SET_VVALUE];
			datatype=&adc_num.port1;
			setcvvoltege(0,CALIB_THREAD_VToVset(0,tempHoldingBuf[SET_VVALUE]));	
		}	
		else if(usRegHoldingBuf[SET_IVALUE]!=tempHoldingBuf[SET_IVALUE])
		{
			tempHoldingBuf[SET_IVALUE]=usRegHoldingBuf[SET_IVALUE];
			datatype=&adc_num.port1;
			setccvoltege(0,CALIB_THREAD_IToSet(0,tempHoldingBuf[SET_IVALUE]));	
		}			
		else if(usRegHoldingBuf[SET_RVALUE]!=tempHoldingBuf[SET_RVALUE])
		{
			tempHoldingBuf[SET_RVALUE]=usRegHoldingBuf[SET_RVALUE];
			datatype=&adc_num.port1;
			if(tempHoldingBuf[SET_RVALUE])
			{
			datatype->resvalue=tempHoldingBuf[SET_RVALUE];
			}
			
		}
		else if(usRegHoldingBuf[SET_LEDVF]!=tempHoldingBuf[SET_LEDVF])
		{
			tempHoldingBuf[SET_LEDVF]=usRegHoldingBuf[SET_LEDVF];
			datatype=&adc_num.port1;
			datatype->ledvf=tempHoldingBuf[SET_LEDVF];			
		}		
		
		else if(usRegHoldingBuf[POWER]!=tempHoldingBuf[POWER])
		{
			tempHoldingBuf[POWER]=usRegHoldingBuf[POWER];
			if(tempHoldingBuf[POWER])
			{
				usRegHoldingBuf[SET_MODE]=0;
				usRegHoldingBuf[SET_ITYPE]=0;
				usRegHoldingBuf[SET_VVALUE]=0;
				usRegHoldingBuf[SET_IVALUE]=0;
				usRegHoldingBuf[SET_RVALUE]=0;
				usRegHoldingBuf[SET_UPTIM]=0;
				usRegHoldingBuf[SET_DNTIM]=0;
				usRegHoldingBuf[SET_LEDVF]=0;
				usRegHoldingBuf[POWER]=0;
				tempHoldingBuf[POWER]=0;
					setccvoltege(0,0);
					setaminrain(0);
					setamaxrain(0);	
				
		}
	}
		
		
	if(usRegHoldingBuf[SET1_MODE]!=tempHoldingBuf[SET1_MODE])
		{
			tempHoldingBuf[SET1_MODE]=usRegHoldingBuf[SET1_MODE];
			datatype=&adc_num.port1;
			datatype+=1;
			datatype->mode=tempHoldingBuf[SET1_MODE];
		}	
   else if(usRegHoldingBuf[SET1_UPTIM]!=tempHoldingBuf[SET1_UPTIM])
		{
			tempHoldingBuf[SET1_UPTIM]=usRegHoldingBuf[SET1_UPTIM];
			datatype=&adc_num.port1;
			datatype+=1;
			datatype->uptimes=tempHoldingBuf[SET1_UPTIM];
			
		}			
   else if(usRegHoldingBuf[SET1_DNTIM]!=tempHoldingBuf[SET1_DNTIM])
		{
			tempHoldingBuf[SET1_DNTIM]=usRegHoldingBuf[SET1_DNTIM];
			datatype=&adc_num.port1;
			datatype+=1;
			datatype->dntimes=tempHoldingBuf[SET1_DNTIM];
			
		}		
		else if(usRegHoldingBuf[SET1_ITYPE]!=tempHoldingBuf[SET1_ITYPE])
		{
			tempHoldingBuf[SET1_ITYPE]=usRegHoldingBuf[SET1_ITYPE];
			datatype=&adc_num.port1;
			datatype+=1;
			datatype->Itype=tempHoldingBuf[SET1_ITYPE];
			
		}			

		else if(usRegHoldingBuf[SET1_VVALUE]!=tempHoldingBuf[SET1_VVALUE])
		{
			tempHoldingBuf[SET1_VVALUE]=usRegHoldingBuf[SET1_VVALUE];
			datatype=&adc_num.port1;
			datatype+=1;
			setcvvoltege(1,CALIB_THREAD_VToVset(1,tempHoldingBuf[SET1_VVALUE]));	
		}	
		else if(usRegHoldingBuf[SET1_IVALUE]!=tempHoldingBuf[SET1_IVALUE])
		{
			tempHoldingBuf[SET1_IVALUE]=usRegHoldingBuf[SET1_IVALUE];
			setccvoltege(1,CALIB_THREAD_IToSet(1,tempHoldingBuf[SET1_IVALUE]));	
		}			
		else if(usRegHoldingBuf[SET1_RVALUE]!=tempHoldingBuf[SET1_RVALUE])
		{
			tempHoldingBuf[SET1_RVALUE]=usRegHoldingBuf[SET1_RVALUE];
			datatype=&adc_num.port1;
			datatype+=1;
			if(tempHoldingBuf[SET1_RVALUE])
			{
			datatype->resvalue=tempHoldingBuf[SET1_RVALUE];
			}
		}			
		else if(usRegHoldingBuf[SET1_LEDVF]!=tempHoldingBuf[SET1_LEDVF])
		{
			tempHoldingBuf[SET1_LEDVF]=usRegHoldingBuf[SET1_LEDVF];
			datatype=&adc_num.port1;
			datatype+=1;
			datatype->ledvf=tempHoldingBuf[SET1_LEDVF];

			
		}			
		else if(usRegHoldingBuf[POWER1]!=tempHoldingBuf[POWER1])
		{
			tempHoldingBuf[POWER1]=usRegHoldingBuf[POWER1];
			if(tempHoldingBuf[POWER1])
			{
				usRegHoldingBuf[SET1_MODE]=0;
				usRegHoldingBuf[SET1_ITYPE]=0;
				usRegHoldingBuf[SET1_VVALUE]=0;
				usRegHoldingBuf[SET1_IVALUE]=0;
				usRegHoldingBuf[SET1_RVALUE]=0;
				usRegHoldingBuf[SET1_UPTIM]=0;
				usRegHoldingBuf[SET1_DNTIM]=0;
				usRegHoldingBuf[SET1_LEDVF]=0;
				usRegHoldingBuf[POWER1]=0;
				tempHoldingBuf[POWER1]=0;
				setbminrain(0);
				setbmaxrain(0);	

				}
			}
		}
		

				
		






//读写线圈/离散输出寄存器 功能码读0x01写0x05
eMBErrorCode
eMBRegCoilsCB(UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNCoils, eMBRegisterMode eMode)
{
	(void)pucRegBuffer;
	(void)usAddress;
	(void)usNCoils;
	(void)eMode;
	return MB_ENOREG;
}

//读离散输入寄存器 功能码0x02
eMBErrorCode
eMBRegDiscreteCB(UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNDiscrete)
{
	(void)pucRegBuffer;
	(void)usAddress;
	(void)usNDiscrete;
	return MB_ENOREG;
}
