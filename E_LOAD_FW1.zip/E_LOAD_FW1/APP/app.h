/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __APP_H
#define __APP_H


/* Includes ------------------------------------------------------------------*/

#include "main.h"
#include "include.h"


extern 	uint16_t    dac_vol_ch1;
extern 	uint16_t    dac_vol_ch2;
extern 	uint16_t    dac_vol_ch3;
extern 	uint16_t    dac_vol_ch4;
extern	uint8_t 		up_vol_flag;
extern	uint8_t 		power_flag;
void app(void);
void up_cv_setvol(void);
void setamaxrain(uint8_t status);
void setaminrain(uint8_t status);
void setbmaxrain(uint8_t status);
void setbminrain(uint8_t status);
void up_cv_setvol(void);
uint8_t getModBusAddressConfig(void);
void TIM_ModBus_Config(uint16_t usTimeOut50us);
void power_on(void);
void power_off(void);
void print_struct(void);
void mb_100ms(void);

void scan_rain(void );
void check_ad(void);
void updata_volcur(void);
#endif






