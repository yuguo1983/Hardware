/* Includes ------------------------------------------------------------------*/
#include "include.h"


#define ADDR0() HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_5)
#define ADDR1() HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_4)
#define ADDR2() HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_3)
//#define ADDR3() HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_6)
//#define MB_SAMPLE_TEST_SLAVE_ADDR  0x01

extern USHORT usRegHoldingBuf[100];
extern  uint16_t setarr[];
extern uint16_t inputarr[];
uint16_t aport_vol=0;
uint16_t aport_cur=0;
uint16_t bport_vol=0;
uint16_t bport_cur=0;

uint16_t    dac_vol_ch1=0;
uint16_t    dac_vol_ch2=0;
uint16_t    dac_vol_ch3=0;
uint16_t    dac_vol_ch4=0;

uint8_t 		power_flag=0;//��Դ���ر�־λ
uint16_t 	 	CH1_value=0;//��1�����趨緳�Ĵ���
uint16_t  	CH3_value=0;//��2�����趨緳�Ĵ���

uint16_t 	 	CH2_value=0;//
uint16_t  	CH4_value=0;//

const uint8_t TEXT_Buffer[]={"test 24c02 IIC TEST\r\n"};
#define SIZE sizeof(TEXT_Buffer)

uint8_t getModBusAddressConfig(void)
{
	return (ADDR0() << 1 | ADDR1());
}

void TIM_ModBus_Config(uint16_t usTimeOut50us)
{

}
extern _ADC_port adc_num;
extern uint8_t   check_flag;
uint8_t app_run=0;
uint8_t test_flag=0;
uint8_t step_flag=0;

void app(void)
{
	eMBInit(MB_RTU, 70, 0, 19200, MB_PAR_NONE);
	eMBEnable();
	float voltage=0;
	AT24CXX_Init();
	dac8554_init();
	set_vol(2,2490);	
	set_vol(4,2490);	
  setamaxrain(1);
	setbmaxrain(1);
	ads1256Init();
//	set_vol(2,0);	
//	set_vol(4,0);	
  setamaxrain(0);
	setbmaxrain(0);
	CALIB_THREAD_Init();
	HAL_TIM_Base_Start_IT(&htim3);
  
	app_run=1;
while (1)
	{

		check_ad();
		cr_chanel();
		CALIB_THREAD_Poll();
		updata_volcur(); 
		updata_mb();

	}
}

void check_ad(void)
{
	if(check_flag==1)
	{
		if(adc_num.port1.mode)
		{
			get_port_adcvalue(0);
		}
		if(adc_num.port2.mode)
		{
			get_port_adcvalue(1);
		}
		check_flag=0;
	}

}



void updata_volcur(void)
{
	aport_vol=(CALIB_THREAD_VMonToValue(0,adc_num.port1.Vvalue))>25?(CALIB_THREAD_VMonToValue(0,adc_num.port1.Vvalue)):0;//?????
	aport_cur=((CALIB_THREAD_ImonToValue(0,getIportvalue(0)))<0x7fff&(CALIB_THREAD_ImonToValue(0,getIportvalue(0)))>36)?(CALIB_THREAD_ImonToValue(0,getIportvalue(0))):0;//?????}
	bport_vol=(CALIB_THREAD_VMonToValue(1,adc_num.port2.Vvalue))>25?(CALIB_THREAD_VMonToValue(1,adc_num.port2.Vvalue)):0;//?????
	bport_cur=((CALIB_THREAD_ImonToValue(1,getIportvalue(1)))<0x7fff&(CALIB_THREAD_ImonToValue(1,getIportvalue(1)))>36)?(CALIB_THREAD_ImonToValue(1,getIportvalue(1))):0;//?????
}
uint32_t tempitype1=0;
uint32_t tempitype2=0;
void scan_rain(void )
{
	if(tempitype1!=adc_num.port1.Itype)
	{
		tempitype1=adc_num.port1.Itype;
	if(adc_num.port1.Itype==ISAA)
	{
	  setaminrain(0);
		setamaxrain(1);
	}
	else if(adc_num.port1.Itype==ISMA)
	{
	  setaminrain(1);
		setamaxrain(0);	
	}
	}
	if(tempitype2!=adc_num.port2.Itype)
	{
		tempitype2=adc_num.port2.Itype;
	if(tempitype2==ISAA)
	{
	  setbminrain(0);
		setbmaxrain(1);
	}
	else if(tempitype2==ISMA)
	{
	  setbminrain(1);
		setbmaxrain(0);	
	}
	}
}

void safe_check(void)
{
//	if(adc_num.port1.Avalue)

}

	
	
void mb_100ms(void)
{
	if(app_run)
	{
		( void )eMBPoll(  );


	}
}



void setamaxrain(uint8_t status)
{
	if(status==1)
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1, GPIO_PIN_SET);//��һ·a����
	else
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1, GPIO_PIN_RESET);//��һ·a����	
}

void setaminrain(uint8_t status)
{
	if(status==1)
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_2, GPIO_PIN_SET); //��һ·ma����
	else
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_2, GPIO_PIN_RESET); //��һ·ma����	
}

void setbmaxrain(uint8_t status)
{
	if(status==1)
		HAL_GPIO_WritePin(GPIOA,GPIO_PIN_0, GPIO_PIN_SET);
	else 
		HAL_GPIO_WritePin(GPIOA,GPIO_PIN_0, GPIO_PIN_RESET);
}

void setbminrain(uint8_t status)
{
	if(status==1)
		HAL_GPIO_WritePin(GPIOA,GPIO_PIN_15, GPIO_PIN_SET);
	else 
		HAL_GPIO_WritePin(GPIOA,GPIO_PIN_15, GPIO_PIN_RESET);
}





